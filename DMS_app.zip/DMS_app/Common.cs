﻿namespace JSOTest.wcf.Helper
{
    using JSOTest.wcf.Model;
    using Microsoft.IdentityModel.Tokens;
    using Org.BouncyCastle.Crypto.Parameters;
    using Org.BouncyCastle.Security;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IdentityModel.Tokens.Jwt;
    using System.IO;
    using System.Linq;
    using System.Security.Claims;
    using System.Security.Cryptography;
    using System.ServiceModel.Web;
    using System.Text;
    using System.Web;
    using System.Xml;
    using System.Xml.Linq;

    public class Common
    {
        public static ServiceHeaderInfo Authenticate(IncomingWebRequestContext requestContext)
        {
            ServiceHeaderInfo headerInfo = new ServiceHeaderInfo();
            System.Net.WebHeaderCollection headerCollection = requestContext.Headers;
            headerInfo.Token = headerCollection["Token"];

            if (headerInfo.Token == "dR$545#h^jjmanJ")
            {
                headerInfo.IsAuthenticated = true;
            }
            else
            {
                headerInfo.IsAuthenticated = false;
            }

            return headerInfo;
        }

        public static ServiceHeaderInfo1 Authenticate1(IncomingWebRequestContext requestContext)
        {
            ServiceHeaderInfo1 headerInfo = new ServiceHeaderInfo1();
            System.Net.WebHeaderCollection headerCollection = requestContext.Headers;
            headerInfo.Token = headerCollection["Token"];
            string path = HttpRuntime.AppDomainAppPath;
            string TokenFile = "GenerateToken" + ".txt";
            string FileName = Path.Combine(path, TokenFile);
            // Open the file to read from.
            using (StreamReader file = new StreamReader(FileName))
            {
                //int counter = 0;
                string ln;
                if ((ln = file.ReadLine()) != null)
                {
                    if (headerInfo.Token == ln)
                    {
                        headerInfo.IsAuthenticated = true;
                    }
                    else
                    {
                        headerInfo.IsAuthenticated = false;
                    }
                    //Console.WriteLine(ln);
                    //counter++;
                }
                file.Close();

            }
            return headerInfo;
        }

        public static ServiceHeaderInfo1 Authenticate2(IncomingWebRequestContext requestContext)
        {
            ServiceHeaderInfo1 headerInfo = new ServiceHeaderInfo1();
            System.Net.WebHeaderCollection headerCollection = requestContext.Headers;
            string authorization = requestContext.Headers["Authorization"];
            //If we don't find the authorization header return null
            if (string.IsNullOrEmpty(authorization))
            {
                return null;
            }
            //get the token from the auth header
            if (authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                headerInfo.Token = authorization.Substring("Bearer ".Length).Trim();
            }
            return ValidateToken(headerInfo.Token);
            //return GetPrincipalFromExpiredToken(headerInfo.Token);
        }

        //Working on JWT Token
        public Tokens GenerateRefreshToken(string UserId, string Password)
        {
            return GenerateJWTTokens(UserId, Password);
        }

        public Tokens GenerateJWTTokens(string UserId, string Password)
        {
            string ss = string.Empty;
            try
            {
                string jwtSecret = Convert.ToString(ConfigurationManager.AppSettings["jwtSecret"]);
                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenKey = Encoding.UTF8.GetBytes(jwtSecret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, UserId),
                new Claim(ClaimTypes.Name, Password)
            }),
                    Expires = DateTime.UtcNow.AddMinutes(30),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenKey), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var refreshToken = GenerateRefreshToken();
                ss = refreshToken;
                return new Tokens { Access_Token = tokenHandler.WriteToken(token), Refresh_Token = refreshToken };
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                const string lineSearch = ":line";
                var index = ex.StackTrace.LastIndexOf(lineSearch);
                var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                Logger.ErrorLogException("GenerateJWTTokens", "JWT", "'pn_user_id': '" + UserId + "','refreshToken':'" + ss, ex);
                return null;
            }
        }
        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }

        public static ServiceHeaderInfo1 GetPrincipalFromExpiredToken(string token)
        {
            string jwtSecret = Convert.ToString(ConfigurationManager.AppSettings["jwtSecret"]);
            ServiceHeaderInfo1 serviceHeader = new ServiceHeaderInfo1();
            var Key = Encoding.UTF8.GetBytes(jwtSecret);
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateLifetime = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Key),
                ClockSkew = TimeSpan.Zero,
                RequireExpirationTime = true
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out SecurityToken securityToken);
            JwtSecurityToken jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
            {
                //throw new SecurityTokenException("Invalid token");
                serviceHeader.Message = "Invalid Token";
                serviceHeader.IsAuthenticated = false;
            }
            var expClaim = principal.Claims.First(x => x.Type == "exp").Value;
            var userid = principal.Claims.First(x => x.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier").Value;
            var passwrd = principal.Claims.First(x => x.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name").Value;
            //var tokenExpiryTime = Convert.ToInt64(expClaim);
            //DateTimeOffset dateTimeOffset = DateTimeOffset.FromFileTime(tokenExpiryTime);
            if (jwtSecurityToken.ValidTo < DateTime.UtcNow)
            {
                serviceHeader.Message = "Token Expired";
                serviceHeader.IsAuthenticated = false;
            }
            else
            {
                serviceHeader.Message = "Token Validated";
                serviceHeader.IsAuthenticated = true;
            }
            return serviceHeader;
        }


        public static String DecryptWithGcm(string cipherText1)
        {
            string PhraseKey = System.Configuration.ConfigurationManager.AppSettings["PhraseKey"];
            string IvKey = System.Configuration.ConfigurationManager.AppSettings["IvKey"];

            byte[] RawBytes = Convert.FromBase64String(cipherText1);

            // converts a C# string to a byte array
            byte[] ivbytes = Encoding.ASCII.GetBytes(IvKey);
            byte[] keybytes = Encoding.ASCII.GetBytes(PhraseKey);

            var instance = CipherUtilities.GetCipher("AES/GCM/NoPadding");
            instance.Init(false, new AeadParameters(new KeyParameter(keybytes), 128, ivbytes));
            var decryptedData = instance.DoFinal(RawBytes);
            return Encoding.UTF8.GetString(decryptedData);
        }
        private static AesCryptoServiceProvider GetProvider(byte[] key)
        {
            AesCryptoServiceProvider result = new AesCryptoServiceProvider();
            result.BlockSize = 128;
            result.KeySize = 256;
            result.Padding = PaddingMode.PKCS7;

            //result.GenerateIV();
            //@1B2c3D4e5F6g7H8
            result.IV = Encoding.UTF8.GetBytes("@1B2c3D4e5F6g7H8");

            //byte[] RealKey = GetKey(key, result);
            result.Key = key;

            // result.IV = RealKey;
            return result;
        }
        public static string DecryptString(string base64StringToDecrypt)
        {
            string passphrase = System.Configuration.ConfigurationManager.AppSettings["PhraseKey"];
            string plaintext = "";
            //Set up the encryption objects
            using (AesCryptoServiceProvider acsp = GetProvider(Encoding.UTF8.GetBytes(passphrase)))
            {
                byte[] RawBytes = Convert.FromBase64String(base64StringToDecrypt);
                if (RawBytes == null)
                {
                    return plaintext;
                }
                ICryptoTransform ictD = acsp.CreateDecryptor();

                //RawBytes now contains original byte array, still in Encrypted state

                //Decrypt into stream
                MemoryStream msD = new MemoryStream(RawBytes);
                CryptoStream csD = new CryptoStream(msD, ictD, CryptoStreamMode.Read);
                ////csD now contains original byte array, fully decrypted

                ////return the content of msD as a regular string
                ////return (new StreamReader(csD)).ReadToEnd();

                using (StreamReader str = new StreamReader(csD))
                {
                    plaintext = str.ReadToEnd();
                }

                return plaintext;
            }
        }
        public static string GetDecryptedString(string _value)
        {
            try
            {
                if (string.IsNullOrEmpty(_value))
                {
                    _value = string.Empty;
                }
                else if (!string.IsNullOrEmpty(_value) && !"null".Equals(_value))
                {
                    //_value = DecryptString(_value);// Code commented by kritika kulariya
                    var Suffix = _value.Length > 4 ? _value.Substring(_value.Length - 4) : _value;
                    if (Suffix.ToLower() == "@gcm")
                    {
                        _value = _value.Substring(0, _value.Length - 4);
                        _value = DecryptWithGcm(_value);
                    }
                    else
                    {
                        _value = DecryptString(_value);
                        _value = !(string.IsNullOrEmpty(_value)) ? (_value.Replace(@"\", @"\\").Replace(@"""", "").Replace(@"'", "\'")).Trim() : "";
                    }
                }

            }
            catch (Exception ex)
            {
                //_value = "";
                Logger.Log("[" + _value + "] GetDecryptedString:: " + ex.ToString());
            }
            return _value;
        }


        public static string EncryptWithGcm(string plainText)
        {
            string PhraseKey = System.Configuration.ConfigurationManager.AppSettings["PhraseKey"];
            string IvKey = System.Configuration.ConfigurationManager.AppSettings["IvKey"];
            // converts a C# string to a byte array
            byte[] ivbytes = Encoding.ASCII.GetBytes(IvKey);
            byte[] keybytes = Encoding.ASCII.GetBytes(PhraseKey);

            var instance = CipherUtilities.GetCipher("AES/GCM/NoPadding");
            instance.Init(true, new AeadParameters(new KeyParameter(keybytes), 128, ivbytes));

            var plainTextData = Encoding.ASCII.GetBytes(plainText);
            var cipherText = instance.DoFinal(plainTextData);
            return Convert.ToBase64String(cipherText);
        }
        //Generate Token Functionality
        public static string GenerateToken(string username)
        {
            var randomNumber = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                var UserName = username;
                var RandomNumber = Convert.ToBase64String(randomNumber);
                var CreatedTime = System.DateTime.Now;
                string Token = String.Format("{0}|{1}|{2}", UserName, RandomNumber, CreatedTime);
                return EncryptWithGcm(Token);
            }
        }

        // Generate XML file for save token
        public static string GenearteXMLDealerFile(string username, string password)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string folder = Path.Combine(path, Path.Combine("DealerDetails.xml"));
            string getToken = GenerateToken(username);
            if (!File.Exists(folder))
            {
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                xmlWriterSettings.NewLineOnAttributes = true;
                using (XmlWriter xmlWriter = XmlWriter.Create(folder, xmlWriterSettings))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("Dealers");
                    xmlWriter.WriteStartElement("Dealer");
                    xmlWriter.WriteElementString("username", username);
                    xmlWriter.WriteElementString("token", getToken);
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();
                }
            }
            else
            {
                XDocument xDocument = XDocument.Load(folder);

                //first it will check if exist then update the token
                var items = from item in xDocument.Descendants("Dealer")
                            where item.Element("username").Value == username
                            select item;
                if (items.Count() > 0)
                {
                    foreach (XElement itemElement in items)
                    {
                        itemElement.SetElementValue("token", getToken);
                    }
                    xDocument.Save(folder);
                }
                else
                {

                    XElement root = xDocument.Element("Dealers");
                    IEnumerable<XElement> rows = root.Descendants("Dealer");
                    XElement firstRow = rows.First();
                    firstRow.AddBeforeSelf(
                       new XElement("Dealer",
                       new XElement("username", username),
                       new XElement("token", getToken))
                      );
                    xDocument.Save(folder);
                }
            }
            return getToken;
        }


        public static ServiceHeaderInfo1 ValidateToken(string token)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string folder = Path.Combine(path, Path.Combine("DealerDetails.xml"));
            ServiceHeaderInfo1 serviceHeaderInfo = new ServiceHeaderInfo1();
            bool flag = false;
            var TokenVal = DecryptWithGcm(token);
            if (TokenVal != null)
            {
                string[] tokenValue = TokenVal.Split('|');
                var UserName = Convert.ToString(tokenValue[0]);
                var CreatedTime = Convert.ToString(tokenValue[2]);
                XDocument xDocument = XDocument.Load(folder);
                var items = from item in xDocument.Descendants("Dealer")
                            where item.Element("username").Value == UserName
                            select item;
                if (items != null)
                {
                    var xElement = items.FirstOrDefault();
                    if (xElement != null)
                    {
                        var TokenFromFile = xElement.Element("token").Value;
                        if (TokenFromFile != token)
                        {
                            flag = false;
                        }
                        else
                        {
                            var currentTime = System.DateTime.Now;
                            var tokenCreatedTime = Convert.ToDateTime(CreatedTime).AddDays(2);
                            if (tokenCreatedTime < currentTime)
                            {
                                //Token is expired
                                flag = false;
                            }
                            else
                            {
                                flag = true;
                            }
                        }
                    }
                }
                serviceHeaderInfo.IsAuthenticated = flag;
                return serviceHeaderInfo;
            }
            else
            {
                serviceHeaderInfo.IsAuthenticated = flag;
                return serviceHeaderInfo;
            }
        }

        public string LogOut(string token)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string folder = Path.Combine(path, Path.Combine("DealerDetails.xml"));
            string flag = "Success";
            var TokenVal = DecryptWithGcm(token);
            if (TokenVal != null)
            {
                string[] tokenValue = TokenVal.Split('|');
                var UserName = Convert.ToString(tokenValue[0]);
                XDocument xDocument = XDocument.Load(folder);
                var items = from item in xDocument.Descendants("Dealer")
                            where item.Element("username").Value == UserName
                            select item;
                if (items != null)
                {
                    var xElement = items.FirstOrDefault();
                    if (xElement != null)
                    {
                        xElement.SetElementValue("token", "");
                    }
                    xDocument.Save(folder);
                }
            }
            return flag;
        }

        // Generate XML file for save and update count for login attempt
        public static string SaveLockOutCount(string username, int count)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string folder = Path.Combine(path, Path.Combine("AccountLockOut.xml"));
            string message = string.Empty;
            if (!File.Exists(folder))
            {
                XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
                xmlWriterSettings.Indent = true;
                xmlWriterSettings.NewLineOnAttributes = true;
                using (XmlWriter xmlWriter = XmlWriter.Create(folder, xmlWriterSettings))
                {
                    xmlWriter.WriteStartDocument();
                    xmlWriter.WriteStartElement("Dealers");
                    xmlWriter.WriteStartElement("Dealer");
                    xmlWriter.WriteElementString("username", username);
                    xmlWriter.WriteElementString("count", Convert.ToString(count));
                    xmlWriter.WriteElementString("CreatedDateTime", DateTime.Now.ToString());
                    xmlWriter.WriteEndElement();
                    xmlWriter.WriteEndDocument();
                    xmlWriter.Flush();
                    xmlWriter.Close();
                }
            }
            else
            {
                XDocument xDocument = XDocument.Load(folder);

                //first it will check if exist then update the token
                var items = from item in xDocument.Descendants("Dealer")
                            where item.Element("username").Value == username
                            select item;

                if (items.Count() > 0)
                {

                    foreach (XElement itemElement in items)
                    {
                        DateTime docTime = Convert.ToDateTime(itemElement.Element("CreatedDateTime").Value);
                        DateTime currentdtTime = DateTime.Now;
                        TimeSpan span = currentdtTime.Subtract(docTime);
                        var totalmin = Convert.ToInt32(span.TotalMinutes);
                        var chkcount = Convert.ToInt32(ConfigurationManager.AppSettings["AccountLockoutTime"]);
                        if (totalmin < chkcount)
                        {
                            var cnt = Convert.ToInt32(itemElement.Element("count").Value) + 1;
                            itemElement.SetElementValue("count", cnt);
                        }
                        else
                        {
                            itemElement.SetElementValue("count", count);
                            itemElement.SetElementValue("CreatedDateTime", currentdtTime);
                            message = "";
                        }
                    }
                    xDocument.Save(folder);
                }
                else
                {

                    XElement root = xDocument.Element("Dealers");
                    IEnumerable<XElement> rows = root.Descendants("Dealer");
                    XElement firstRow = rows.First();
                    firstRow.AddBeforeSelf(
                       new XElement("Dealer",
                       new XElement("username", username),
                       new XElement("count", count),
                       new XElement("CreatedDateTime", DateTime.Now.ToString())
                       )
                      );
                    xDocument.Save(folder);
                }
            }
            return "";
        }

        // return count for login attempt
        public static int CheckLockOutCount(string username)
        {
            string path = HttpRuntime.AppDomainAppPath;
            string folder = Path.Combine(path, Path.Combine("AccountLockOut.xml"));
            int cnt = 0;
            if (File.Exists(folder))
            {
                XDocument xDocument = XDocument.Load(folder);
                //first it will check if exist then update the token
                var items = from item in xDocument.Descendants("Dealer")
                            where item.Element("username").Value == username
                            select item;

                if (items.Count() > 0)
                {
                    foreach (XElement itemElement in items)
                    {
                        cnt = Convert.ToInt32(itemElement.Element("count").Value);
                        DateTime docTime = Convert.ToDateTime(itemElement.Element("CreatedDateTime").Value);
                        DateTime currentdtTime = DateTime.Now;
                        TimeSpan span = currentdtTime.Subtract(docTime);
                        var totalmin = Convert.ToInt32(span.TotalMinutes);
                        var chkcount = Convert.ToInt32(ConfigurationManager.AppSettings["AccountLockoutTime"]);
                        if (totalmin < chkcount)
                        {
                            return cnt;
                        }
                        else
                        {
                            itemElement.SetElementValue("count", 0);
                            itemElement.SetElementValue("CreatedDateTime", currentdtTime);
                            xDocument.Save(folder);
                            return 0;
                        }
                    }
                }
                else
                {
                    return cnt;
                }
            }
            return cnt;
        }
    }

    public class ServiceHeaderInfo
    {
        public bool IsAuthenticated { get; set; }
        public string Token { get; set; }
    }
    public class ServiceHeaderInfo1
    {
        public bool IsAuthenticated { get; set; }
        public string Token { get; set; }
        //Add new input Regarting JWT token

        public string Message { get; set; }
    }


    public enum ServiceMassageCode
    {
        SUCCESS = 200,
        INVALID_PARAMETER = 201,
        ERROR = 202,
        DATA_NOT_EXIST = 203,
        SQL_ERROR = 204,
        UNAUTHORIZED_REQUEST = 205,
        ITEM_NOT_EXIST = 206,
        DATA_ALREADY_EXIST = 207,
    }

}