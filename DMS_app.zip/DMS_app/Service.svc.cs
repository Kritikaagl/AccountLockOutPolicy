﻿namespace JSOTest.wcf
{
    using JSOTest.wcf.Helper;
    using JSOTest.wcf.model;
    using JSOTest.wcf.Model;
    using Oracle.DataAccess.Types;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.OracleClient;
    using System.IO;
    using System.ServiceModel.Activation;
    using System.ServiceModel.Web;
    using System.Text;
    using System.Web;
    using System.Web.Script.Serialization;

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service.svc or Service.svc.cs at the Solution Explorer and start debugging.
    public class Service : IService
    {

        string jsonResponce = string.Empty;
        JavaScriptSerializer js = new JavaScriptSerializer();
        String encType = string.Empty;
        string constr = ConfigurationManager.ConnectionStrings["ConnectionStrings"].ConnectionString;
        string constr_PushApi = ConfigurationManager.ConnectionStrings["conoracle_PushApi"].ConnectionString;
        OracleConnection con;
        OracleCommand cmd;
        DataSet ds;
        OracleDataAdapter da;
        DataTable dt;


        #region GET_DRIVABLE_FAILURE_HIST
        /// <summary>
        /// GetDrivableFailureHistory For Suzuki Connect Gen-2
        /// </summary>
        /// <param name="P_REG_NUM"></param>
        ///  <param name="P_VIN"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_DRIVABLE_FAILURE_HIST> GETDRIVABLEFAILUREHIST(string P_REG_NUM, string P_VIN)
        {

            BaseListReturnType<GET_DRIVABLE_FAILURE_HIST> response = new BaseListReturnType<GET_DRIVABLE_FAILURE_HIST>();

            GET_DRIVABLE_FAILURE_HIST Typedetail = null;
            List<GET_DRIVABLE_FAILURE_HIST> Details = new List<GET_DRIVABLE_FAILURE_HIST>();
            List<FAILURE_HIST> FAILURE_HIST_LIST = new List<FAILURE_HIST>();
            FAILURE_HIST FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_Drivable_Failure_Hist;
                cmd.CommandType = CommandType.StoredProcedure;
                OracleParameter InOutParam = new OracleParameter("P_REG_NUM", OracleType.VarChar, 20);
                InOutParam.Direction = ParameterDirection.InputOutput;
                InOutParam.Value = P_REG_NUM;
                cmd.Parameters.Add(InOutParam);
                cmd.Parameters.Add("P_VIN", OracleType.VarChar, 22).Value = P_VIN;
                //output varibale
                cmd.Parameters.Add("P_FAILURE_HIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["P_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["P_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["P_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_FAILURE_HIST"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new FAILURE_HIST();
                        FAILURE_HIST_CURSOR.FAILURE_ID = Convert.ToString(dr["FAILURE_ID"]);
                        FAILURE_HIST_CURSOR.CASE_CREATED_DATE = Convert.ToString(dr["CASE_CREATED_DATE"]);
                        FAILURE_HIST_CURSOR.BREAKDOWN_AREA = Convert.ToString(dr["BREAKDOWN_AREA"]);
                        FAILURE_HIST_CURSOR.ODOMETER_READING = Convert.ToString(dr["ODOMETER_READING"]);
                        FAILURE_HIST_CURSOR.ADVICEMESSAGE = Convert.ToString(dr["ADVICEMESSAGE"]);
                        FAILURE_HIST_CURSOR.FAIL_SAFE = Convert.ToString(dr["FAIL_SAFE"]);
                        FAILURE_HIST_CURSOR.REQUEST_GENERATED_FROM = Convert.ToString(dr["REQUEST_GENERATED_FROM"]);
                        FAILURE_HIST_CURSOR.LONGITUDE = Convert.ToString(dr["LONGITUDE"]);
                        FAILURE_HIST_CURSOR.LATITUDE = Convert.ToString(dr["LATITUDE"]);
                        FAILURE_HIST_CURSOR.MSIL_QA_INST = Convert.ToString(dr["MSIL_QA_INST"]);
                        FAILURE_HIST_CURSOR.MSIL_QA_INST_DATE = Convert.ToString(dr["MSIL_QA_INST_DATE"]);
                        //added on 28-dec-2021 by gagan
                        FAILURE_HIST_CURSOR.ticket_num = Convert.ToString(dr["ticket_num"]);
                        FAILURE_HIST_CURSOR.ADVICE_SUMMARY = Convert.ToString(dr["ADVICE_SUMMARY"]);
                        FAILURE_HIST_CURSOR.CASE_STATUS = Convert.ToString(dr["CASE_STATUS"]);
                        FAILURE_HIST_CURSOR.ASSISTANCE_STATUS = Convert.ToString(dr["ASSISTANCE_STATUS"]);
                        FAILURE_HIST_CURSOR.CASE_CLOSURE_DATE = Convert.ToString(dr["CASE_CLOSURE_DATE"]);
                        //added on 24-jan-2022 by gagan
                        FAILURE_HIST_CURSOR.ADVICE_MSG_SUMMARY = Convert.ToString(dr["ADVICE_MSG_SUMMARY"]);
                        //added on 1-march-2022 by gagan
                        FAILURE_HIST_CURSOR.VIN = Convert.ToString(dr["VIN"]);
                        FAILURE_HIST_CURSOR.model_name = Convert.ToString(dr["model_name"]);
                        FAILURE_HIST_CURSOR.customer_name = Convert.ToString(dr["customer_name"]);
                        FAILURE_HIST_CURSOR.Model_code = Convert.ToString(dr["Model_code"]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }

                    Typedetail = new GET_DRIVABLE_FAILURE_HIST();
                    Typedetail.FAILURE_HIST = FAILURE_HIST_LIST;
                    Typedetail.P_REG_NUM = cmd.Parameters["P_REG_NUM"].Value.ToString(); //consume input-output parameter
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }

                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETDRIVABLEFAILUREHIST", "PKG_TCU.SP_GET_DRIVABLE_FAILURE_HIST", "'P_REG_NUM': '" + P_REG_NUM + "'P_VIN': '" + P_VIN, "Success Code': '" + Convert.ToString(cmd.Parameters["P_ERR_CD"].Value)
    + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["P_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETDRIVABLEFAILUREHIST", "PKG_TCU.SP_GET_DRIVABLE_FAILURE_HIST", "'P_REG_NUM': '" + P_REG_NUM + "'P_VIN': '" + P_VIN, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GET_DRIVABLE_ADVICE
        /// <summary>
        /// GetDrivableAdvice For Suzuki Connect Gen-2
        /// </summary>
        /// <param name="P_REG_NUM"></param>
        /// <param name="P_FAILURE_ID"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_DRIVABLE_ADVICE> GETDRIVABLEADVICE(string P_REG_NUM, string P_FAILURE_ID)
        {

            BaseListReturnType<GET_DRIVABLE_ADVICE> response = new BaseListReturnType<GET_DRIVABLE_ADVICE>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            GET_DRIVABLE_ADVICE Typedetail = null;
            List<GET_DRIVABLE_ADVICE> Details = new List<GET_DRIVABLE_ADVICE>();
            List<DTCLIST> DTC_LIST = new List<DTCLIST>();
            List<NOTIFICATIONLIST> NOTIFICATION_LIST = new List<NOTIFICATIONLIST>();
            List<ADDINTERVIEWLIST> ADDINTERVIEW_LIST = new List<ADDINTERVIEWLIST>();
            List<EVENTLIST> EVENT_LIST = new List<EVENTLIST>();
            List<CHARTLIST> CHART_LIST = new List<CHARTLIST>();
            DTCLIST DTC_LIST_CURSOR;
            NOTIFICATIONLIST NOTIFICATION_LIST_CURSOR;
            ADDINTERVIEWLIST ADDINTERVIEW_LIST_CURSOR;
            EVENTLIST EVENT_LIST_CURSOR;
            CHARTLIST CHART_LIST_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_Drivable_Advice;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("P_REG_NUM", OracleType.VarChar, 20).Value = P_REG_NUM;
                cmd.Parameters.Add("P_FAILURE_ID", OracleType.VarChar, 50).Value = P_FAILURE_ID;
                //output varibale
                cmd.Parameters.Add("P_DTC_LIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_NOTIFICATION_LIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_ADDINTERVIEW_LIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_EVENT_LIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_CHART_LIST", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("p_FAIL_SAFE", OracleType.VarChar, 1500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["P_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["P_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["P_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<GET_DRIVABLE_ADVICE>();

                //check error 
                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_DTC_LIST"].Value;
                    while (dr.Read())
                    {
                        DTC_LIST_CURSOR = new DTCLIST();
                        DTC_LIST_CURSOR.Dtc = Convert.ToString(dr["Dtc"]);
                        DTC_LIST_CURSOR.DtcName = Convert.ToString(dr["DtcName"]);
                        DTC_LIST_CURSOR.DrivableLevel = Convert.ToString(dr["DrivableLevel"]);
                        DTC_LIST_CURSOR.WarningCode = Convert.ToString(dr["WarningCode"]);
                        DTC_LIST_CURSOR.WarningName = Convert.ToString(dr["WarningName"]);
                        DTC_LIST_CURSOR.ControllerName = Convert.ToString(dr["ControllerName"]);
                        DTC_LIST_CURSOR.OccurDatetime = Convert.ToString(dr["OccurDatetime"]);
                        DTC_LIST_CURSOR.ReceiveDatetime = Convert.ToString(dr["ReceiveDatetime"]);
                        DTC_LIST_CURSOR.DtcDescription = Convert.ToString(dr["DtcDescription"]);
                        DTC_LIST.Add(DTC_LIST_CURSOR);
                    }

                }


                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_NOTIFICATION_LIST"].Value;
                    while (dr.Read())
                    {
                        NOTIFICATION_LIST_CURSOR = new NOTIFICATIONLIST();
                        NOTIFICATION_LIST_CURSOR.NotificationMessage = Convert.ToString(dr["NotificationMessage"]);
                        NOTIFICATION_LIST_CURSOR.NotificationDatetime = Convert.ToString(dr["NotificationDatetime"]);
                        NOTIFICATION_LIST_CURSOR.NotificationWarningCode = Convert.ToString(dr["NotificationWarningCode"]);
                        NOTIFICATION_LIST_CURSOR.NotificationWarningName = Convert.ToString(dr["NotificationWarningName"]);
                        NOTIFICATION_LIST_CURSOR.NotificationOccurDatetime = Convert.ToString(dr["NotificationOccurDatetime"]);
                        NOTIFICATION_LIST_CURSOR.NotificationReceiveDatetime = Convert.ToString(dr["NotificationReceiveDatetime"]);
                        NOTIFICATION_LIST.Add(NOTIFICATION_LIST_CURSOR);
                    }

                }

                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_ADDINTERVIEW_LIST"].Value;
                    while (dr.Read())
                    {
                        ADDINTERVIEW_LIST_CURSOR = new ADDINTERVIEWLIST();
                        ADDINTERVIEW_LIST_CURSOR.InquiryID = Convert.ToString(dr["InquiryID"]);
                        ADDINTERVIEW_LIST_CURSOR.Question = Convert.ToString(dr["Question"]);
                        ADDINTERVIEW_LIST_CURSOR.Answer = Convert.ToString(dr["Answer"]);
                        ADDINTERVIEW_LIST.Add(ADDINTERVIEW_LIST_CURSOR);
                    }

                }


                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_EVENT_LIST"].Value;
                    while (dr.Read())
                    {
                        EVENT_LIST_CURSOR = new EVENTLIST();
                        EVENT_LIST_CURSOR.EVENT_TRIGGER_INFO = Convert.ToString(dr["EVENT_TRIGGER_INFO"]);
                        EVENT_LIST_CURSOR.EVENT_DATE_TIME = Convert.ToString(dr["EVENT_DATE_TIME"]);
                        EVENT_LIST_CURSOR.PRIMARY_USER_ACTION = Convert.ToString(dr["PRIMARY_USER_ACTION"]);
                        EVENT_LIST.Add(EVENT_LIST_CURSOR);
                    }

                }

                if (Convert.ToString(cmd.Parameters["P_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_CHART_LIST"].Value;
                    while (dr.Read())
                    {
                        CHART_LIST_CURSOR = new CHARTLIST();
                        CHART_LIST_CURSOR.REQUESTNO = Convert.ToString(dr["REQUESTNO"]);
                        CHART_LIST_CURSOR.CHARTSTATUS = Convert.ToString(dr["CHARTSTATUS"]);
                        CHART_LIST_CURSOR.OPERATIONRESULT = Convert.ToString(dr["OPERATIONRESULT"]);
                        CHART_LIST_CURSOR.DECISIONRESULT = Convert.ToString(dr["DECISIONRESULT"]);
                        CHART_LIST_CURSOR.DECISIONDATETIME = Convert.ToString(dr["DECISIONDATETIME"]);
                        CHART_LIST_CURSOR.MEMO = Convert.ToString(dr["MEMO"]);
                        CHART_LIST.Add(CHART_LIST_CURSOR);
                    }
                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }

                }

                Typedetail = new GET_DRIVABLE_ADVICE();
                Typedetail.DTCLIST = DTC_LIST;
                Typedetail.NOTIFICATIONLIST = NOTIFICATION_LIST;
                Typedetail.ADDINTERVIEWLIST = ADDINTERVIEW_LIST;
                Typedetail.EVENTLIST = EVENT_LIST;
                Typedetail.CHARTLIST = CHART_LIST;
                Typedetail.p_FAIL_SAFE = cmd.Parameters["p_FAIL_SAFE"].Value.ToString();
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETDRIVABLEADVICE", "PKG_TCU.SP_GET_DRIVABLE_ADVICE", "'P_REG_NUM': '" + P_REG_NUM + "'P_FAILURE_ID': '" + P_FAILURE_ID, "Success Code': '" + Convert.ToString(cmd.Parameters["P_ERR_CD"].Value)
     + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["P_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETDRIVABLEADVICE", "PKG_TCU.SP_GET_DRIVABLE_ADVICE", "'P_REG_NUM': '" + P_REG_NUM + "'P_FAILURE_ID': '" + P_FAILURE_ID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region SUGGESTED_REPAIR_PARTS
        /// <summary>
        /// GetDrivableAdvice For Suzuki Connect Gen-2
        /// </summary>
        /// <param name="PN_VIN"></param>
        /// <param name="PN_CAT_CD"></param>
        /// <param name="PN_SUBCAT_CD"></param>
        /// <returns></returns>
        public BaseListReturnType<SUGGESTED_REPAIR_PARTS> SUGGESTEDREPAIRPARTS(string PN_VIN, string PN_CAT_CD, string PN_SUBCAT_CD)
        {

            BaseListReturnType<SUGGESTED_REPAIR_PARTS> response = new BaseListReturnType<SUGGESTED_REPAIR_PARTS>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            SUGGESTED_REPAIR_PARTS Typedetail = null;
            List<SUGGESTED_REPAIR_PARTS> Details = new List<SUGGESTED_REPAIR_PARTS>();
            List<REPAIRPART> REPAIR_PART = new List<REPAIRPART>();
            List<REPLACEMENTDUEDTL> REPLACEMENT_DUE_DTL = new List<REPLACEMENTDUEDTL>();

            REPAIRPART REPAIR_PART_CURSOR;
            REPLACEMENTDUEDTL REPLACEMENT_DUE_DTL_CURSOR;


            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_suggested_repair_parts;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("PN_VIN", OracleType.VarChar, 22).Value = PN_VIN;
                cmd.Parameters.Add("PN_CAT_CD", OracleType.VarChar, 20).Value = PN_CAT_CD;
                cmd.Parameters.Add("PN_SUBCAT_CD", OracleType.VarChar, 20).Value = PN_SUBCAT_CD;
                //output varibale
                cmd.Parameters.Add("PO_REPAIR_PART_CURSOR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("P_REPLACEMENT_DUE_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<SUGGESTED_REPAIR_PARTS>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_REPAIR_PART_CURSOR"].Value;
                    while (dr.Read())
                    {
                        REPAIR_PART_CURSOR = new REPAIRPART();
                        REPAIR_PART_CURSOR.VIN = Convert.ToString(dr["VIN"]);
                        REPAIR_PART_CURSOR.TYPE = Convert.ToString(dr["TYPE"]);
                        REPAIR_PART_CURSOR.PART_NUM = Convert.ToString(dr["PART_NUM"]);
                        REPAIR_PART_CURSOR.PART_NAME = Convert.ToString(dr["PART_NAME"]);
                        REPAIR_PART_CURSOR.SRV_TYPE = Convert.ToString(dr["SRV_TYPE"]);
                        REPAIR_PART_CURSOR.REPLACEMENT_DATE = Convert.ToString(dr["REPLACEMENT_DATE"]);
                        REPAIR_PART_CURSOR.REPLACEMENT_MILEAGE = Convert.ToString(dr["REPLACEMENT_MILEAGE"]);
                        REPAIR_PART_CURSOR.DEALER_CD = Convert.ToString(dr["DEALER_CD"]);
                        REPAIR_PART_CURSOR.DEALER_NAME = Convert.ToString(dr["DEALER_NAME"]);
                        REPAIR_PART_CURSOR.DEALER_CITY = Convert.ToString(dr["DEALER_CITY"]);
                        REPAIR_PART.Add(REPAIR_PART_CURSOR);
                    }

                }

                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_REPLACEMENT_DUE_DTL"].Value;
                    while (dr.Read())
                    {
                        REPLACEMENT_DUE_DTL_CURSOR = new REPLACEMENTDUEDTL();
                        REPLACEMENT_DUE_DTL_CURSOR.REPLACEMENT_DUE_Date = Convert.ToString(dr["REPLACEMENT_DUE_Date"]);
                        REPLACEMENT_DUE_DTL_CURSOR.REPLACEMENT_DUE_MILEGE = Convert.ToString(dr["REPLACEMENT_DUE_MILEGE"]);
                        REPLACEMENT_DUE_DTL_CURSOR.QTY = Convert.ToString(dr["QTY"]);
                        REPLACEMENT_DUE_DTL.Add(REPLACEMENT_DUE_DTL_CURSOR);
                    }
                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }

                }

                Typedetail = new SUGGESTED_REPAIR_PARTS();
                Typedetail.REPAIRPART = REPAIR_PART;
                Typedetail.REPLACEMENTDUEDTL = REPLACEMENT_DUE_DTL;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("SUGGESTEDREPAIRPARTS", "PKG_JCO_1.SP_SUGGESTED_REPAIR_PARTS", "'PN_VIN': '" + PN_VIN + "'PN_CAT_CD': '" + PN_CAT_CD + "'PN_SUBCAT_CD': '" + PN_SUBCAT_CD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
      + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                // Logger.Log(ex.InnerException.ToString(), "SUGGESTED_REPAIR_PARTS");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("SUGGESTEDREPAIRPARTS", "PKG_JCO_1.SP_SUGGESTED_REPAIR_PARTS", "'PN_VIN': '" + PN_VIN + "'PN_CAT_CD': '" + PN_CAT_CD + "'PN_SUBCAT_CD': '" + PN_SUBCAT_CD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GET_QA_INS
        /// <summary>
        /// GET_QA_INS For Suzuki Connect Gen-2
        /// </summary>
        /// <param name="PN_REG"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_QA_INS> GETQAINS(string PN_REG)
        {

            BaseListReturnType<GET_QA_INS> response = new BaseListReturnType<GET_QA_INS>();

            GET_QA_INS Typedetail = null;
            List<GET_QA_INS> Details = new List<GET_QA_INS>();
            List<PLIST> P_LIST = new List<PLIST>();
            PLIST P_LIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_pkg_ftir_get_qa_ins;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_REG", OracleType.VarChar, 20).Value = PN_REG;
                //output varibale
                cmd.Parameters.Add("P_LIST_CURSOR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["P_LIST_CURSOR"].Value;
                    while (dr.Read())
                    {
                        P_LIST_CURSOR = new PLIST();
                        P_LIST_CURSOR.DTC = Convert.ToString(dr["DTC"]);
                        P_LIST_CURSOR.INS_FROM_MANUF = Convert.ToString(dr["INS_FROM_MANUF"]);
                        P_LIST.Add(P_LIST_CURSOR);
                    }

                    Typedetail = new GET_QA_INS();
                    Typedetail.PLIST = P_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }

                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETQAINS", "PKG_FTIR.SP_GET_QA_INS", "'PN_REG': '" + PN_REG, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
        + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_QA_INS");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETQAINS", "PKG_FTIR.SP_GET_QA_INS", "'PN_REG': '" + PN_REG, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion


        //START API WORK OF MTAB RECALL MODULE 1APRIL2022//
        #region RecallUserLogin
        /// <summary>
        /// RecallUserLogin
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        /// <param name="PN_PWD"></param>
        /// <returns></returns>
        public BaseListReturnType<LoginUserValidate> RecallUserLogin(string PN_USER_ID, string PN_PWD)
        {

            BaseListReturnType<LoginUserValidate> response = new BaseListReturnType<LoginUserValidate>();

            //LoginUserValidate Typedetail = null;
            //List<LoginUserValidate> Details = new List<LoginUserValidate>();
            List<LoginUserValidate> LoginMdl_LIST = new List<LoginUserValidate>();
            LoginUserValidate Login_Mdl;
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_user_validate2;
                cmd.CommandType = CommandType.StoredProcedure;
                OracleParameter InOutParam = new OracleParameter("PN_USER_ID", OracleType.VarChar, 100);
                InOutParam.Direction = ParameterDirection.InputOutput;
                InOutParam.Value = PN_USER_ID;
                cmd.Parameters.Add(InOutParam);
                cmd.Parameters.Add("PN_PWD", OracleType.VarChar, 50).Value = PN_PWD;
                //output varibale
                cmd.Parameters.Add("PO_PARENT_GROUP", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DEALER_MAP_CD", OracleType.Number, 5).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LOC_CD", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_COMP_FA", OracleType.VarChar, 4).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DEALER_NAME", OracleType.VarChar, 70).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DEALER_CODE", OracleType.VarChar, 13).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REGION_CD", OracleType.VarChar, 3).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REGION", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ZONE_CD", OracleType.VarChar, 2).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ZONE", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LOC_DESC", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_EMP_CD", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DESG_CD", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DESG_DESC", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ACCESS_FLAG", OracleType.VarChar, 3).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {

                    Login_Mdl = new LoginUserValidate();
                    Login_Mdl.DEALER_NAME = Convert.ToString(cmd.Parameters["PO_DEALER_NAME"].Value);
                    Login_Mdl.PARENT_GROUP = Convert.ToString(cmd.Parameters["PO_PARENT_GROUP"].Value);
                    Login_Mdl.DEALER_MAP_CD = Convert.ToString(cmd.Parameters["PO_DEALER_MAP_CD"].Value);
                    Login_Mdl.LOC_CD = Convert.ToString(cmd.Parameters["PO_LOC_CD"].Value);
                    Login_Mdl.COMP_FA = Convert.ToString(cmd.Parameters["PO_COMP_FA"].Value);
                    Login_Mdl.DEALER_CODE = Convert.ToString(cmd.Parameters["PO_DEALER_CODE"].Value);
                    Login_Mdl.REGION_CD = Convert.ToString(cmd.Parameters["PO_REGION_CD"].Value);
                    Login_Mdl.REGION = Convert.ToString(cmd.Parameters["PO_REGION"].Value);
                    Login_Mdl.ZONE_CD = Convert.ToString(cmd.Parameters["PO_ZONE_CD"].Value);
                    Login_Mdl.ZONE = Convert.ToString(cmd.Parameters["PO_ZONE"].Value);
                    Login_Mdl.LOC_DESC = Convert.ToString(cmd.Parameters["PO_LOC_DESC"].Value);
                    Login_Mdl.EMP_CD = Convert.ToString(cmd.Parameters["PO_EMP_CD"].Value);
                    Login_Mdl.DESG_CD = Convert.ToString(cmd.Parameters["PO_DESG_CD"].Value);
                    Login_Mdl.DESG_DESC = Convert.ToString(cmd.Parameters["PO_DESG_DESC"].Value);
                    Login_Mdl.ACCESS_FLAG = Convert.ToString(cmd.Parameters["PO_ACCESS_FLAG"].Value);
                    Login_Mdl.USER_ID = PN_USER_ID;
                    LoginMdl_LIST.Add(Login_Mdl);

                    //Typedetail = new LoginUserValidate();
                    // Typedetail.USER_ID = PN_USER_ID; //consume input-output parameter
                    //LoginMdl_LIST.Add(Typedetail);


                    con.Close();
                    response.code = (int)ServiceMassageCode.SUCCESS;
                    response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                    response.result = LoginMdl_LIST;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
                Logger.SuccessLogPrint("RecallUserLogin", "pkg_jco_1.sp_jco_user_validate2", "'PN_USER_ID': '" + PN_USER_ID + "'PN_PWD': '" + PN_PWD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
         + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("RecallUserLogin", "pkg_jco_1.sp_jco_user_validate2", "'PN_USER_ID': '" + PN_USER_ID + "'PN_PWD': '" + PN_PWD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region RecallPicDetail
        /// <summary>
        /// RecallPicDetail
        /// </summary>
        /// <param name="PN_VIN"></param>
        /// <param name="PN_RCAMP_PIC_FLAG"></param>
        /// <returns></returns>
        public BaseListReturnType<RecallPicDetail> RecallPicDetail(string PN_VIN, string PN_RCAMP_PIC_FLAG)
        {
            BaseListReturnType<RecallPicDetail> response = new BaseListReturnType<RecallPicDetail>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_set_rcamp_pic_dtl;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_VIN", OracleType.VarChar, 22).Value = PN_VIN;
                cmd.Parameters.Add("PN_RCAMP_PIC_FLAG", OracleType.VarChar, 20).Value = PN_RCAMP_PIC_FLAG;
                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
                Logger.SuccessLogPrint("RecallPicDetail", "pkg_jco_1.SP_SET_RCAMP_PIC_DTL", "'PN_VIN': '" + PN_VIN + "'PN_RCAMP_PIC_FLAG': '" + PN_RCAMP_PIC_FLAG, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
          + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("RecallPicDetail", "pkg_jco_1.SP_SET_RCAMP_PIC_DTL", "'PN_VIN': '" + PN_VIN + "'PN_RCAMP_PIC_FLAG': '" + PN_RCAMP_PIC_FLAG, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region RecallStatus
        /// <summary>
        /// RecallStatus
        /// </summary>
        /// <param name="pn_parent_group"></param>
        /// <param name="pn_dealer_map_cd"></param>
        ///  /// <param name="pn_loc_Cd"></param>
        ///   /// <param name="PN_RO_NUM"></param>
        ///    /// <param name="PN_RECALL_STATUS"></param>
        /// <returns></returns>
        public BaseListReturnType<RecallStatus> UpdateRecallStatus(string pn_parent_group, string pn_dealer_map_cd, string pn_loc_Cd, string PN_RO_NUM, string PN_RECALL_STATUS)
        {
            BaseListReturnType<RecallStatus> response = new BaseListReturnType<RecallStatus>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_update_recall_status;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_parent_group", OracleType.VarChar, 200).Value = pn_parent_group;
                cmd.Parameters.Add("pn_dealer_map_cd", OracleType.VarChar, 20).Value = pn_dealer_map_cd;
                cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 200).Value = pn_loc_Cd;
                cmd.Parameters.Add("PN_RO_NUM", OracleType.VarChar, 12).Value = PN_RO_NUM;
                cmd.Parameters.Add("PN_RECALL_STATUS", OracleType.VarChar, 1).Value = PN_RECALL_STATUS;
                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
                Logger.SuccessLogPrint("UpdateRecallStatus", "pkg_jco_1.SP_UPDATE_RECALL_STATUS", "'pn_parent_group': '" + pn_parent_group + "'pn_dealer_map_cd': '" + pn_dealer_map_cd +
                   "'pn_loc_Cd': '" + pn_loc_Cd + "'PN_RO_NUM': '" + PN_RO_NUM +
                   "'PN_RECALL_STATUS': '" + PN_RECALL_STATUS, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
           + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("UpdateRecallStatus", "pkg_jco_1.SP_UPDATE_RECALL_STATUS", "'pn_parent_group': '" + pn_parent_group + "'pn_dealer_map_cd': '" + pn_dealer_map_cd +
                  "'pn_loc_Cd': '" + pn_loc_Cd + "'PN_RO_NUM': '" + PN_RO_NUM +
                  "'PN_RECALL_STATUS': '" + PN_RECALL_STATUS, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        //START API WORK OF SCAN APPROVAL MODULE 4 MAY 2022//

        #region ScanUserLogin
        /// <summary>
        /// RecallStatus
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        /// <param name="PN_PWD"></param>
        /// <returns></returns>
        public BaseListReturnType<ScanLogin> ScanUserLogin(string PN_USER_ID, string PN_PWD)
        {
            BaseListReturnType<ScanLogin> response = new BaseListReturnType<ScanLogin>();
            //Validate Token
            List<ScanLogin> ScanMdl_LIST = new List<ScanLogin>();
            ScanLogin Scan_Mdl;
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_user_login_scan;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 100).Value = PN_USER_ID;
                cmd.Parameters.Add("PN_PWD", OracleType.VarChar, 50).Value = PN_PWD;
                //output varibale
                cmd.Parameters.Add("PO_REGION_CD", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REGION", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ZONE_CD", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ZONE", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LOC_DESC", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DESG_CD", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DESG_DESC", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CHANNEL", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_dealer_cd", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    Scan_Mdl = new ScanLogin();
                    Scan_Mdl.PO_REGION_CD = Convert.ToString(cmd.Parameters["PO_REGION_CD"].Value);
                    Scan_Mdl.PO_REGION = Convert.ToString(cmd.Parameters["PO_REGION"].Value);
                    Scan_Mdl.PO_ZONE_CD = Convert.ToString(cmd.Parameters["PO_ZONE_CD"].Value);
                    Scan_Mdl.PO_ZONE = Convert.ToString(cmd.Parameters["PO_ZONE"].Value);
                    Scan_Mdl.PO_LOC_DESC = Convert.ToString(cmd.Parameters["PO_LOC_DESC"].Value);
                    Scan_Mdl.PO_DESG_CD = Convert.ToString(cmd.Parameters["PO_DESG_CD"].Value);
                    Scan_Mdl.PO_DESG_DESC = Convert.ToString(cmd.Parameters["PO_DESG_DESC"].Value);
                    Scan_Mdl.PO_CHANNEL = Convert.ToString(cmd.Parameters["PO_CHANNEL"].Value);
                    Scan_Mdl.po_dealer_cd = Convert.ToString(cmd.Parameters["po_dealer_cd"].Value);
                    ScanMdl_LIST.Add(Scan_Mdl);

                    con.Close();
                    response.code = (int)ServiceMassageCode.SUCCESS;
                    response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                    response.result = ScanMdl_LIST;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
                Logger.SuccessLogPrint("ScanUserLogin", "pkg_jco_1.SP_JCO_USER_LOGIN_SCAN", "'PN_USER_ID': '" + PN_USER_ID + "'PN_PWD': '" + PN_PWD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
            + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("ScanUserLogin", "pkg_jco_1.SP_JCO_USER_LOGIN_SCAN", "'PN_USER_ID': '" + PN_USER_ID + "'PN_PWD': '" + PN_PWD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region ScanApprovalStatus
        /// <summary>
        /// RecallStatus
        /// </summary>
        /// <param name="pn_parent_group"></param>
        /// <param name="pn_dealer_map_cd"></param>
        ///  /// <param name="pn_loc_Cd"></param>
        ///   /// <param name="PN_JOBCARD_NUM"></param>
        ///    /// <param name="PN_SCAN_APPR_STATUS"></param>
        ///      /// <param name="PN_SCAN_USER_ID"></param>
        /// <returns></returns>
        public BaseListReturnType<ScanApprovalStatus> ScanApprovalStatus(string pn_parent_group, string pn_dealer_map_cd, string pn_loc_Cd, string PN_JOBCARD_NUM, string PN_SCAN_APPR_STATUS, string PN_SCAN_USER_ID)
        {
            BaseListReturnType<ScanApprovalStatus> response = new BaseListReturnType<ScanApprovalStatus>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_set_scan_approval_status;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_parent_group", OracleType.VarChar, 200).Value = pn_parent_group;
                cmd.Parameters.Add("pn_dealer_map_cd", OracleType.VarChar, 20).Value = pn_dealer_map_cd;
                cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 200).Value = pn_loc_Cd;
                cmd.Parameters.Add("PN_JOBCARD_NUM", OracleType.VarChar, 12).Value = PN_JOBCARD_NUM;
                cmd.Parameters.Add("PN_SCAN_APPR_STATUS", OracleType.VarChar, 100).Value = PN_SCAN_APPR_STATUS;
                cmd.Parameters.Add("PN_SCAN_USER_ID", OracleType.VarChar, 100).Value = PN_SCAN_USER_ID;
                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
                Logger.SuccessLogPrint("ScanApprovalStatus", "pkg_jco_1.SP_SET_SCAN_APPROVAL_STATUS", "'pn_parent_group': '" + pn_parent_group + "'pn_dealer_map_cd': '" + pn_dealer_map_cd +
                    "'pn_loc_Cd': '" + pn_loc_Cd + "'PN_JOBCARD_NUM': '" + PN_JOBCARD_NUM +
                    "'PN_SCAN_APPR_STATUS': '" + PN_SCAN_APPR_STATUS + "'PN_SCAN_USER_ID': '" + PN_SCAN_USER_ID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
            + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("ScanApprovalStatus", "pkg_jco_1.SP_SET_SCAN_APPROVAL_STATUS", "'pn_parent_group': '" + pn_parent_group + "'pn_dealer_map_cd': '" + pn_dealer_map_cd +
                    "'pn_loc_Cd': '" + pn_loc_Cd + "'PN_JOBCARD_NUM': '" + PN_JOBCARD_NUM +
                    "'PN_SCAN_APPR_STATUS': '" + PN_SCAN_APPR_STATUS + "'PN_SCAN_USER_ID': '" + PN_SCAN_USER_ID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region MTAB CCP
        /// <summary>
        /// Get_CCP_Price
        /// </summary>
        /// <param name="pn_pmc"></param>
        /// <param name="pn_reg"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_CCP_PRICE> Get_CCP_Price(string pn_pmc, string pn_reg)
        {

            BaseListReturnType<GET_CCP_PRICE> response = new BaseListReturnType<GET_CCP_PRICE>();

            GET_CCP_PRICE Typedetail = null;
            List<GET_CCP_PRICE> Details = new List<GET_CCP_PRICE>();
            List<CCP_LIST> P_LIST = new List<CCP_LIST>();
            CCP_LIST P_LIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_ccp_list;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_pmc", OracleType.Number, 1).Value = Convert.ToInt32(pn_pmc);
                cmd.Parameters.Add("pn_reg", OracleType.VarChar, 20).Value = pn_reg;
                //output varibale
                cmd.Parameters.Add("po_ccp_dtl", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_ccp_dtl"].Value;
                    while (dr.Read())
                    {
                        P_LIST_CURSOR = new CCP_LIST();
                        P_LIST_CURSOR.ccp_cd = Convert.ToString(dr["ccp_cd"]);
                        P_LIST_CURSOR.ccp_desc = Convert.ToString(dr["ccp_desc"]);
                        P_LIST_CURSOR.price = Convert.ToString(dr["price"]);
                        P_LIST.Add(P_LIST_CURSOR);
                    }

                    Typedetail = new GET_CCP_PRICE();
                    Typedetail.CCPLIST = P_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }

                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("Get_CCP_Price", "PKG_ADDON_SALE.SP_CCP_LIST", "'pn_pmc': '" + pn_pmc + "'pn_reg': '" + pn_reg, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value)
              + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_QA_INS");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("Get_CCP_Price", "PKG_ADDON_SALE.SP_CCP_LIST", "'pn_pmc': '" + pn_pmc + "'pn_reg': '" + pn_reg, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        //MTAB New Insert All Details API 19 JULY 2022

        #region NewInsertAllDetails
        /// <summary>
        /// NewInsertAllDetails
        /// </summary>
        /// <param name="RegNum"></param>
        /// <param name="UserID"></param>
        /// <param name="srv_cat_cd"></param>
        /// <param name="sub_srv_type_cd"></param>
        /// <param name="OMR"></param>
        /// <param name="promised_date"></param>
        /// <param name="checkin_date"></param>
        /// <param name="sa_adv"></param>
        /// <param name="tech_adv"></param>
        /// <param name="bay_cd"></param>
        /// <param name="group_cd"></param>
        /// <param name="omr_change"></param>
        /// <param name="vts_card_num"></param>
        /// <param name="tech_cd"></param>
        /// <param name="menu_ins_refcur"></param>
        /// <param name="demand_ins_refcur"></param>
        /// <param name="part_ins_refcur"></param>
        /// <param name="labor_ins_refcur"></param>
        /// <param name="inv_ins_refcur"></param>
        /// <param name="mcard_ins_refcur"></param>
        /// <param name="unapprv_fitment_refcur"></param>
        /// <param name="estm_refcur"></param>
        /// <param name="Pick_Typ"></param>
        /// <param name="Pick_Dat"></param>
        /// <param name="Pick_Flag"></param>
        /// <param name="Pick_Loc"></param>
        /// <param name="Pick_Drv"></param>
        /// <param name="Pick_Rem"></param>
        /// <param name="mms_num"></param>
        /// <param name="Emailid"></param>
        /// <param name="prob_str"></param>
        /// <param name="pn_part_est_amt"></param>
        /// <param name="pn_opr_est_amt"></param>
        /// <param name="rf_tag_num"></param>
        /// <param name="fcs_num"></param>
        /// <param name="qr_code"></param>
        /// <param name="cust_Remarks"></param>
        /// <param name="dlr_Remarks"></param>
        /// <param name="approval_Status"></param>
        /// <param name="ew_Flag"></param>
        /// <param name="ew_Type"></param>
        /// <param name="mcp_Flag"></param>
        /// <param name="mcp_Pckg"></param>
        /// <param name="wash_Type"></param>
        /// <param name="mms_Address"></param>
        /// <param name="mms_City"></param>
        /// <param name="mms_District"></param>
        /// <param name="mms_State"></param>
        /// <param name="mms_Pin"></param>
        /// <param name="audioCnt"></param>
        /// <param name="jc_scan_type"></param>
        /// <param name="ocas_cnt"></param>
        /// <param name="save_cnt"></param>
        /// <param name="sent_cnt"></param>
        /// <param name="final_Inspection"></param>
        /// <param name="c_measure_refcur"></param>
        /// <param name="BILLABLE_TYPE"></param>
        /// <param name="MI_NMI"></param>
        /// <param name="PANEL"></param>
        /// <param name="CUTTING_WELDING_YN"></param>
        /// <param name="PART_REPLACE_YN"></param>
        /// <param name="ENGINE_TRANSMISSION_YN"></param>
        /// <param name="FOR_CD"></param>
        /// <param name="SUGGESTED_PROMISE_DATE"></param>
        /// <param name="Tyres_Depth"></param>
        /// <param name="Battery_Condition"></param>
        /// <param name="Find_Id"></param>
        /// <param name="Recall_Type"></param>
        /// <param name="pn_ccp_yn"></param>
        /// <param name="pn_ccp_num"></param>
        /// <returns></returns>
        public BaseListReturnType<NewInsertAllDetailsOutput> NewInsertAllDetails(NewInsertAllDetailsInput mdl)
        {
            NewInsertAllDetailsOutput Typedetail = null;
            List<NewInsertAllDetailsOutput> Details = new List<NewInsertAllDetailsOutput>();
            // String Result = String.Empty;
            BaseListReturnType<NewInsertAllDetailsOutput> response = new BaseListReturnType<NewInsertAllDetailsOutput>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_insert_dtl;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_reg_num", OracleType.VarChar, 20).Value = Convert.ToString(mdl.RegNum);
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = Convert.ToString(mdl.UserID);
                cmd.Parameters.Add("pn_srv_cat_cd", OracleType.VarChar, 20).Value = Convert.ToString(mdl.srv_cat_cd);
                cmd.Parameters.Add("pn_sub_srv_type_cd", OracleType.VarChar, 20).Value = Convert.ToString(mdl.sub_srv_type_cd);
                cmd.Parameters.Add("pn_omr", OracleType.Int32, 8).Value = Convert.ToInt32(mdl.OMR);

                if (mdl.promised_date == "")
                    cmd.Parameters.Add("pn_promised_date", OracleType.VarChar).Value = DBNull.Value;//Convert.ToDateTime(promised_date);
                else
                    cmd.Parameters.Add("pn_promised_date", OracleType.VarChar).Value = Convert.ToString(mdl.promised_date);//Convert.ToDateTime(promised_date);

                if (mdl.checkin_date == "")
                    cmd.Parameters.Add("pn_checkin_date", OracleType.VarChar).Value = DBNull.Value;//Convert.ToDateTime(checkin_date);
                else
                    cmd.Parameters.Add("pn_checkin_date", OracleType.VarChar).Value = Convert.ToString(mdl.checkin_date);//Convert.ToDateTime(checkin_date);

                cmd.Parameters.Add("pn_sa_adv", OracleType.VarChar).Value = Convert.ToString(mdl.sa_adv);
                cmd.Parameters.Add("pn_tech_adv", OracleType.VarChar).Value = Convert.ToString(mdl.tech_adv);
                cmd.Parameters.Add("pn_bay_cd", OracleType.VarChar, 20).Value = Convert.ToString(mdl.bay_cd);
                cmd.Parameters.Add("pn_group_cd", OracleType.VarChar, 20).Value = Convert.ToString(mdl.group_cd);
                cmd.Parameters.Add("pn_omr_change", OracleType.VarChar, 20).Value = Convert.ToString(mdl.omr_change);
                cmd.Parameters.Add("pn_vts_card_num", OracleType.Int32, 4).Value = Convert.ToInt32(mdl.vts_card_num);
                cmd.Parameters.Add("pn_tech_cd", OracleType.VarChar, 20).Value = Convert.ToString(mdl.tech_cd);



                cmd.Parameters.Add("pn_menu_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.menu_ins_refcur);
                cmd.Parameters.Add("pn_demand_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.demand_ins_refcur);
                cmd.Parameters.Add("pn_part_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.part_ins_refcur);
                cmd.Parameters.Add("pn_labor_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.labor_ins_refcur);
                cmd.Parameters.Add("pn_inv_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.inv_ins_refcur);
                cmd.Parameters.Add("pn_mcard_ins_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.mcard_ins_refcur);
                cmd.Parameters.Add("pn_unapprv_fit_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.unapprv_fitment_refcur);
                cmd.Parameters.Add("pn_estm_str", OracleType.VarChar, 3600).Value = Convert.ToString(mdl.estm_refcur);
                cmd.Parameters.Add("pn_pickup_type", OracleType.VarChar, 25).Value = Convert.ToString(mdl.Pick_Typ);

                if (mdl.Pick_Dat == "")
                    cmd.Parameters.Add("pn_pickup_date", OracleType.VarChar).Value = DBNull.Value;//Convert.ToDateTime(Pick_Dat);
                else
                    cmd.Parameters.Add("pn_pickup_date", OracleType.VarChar).Value = Convert.ToString(mdl.Pick_Dat);

                cmd.Parameters.Add("pn_free_pikcup_flag", OracleType.VarChar, 1).Value = Convert.ToString(mdl.Pick_Flag);
                cmd.Parameters.Add("pn_pickup_loc_cd", OracleType.VarChar, 5).Value = Convert.ToString(mdl.Pick_Loc);
                cmd.Parameters.Add("pn_pickup_driver", OracleType.VarChar, 30).Value = Convert.ToString(mdl.Pick_Drv);
                cmd.Parameters.Add("pn_pikcup_remarks", OracleType.VarChar, 20).Value = Convert.ToString(mdl.Pick_Rem);
                cmd.Parameters.Add("pn_mms_num", OracleType.VarChar, 20).Value = Convert.ToString(mdl.mms_num);
                cmd.Parameters.Add("pn_email_id", OracleType.VarChar, 5).Value = Convert.ToString(mdl.Emailid);
                //new param added
                cmd.Parameters.Add("pn_prob_str", OracleType.VarChar, 500).Value = Convert.ToString(mdl.prob_str);
                //two new params added

                cmd.Parameters.Add("pn_part_est_amt", OracleType.Double).Value = Convert.ToDouble(mdl.pn_part_est_amt);
                cmd.Parameters.Add("pn_opr_est_amt", OracleType.Double).Value = Convert.ToDouble(mdl.pn_opr_est_amt);
                cmd.Parameters.Add("PN_RFTAG_NUM", OracleType.VarChar, 500).Value = Convert.ToString(mdl.rf_tag_num);
                cmd.Parameters.Add("PN_FSC_NUM", OracleType.VarChar, 500).Value = Convert.ToString(mdl.fcs_num);
                cmd.Parameters.Add("PN_QR_CODE", OracleType.VarChar, 500).Value = Convert.ToString(mdl.qr_code);
                cmd.Parameters.Add("PN_CUST_REMARKS", OracleType.VarChar, 500).Value = mdl.cust_Remarks;
                cmd.Parameters.Add("PN_DLR_REMARKS", OracleType.VarChar, 500).Value = mdl.dlr_Remarks;
                cmd.Parameters.Add("PN_APPRV_STATUS", OracleType.VarChar, 500).Value = mdl.approval_Status;
                cmd.Parameters.Add("PN_EW_INTRST_YN", OracleType.VarChar, 10).Value = mdl.ew_Flag;
                cmd.Parameters.Add("PN_EW_INTRST_TYPE", OracleType.VarChar, 500).Value = mdl.ew_Type;
                cmd.Parameters.Add("PN_MCP_INTRST_YN", OracleType.VarChar, 10).Value = mdl.mcp_Flag;
                cmd.Parameters.Add("PN_MCP_INTRST_PKG", OracleType.VarChar, 500).Value = mdl.mcp_Pckg;
                cmd.Parameters.Add("PN_WASH_TYPE", OracleType.VarChar, 500).Value = mdl.wash_Type;


                if (string.IsNullOrEmpty(mdl.mms_Address))
                    cmd.Parameters.Add("PN_MMS_ADDRESS", OracleType.VarChar, 100).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_MMS_ADDRESS", OracleType.VarChar, 100).Value = Convert.ToString(mdl.mms_Address);

                if (string.IsNullOrEmpty(mdl.mms_City))
                    cmd.Parameters.Add("PN_MMS_CITY", OracleType.VarChar, 50).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_MMS_CITY", OracleType.VarChar, 50).Value = Convert.ToString(mdl.mms_City);

                if (string.IsNullOrEmpty(mdl.mms_District))
                    cmd.Parameters.Add("PN_MMS_DISTRICT", OracleType.VarChar, 50).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_MMS_DISTRICT", OracleType.VarChar, 50).Value = Convert.ToString(mdl.mms_District);

                if (string.IsNullOrEmpty(mdl.mms_State))
                    cmd.Parameters.Add("PN_MMS_STATE", OracleType.VarChar, 50).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_MMS_STATE", OracleType.VarChar, 50).Value = Convert.ToString(mdl.mms_State);

                if (string.IsNullOrEmpty(mdl.mms_Pin))
                    cmd.Parameters.Add("PN_MMS_PIN", OracleType.VarChar, 6).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_MMS_PIN", OracleType.VarChar, 6).Value = Convert.ToString(mdl.mms_Pin);

                cmd.Parameters.Add("PN_AUDIO_COUNT", OracleType.Int32, 25).Value = mdl.audioCnt;
                if (string.IsNullOrEmpty(mdl.jc_scan_type))
                    cmd.Parameters.Add("PN_JC_SCAN_TYPE", OracleType.VarChar).Value = DBNull.Value;
                else
                    cmd.Parameters.Add("PN_JC_SCAN_TYPE", OracleType.VarChar).Value = mdl.jc_scan_type;

                cmd.Parameters.Add("PN_OCAS_CNT", OracleType.Int32, 8).Value = mdl.ocas_cnt;
                cmd.Parameters.Add("PN_SAVE_CNT", OracleType.Int32, 8).Value = mdl.save_cnt;
                cmd.Parameters.Add("PN_SENT_CNT", OracleType.Int32, 8).Value = mdl.sent_cnt;
                cmd.Parameters.Add("PN_Counter_Measure_DTL", OracleType.VarChar, 4000).Value = mdl.c_measure_refcur;
                cmd.Parameters.Add("PN_BILLABLE_TYPE", OracleType.VarChar, 1).Value = mdl.BILLABLE_TYPE;
                cmd.Parameters.Add("PN_MI_NMI", OracleType.VarChar, 3).Value = mdl.MI_NMI;
                //cmd.Parameters.Add("PN_PANEL", OracleType.Int32, 2, ParameterDirection.Input).Value = Convert.ToInt32(PANEL);
                cmd.Parameters.Add("PN_PANEL", OracleType.VarChar, 2).Value = mdl.PANEL;
                cmd.Parameters.Add("PN_CUTTING_WELDING_YN", OracleType.VarChar, 1).Value = mdl.CUTTING_WELDING_YN;
                cmd.Parameters.Add("PN_PART_REPLACE_YN", OracleType.VarChar, 1).Value = mdl.PART_REPLACE_YN;
                cmd.Parameters.Add("PN_ENGINE_TRANSMISSION_YN", OracleType.VarChar, 1).Value = mdl.ENGINE_TRANSMISSION_YN;
                if (!string.IsNullOrEmpty(mdl.SUGGESTED_PROMISE_DATE))
                    cmd.Parameters.Add("PN_SUGGESTED_PROMISE_DATE", OracleType.VarChar).Value = mdl.SUGGESTED_PROMISE_DATE;
                else
                    cmd.Parameters.Add("PN_SUGGESTED_PROMISE_DATE", OracleType.VarChar).Value = DBNull.Value;
                cmd.Parameters.Add("PN_Tire_Depth", OracleType.VarChar, 4000).Value = mdl.Tyres_Depth;
                cmd.Parameters.Add("PN_Battery_Condition", OracleType.VarChar, 20).Value = mdl.Battery_Condition;
                cmd.Parameters.Add("PN_FIND_ID", OracleType.VarChar, 20).Value = mdl.Find_Id;
                cmd.Parameters.Add("PN_RECALL_TYPE", OracleType.VarChar, 20).Value = mdl.Recall_Type;
                //Added PN_CNG_TESTING_DUE , PN_CNG_TESTING_DATE by gagan sharma 4JAN2023
                cmd.Parameters.Add("PN_CNG_TESTING_DUE", OracleType.VarChar, 1).Value = mdl.CNG_TESTING_DUE;//Possible values Y & N
                if (mdl.CNG_TESTING_DATE == "")
                    cmd.Parameters.Add("PN_CNG_TESTING_DATE", OracleType.VarChar).Value = DBNull.Value;//Aded on 04-01-2023
                else
                    cmd.Parameters.Add("PN_CNG_TESTING_DATE", OracleType.VarChar).Value = mdl.CNG_TESTING_DATE;
                cmd.Parameters.Add("po_job_card_num", OracleType.VarChar, 12).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 3600).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PN_FINAL_INSPECTION", OracleType.VarChar, 1).Value = mdl.final_Inspection;
                cmd.Parameters.Add("pn_ccp_yn", OracleType.VarChar, 1).Value = mdl.pn_ccp_yn;
                cmd.Parameters.Add("pn_ccp_num", OracleType.VarChar, 12).Value = mdl.pn_ccp_num;
                cmd.CommandType = CommandType.StoredProcedure;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                //if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                //{
                //    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                //    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                //    response.result = null;
                //    con.Close();
                //    return response;
                //}

                Typedetail = new NewInsertAllDetailsOutput();
                Typedetail.po_job_card_num = cmd.Parameters["po_job_card_num"].Value.ToString();
                Details.Add(Typedetail);
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("NewInsertAllDetails", "sp_jco_insert_dtl", "'RegNum': '" + mdl.RegNum + "', 'pn_user_id': '" + mdl.UserID + "', 'pn_srv_cat_cd':'" + mdl.srv_cat_cd + "','pn_sub_srv_type_cd':'" + mdl.sub_srv_type_cd
               + "','pn_omr':'" + mdl.OMR + "','pn_promised_date':'" + mdl.promised_date + "','pn_checkin_date':'" + mdl.checkin_date + "','pn_sa_adv':'" + mdl.sa_adv + "','pn_tech_adv':'"
               + mdl.tech_adv + "','pn_bay_cd':'" + mdl.bay_cd + "','pn_group_cd':'" + mdl.group_cd + "','pn_omr_change':'" + mdl.omr_change + "','pn_vts_card_num':'" + mdl.vts_card_num
               + "','pn_tech_cd':'" + mdl.tech_cd + "','pn_menu_ins_str':'" + mdl.menu_ins_refcur + "','pn_demand_ins_str':'" + mdl.demand_ins_refcur + "','pn_part_ins_str':'"
               + mdl.part_ins_refcur + "','pn_labor_ins_str':'" + mdl.labor_ins_refcur + "','pn_inv_ins_str':'" + mdl.inv_ins_refcur + "','pn_mcard_ins_str':'" + mdl.mcard_ins_refcur
               + "','pn_unapprv_fit_str':'" + mdl.unapprv_fitment_refcur + "','pn_estm_str':'" + mdl.estm_refcur + "','pn_pickup_type':'" + mdl.Pick_Typ + "','pn_pickup_date':'" + mdl.Pick_Dat
               + "','pn_free_pikcup_flag':'" + mdl.Pick_Flag + "','pn_pickup_loc_cd':'" + mdl.Pick_Loc + "','pn_pickup_driver':'" + mdl.Pick_Drv + "','pn_pikcup_remarks':'" + mdl.Pick_Rem
               + "','pn_mms_num':'" + mdl.mms_num + "','pn_email_id':'" + mdl.Emailid + "','pn_prob_str':'" + mdl.prob_str + "','pn_part_est_amt':'" + mdl.pn_part_est_amt + "','pn_opr_est_amt':'"
               + mdl.pn_opr_est_amt + "','PN_RFTAG_NUM':'" + mdl.rf_tag_num + "','PN_FSC_NUM':'" + mdl.fcs_num + "','PN_QR_CODE':'" + mdl.qr_code + "','PN_CUST_REMARKS':'" + mdl.cust_Remarks
               + "','PN_DLR_REMARKS':'" + mdl.dlr_Remarks + "','PN_APPRV_STATUS':'" + mdl.approval_Status + "','PN_EW_INTRST_YN':'" + mdl.ew_Flag + "','PN_EW_INTRST_TYPE':'" + mdl.ew_Type
               + "','PN_MCP_INTRST_YN':'" + mdl.mcp_Flag + "','PN_MCP_INTRST_PKG':'" + mdl.mcp_Pckg + "','PN_WASH_TYPE':'" + mdl.wash_Type + "','PN_MMS_ADDRESS':'" + mdl.mms_Address
               + "','PN_MMS_CITY':'" + mdl.mms_City + "','PN_MMS_DISTRICT':'" + mdl.mms_District + "','PN_MMS_STATE':'" + mdl.mms_State + "','PN_MMS_PIN':'" + mdl.mms_Pin + "','PN_AUDIO_COUNT':'"
               + mdl.audioCnt + "','PN_JC_SCAN_TYPE':'" + mdl.jc_scan_type + "','PN_OCAS_CNT':'" + mdl.ocas_cnt + "','PN_SAVE_CNT':'" + mdl.save_cnt + "','PN_SENT_CNT':'" + mdl.sent_cnt
               + "','PN_Counter_Measure_DTL':'" + mdl.c_measure_refcur + "','PN_BILLABLE_TYPE':'" + mdl.BILLABLE_TYPE + "','PN_MI_NMI':'" + mdl.MI_NMI + "','PN_PANEL':'" + mdl.PANEL
               + "','PN_CUTTING_WELDING_YN':'" + mdl.CUTTING_WELDING_YN + "','PN_PART_REPLACE_YN':'" + mdl.PART_REPLACE_YN + "','PN_ENGINE_TRANSMISSION_YN':'"
               + mdl.ENGINE_TRANSMISSION_YN + "','PN_SUGGESTED_PROMISE_DATE':'" + mdl.SUGGESTED_PROMISE_DATE + "','PN_Tire_Depth':'" + mdl.Tyres_Depth + "','PN_Battery_Condition':'"
               + mdl.Battery_Condition + "','PN_FIND_ID':'" + mdl.Find_Id + "','PN_RECALL_TYPE':'" + mdl.Recall_Type + "','pn_ccp_yn':'" + mdl.pn_ccp_yn + "','pn_ccp_num':'" + mdl.pn_ccp_num + "'CNG_TESTING_DUE':'" + mdl.CNG_TESTING_DUE + "', 'CNG_TESTING_DATE':'" + mdl.CNG_TESTING_DATE, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("NewInsertAllDetails", "sp_jco_insert_dtl", "'RegNum': '" + mdl.RegNum + "', 'pn_user_id': '" + mdl.UserID + "', 'pn_srv_cat_cd':'" + mdl.srv_cat_cd + "','pn_sub_srv_type_cd':'" + mdl.sub_srv_type_cd
                + "','pn_omr':'" + mdl.OMR + "','pn_promised_date':'" + mdl.promised_date + "','pn_checkin_date':'" + mdl.checkin_date + "','pn_sa_adv':'" + mdl.sa_adv + "','pn_tech_adv':'"
                + mdl.tech_adv + "','pn_bay_cd':'" + mdl.bay_cd + "','pn_group_cd':'" + mdl.group_cd + "','pn_omr_change':'" + mdl.omr_change + "','pn_vts_card_num':'" + mdl.vts_card_num
                + "','pn_tech_cd':'" + mdl.tech_cd + "','pn_menu_ins_str':'" + mdl.menu_ins_refcur + "','pn_demand_ins_str':'" + mdl.demand_ins_refcur + "','pn_part_ins_str':'"
                + mdl.part_ins_refcur + "','pn_labor_ins_str':'" + mdl.labor_ins_refcur + "','pn_inv_ins_str':'" + mdl.inv_ins_refcur + "','pn_mcard_ins_str':'" + mdl.mcard_ins_refcur
                + "','pn_unapprv_fit_str':'" + mdl.unapprv_fitment_refcur + "','pn_estm_str':'" + mdl.estm_refcur + "','pn_pickup_type':'" + mdl.Pick_Typ + "','pn_pickup_date':'" + mdl.Pick_Dat
                + "','pn_free_pikcup_flag':'" + mdl.Pick_Flag + "','pn_pickup_loc_cd':'" + mdl.Pick_Loc + "','pn_pickup_driver':'" + mdl.Pick_Drv + "','pn_pikcup_remarks':'" + mdl.Pick_Rem
                + "','pn_mms_num':'" + mdl.mms_num + "','pn_email_id':'" + mdl.Emailid + "','pn_prob_str':'" + mdl.prob_str + "','pn_part_est_amt':'" + mdl.pn_part_est_amt + "','pn_opr_est_amt':'"
                + mdl.pn_opr_est_amt + "','PN_RFTAG_NUM':'" + mdl.rf_tag_num + "','PN_FSC_NUM':'" + mdl.fcs_num + "','PN_QR_CODE':'" + mdl.qr_code + "','PN_CUST_REMARKS':'" + mdl.cust_Remarks
                + "','PN_DLR_REMARKS':'" + mdl.dlr_Remarks + "','PN_APPRV_STATUS':'" + mdl.approval_Status + "','PN_EW_INTRST_YN':'" + mdl.ew_Flag + "','PN_EW_INTRST_TYPE':'" + mdl.ew_Type
                + "','PN_MCP_INTRST_YN':'" + mdl.mcp_Flag + "','PN_MCP_INTRST_PKG':'" + mdl.mcp_Pckg + "','PN_WASH_TYPE':'" + mdl.wash_Type + "','PN_MMS_ADDRESS':'" + mdl.mms_Address
                + "','PN_MMS_CITY':'" + mdl.mms_City + "','PN_MMS_DISTRICT':'" + mdl.mms_District + "','PN_MMS_STATE':'" + mdl.mms_State + "','PN_MMS_PIN':'" + mdl.mms_Pin + "','PN_AUDIO_COUNT':'"
                + mdl.audioCnt + "','PN_JC_SCAN_TYPE':'" + mdl.jc_scan_type + "','PN_OCAS_CNT':'" + mdl.ocas_cnt + "','PN_SAVE_CNT':'" + mdl.save_cnt + "','PN_SENT_CNT':'" + mdl.sent_cnt
                + "','PN_Counter_Measure_DTL':'" + mdl.c_measure_refcur + "','PN_BILLABLE_TYPE':'" + mdl.BILLABLE_TYPE + "','PN_MI_NMI':'" + mdl.MI_NMI + "','PN_PANEL':'" + mdl.PANEL
                + "','PN_CUTTING_WELDING_YN':'" + mdl.CUTTING_WELDING_YN + "','PN_PART_REPLACE_YN':'" + mdl.PART_REPLACE_YN + "','PN_ENGINE_TRANSMISSION_YN':'"
                + mdl.ENGINE_TRANSMISSION_YN + "','PN_SUGGESTED_PROMISE_DATE':'" + mdl.SUGGESTED_PROMISE_DATE + "','PN_Tire_Depth':'" + mdl.Tyres_Depth + "','PN_Battery_Condition':'"
                + mdl.Battery_Condition + "','PN_FIND_ID':'" + mdl.Find_Id + "','PN_RECALL_TYPE':'" + mdl.Recall_Type + "','pn_ccp_yn':'" + mdl.pn_ccp_yn + "','pn_ccp_num':'" + mdl.pn_ccp_num + "'CNG_TESTING_DUE':'" + mdl.CNG_TESTING_DUE + "', 'CNG_TESTING_DATE':'" + mdl.CNG_TESTING_DATE, ex);
            }

            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        /// <summary>
        /// Null Validator
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        protected string NullValidator(string parameter)
        {
            string OutputParameter = string.Empty;
            if (parameter == "null")
                OutputParameter = "\"\"";
            else
                OutputParameter = "\"" + parameter + "\"";
            return OutputParameter;
        }
        #endregion

        //START API WORK OF MTAB JC BILLING MODULE 18 JULY 2022//

        #region GETJCBILLDTL
        /// <summary>
        ///  To get details by Jobcard or Bill Number
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        ///  <param name="PN_JC_NO"></param>
        ///   ///  <param name="PO_BILL_NUM"></param>
        /// <returns></returns>

        public BaseListReturnType<GET_JC_BILL_DTL> GETJCBILLDTL(string PN_USER_ID, string PN_JC_NO, string PO_BILL_NUM)
        {
            BaseListReturnType<GET_JC_BILL_DTL> response = new BaseListReturnType<GET_JC_BILL_DTL>();
            GET_JC_BILL_DTL Typedetail = null;
            List<GET_JC_BILL_DTL> Details = new List<GET_JC_BILL_DTL>();
            List<PO_PART_REFCUR> PO_PART_REFCUR_LIST = new List<PO_PART_REFCUR>();
            PO_PART_REFCUR PO_PART_REFCUR_CURSOR;
            List<PO_LABOUR_REFCUR> PO_LABOUR_REFCUR_LIST = new List<PO_LABOUR_REFCUR>();
            PO_LABOUR_REFCUR PO_LABOUR_REFCUR_CURSOR;
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jc_bill_dtl;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                OracleParameter input_JC_No = cmd.Parameters.Add("PN_JC_NO", OracleType.VarChar, 12);
                input_JC_No.Direction = ParameterDirection.InputOutput;
                input_JC_No.Value = PN_JC_NO;
                //Output
                cmd.Parameters.Add("PO_DOC_DATE", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                //Updated by NM CHAUHAN 24-07-22
                cmd.Parameters.Add("PO_DOC_STATUS", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                OracleParameter input_BILL_NUM = cmd.Parameters.Add("PO_BILL_NUM", OracleType.VarChar, 15);
                input_BILL_NUM.Direction = ParameterDirection.InputOutput;
                input_BILL_NUM.Value = PO_BILL_NUM;

                //output varibale
                cmd.Parameters.Add("PO_BILL_TYPE", OracleType.VarChar, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PAYMENT_MODE", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INSURANCE", OracleType.VarChar, 15).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_CREDIT_NAME", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_CREDIT_NO", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_VIN", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REG_NO", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_MODEL_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_MODEL_DESC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_VEH_DELV_BY", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_UNAPPR_PART_ACC_YN", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_UNAPPR_CNG_LPG_YN", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_LEGAL_STATUS_YN", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_CD", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_DESC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INV_CD", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INV_DESC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INV_GSTIN", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INS_COMPANY_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INS_COMPANY_DESC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INS_PARTY_CD", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INS_PARTY_DESC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DEDUCTIBLES", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SALVAGE", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CATEGORY", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CAR_USERNAME", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REMARKS", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_JC_CLOSE_DATE", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_GST_TYPE", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PICKUP_TYPE", OracleType.VarChar, 25).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PICKUP_DATE", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_OUT_AMT", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_TYPE", OracleType.VarChar, 25).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_DISC_PER", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_DISC_PER", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_DISC_VAL", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_DISC_VAL", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DISC_AUTH_BY", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_AMT_EST", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_AMT_EST", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_TOTAL_BILL_AMT_EST", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_QR_CD_YN", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ROUND_OFF", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_VAR_REASON_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DELAY_REASON_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DELAY_REMARKS", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_TCS", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_INS_TCS", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_EWR_TCS", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_B2B_FLAG", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_B2C_FLAG", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_PART_REFCUR"].Value;
                    while (dr.Read())
                    {
                        PO_PART_REFCUR_CURSOR = new PO_PART_REFCUR();
                        PO_PART_REFCUR_CURSOR.srl_no = Convert.ToString(dr["srl_no"]);
                        PO_PART_REFCUR_CURSOR.Part_no = Convert.ToString(dr["Part_no"]);
                        PO_PART_REFCUR_CURSOR.Qty = Convert.ToString(dr["Qty"]);
                        PO_PART_REFCUR_CURSOR.Rate = Convert.ToString(dr["Rate"]);
                        PO_PART_REFCUR_CURSOR.Item_Val = Convert.ToString(dr["Item_Val"]);
                        PO_PART_REFCUR_CURSOR.Type = Convert.ToString(dr["Type"]);
                        PO_PART_REFCUR_CURSOR.Perc = Convert.ToString(dr["Perc"]);
                        PO_PART_REFCUR_CURSOR.Basic_Amt = Convert.ToString(dr["Basic_Amt"]);
                        PO_PART_REFCUR_CURSOR.Value = Convert.ToString(dr["Value"]);
                        PO_PART_REFCUR_CURSOR.Disc_Amt = Convert.ToString(dr["Disc_Amt"]);
                        PO_PART_REFCUR_CURSOR.Tax = Convert.ToString(dr["Tax"]);
                        PO_PART_REFCUR_CURSOR.Total_Amt = Convert.ToString(dr["Total_Amt"]);
                        PO_PART_REFCUR_CURSOR.Set_No = Convert.ToString(dr["Set_No"]);
                        PO_PART_REFCUR_CURSOR.Batch = Convert.ToString(dr["Batch"]);
                        PO_PART_REFCUR_CURSOR.Part_Desc = Convert.ToString(dr["Part_Desc"]);
                        PO_PART_REFCUR_CURSOR.Tax_Category = Convert.ToString(dr["Tax_Category"]);
                        PO_PART_REFCUR_LIST.Add(PO_PART_REFCUR_CURSOR);
                    }
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_LABOUR_REFCUR"].Value;
                    while (dr.Read())
                    {
                        PO_LABOUR_REFCUR_CURSOR = new PO_LABOUR_REFCUR();
                        PO_LABOUR_REFCUR_CURSOR.srl_no = Convert.ToString(dr["srl_no"]);
                        PO_LABOUR_REFCUR_CURSOR.Labour = Convert.ToString(dr["Labour"]);
                        PO_LABOUR_REFCUR_CURSOR.Frm_hr = Convert.ToString(dr["Frm_hr"]);
                        PO_LABOUR_REFCUR_CURSOR.Comp_perc = Convert.ToString(dr["Comp_perc"]);
                        PO_LABOUR_REFCUR_CURSOR.Normal_perc = Convert.ToString(dr["Normal_perc"]);
                        PO_LABOUR_REFCUR_CURSOR.Labour_Amt = Convert.ToString(dr["Labour_Amt"]);
                        PO_LABOUR_REFCUR_CURSOR.Type = Convert.ToString(dr["Type"]);
                        PO_LABOUR_REFCUR_CURSOR.Perc = Convert.ToString(dr["Perc"]);
                        PO_LABOUR_REFCUR_CURSOR.Basic_Amt = Convert.ToString(dr["Basic_Amt"]);
                        PO_LABOUR_REFCUR_CURSOR.Value = Convert.ToString(dr["Value"]);
                        PO_LABOUR_REFCUR_CURSOR.Disc_Amt = Convert.ToString(dr["Disc_Amt"]);
                        PO_LABOUR_REFCUR_CURSOR.Tax = Convert.ToString(dr["Tax"]);
                        PO_LABOUR_REFCUR_CURSOR.Total_Amt = Convert.ToString(dr["Total_Amt"]);
                        PO_LABOUR_REFCUR_CURSOR.Set_No = Convert.ToString(dr["Set_No"]);
                        PO_LABOUR_REFCUR_CURSOR.Labour_Desc = Convert.ToString(dr["Labour_Desc"]);
                        PO_LABOUR_REFCUR_CURSOR.Tax_Category = Convert.ToString(dr["Tax_Category"]);
                        PO_LABOUR_REFCUR_LIST.Add(PO_LABOUR_REFCUR_CURSOR);
                    }
                }
                Typedetail = new GET_JC_BILL_DTL();
                Typedetail.PART_DETAIL = PO_PART_REFCUR_LIST;
                Typedetail.LABOUR_DETAIL = PO_LABOUR_REFCUR_LIST;
                Typedetail.PN_JC_NO = cmd.Parameters["PN_JC_NO"].Value.ToString(); //consume input-output parameter
                Typedetail.PO_DOC_DATE = cmd.Parameters["PO_DOC_DATE"].Value.ToString();
                Typedetail.PO_DOC_STATUS = cmd.Parameters["PO_DOC_STATUS"].Value.ToString();// Updated By NM 24-07-2022
                Typedetail.PO_BILL_NUM = cmd.Parameters["PO_BILL_NUM"].Value.ToString();
                Typedetail.PO_BILL_TYPE = cmd.Parameters["PO_BILL_TYPE"].Value.ToString();
                Typedetail.PO_PAYMENT_MODE = cmd.Parameters["PO_PAYMENT_MODE"].Value.ToString();
                Typedetail.PO_INSURANCE = cmd.Parameters["PO_INSURANCE"].Value.ToString();
                Typedetail.PO_CUST_CREDIT_NAME = cmd.Parameters["PO_CUST_CREDIT_NAME"].Value.ToString();
                Typedetail.PO_CUST_CREDIT_NO = cmd.Parameters["PO_CUST_CREDIT_NO"].Value.ToString();
                Typedetail.PO_VIN = cmd.Parameters["PO_VIN"].Value.ToString();
                Typedetail.PO_REG_NO = cmd.Parameters["PO_REG_NO"].Value.ToString();
                Typedetail.PO_MODEL_CD = cmd.Parameters["PO_MODEL_CD"].Value.ToString();
                Typedetail.PO_MODEL_DESC = cmd.Parameters["PO_MODEL_DESC"].Value.ToString();
                Typedetail.PO_VEH_DELV_BY = cmd.Parameters["PO_VEH_DELV_BY"].Value.ToString();
                Typedetail.PO_UNAPPR_PART_ACC_YN = cmd.Parameters["PO_UNAPPR_PART_ACC_YN"].Value.ToString();
                Typedetail.PO_UNAPPR_CNG_LPG_YN = cmd.Parameters["PO_UNAPPR_CNG_LPG_YN"].Value.ToString();
                Typedetail.PO_CUST_LEGAL_STATUS_YN = cmd.Parameters["PO_CUST_LEGAL_STATUS_YN"].Value.ToString();
                Typedetail.PO_CUST_CD = cmd.Parameters["PO_CUST_CD"].Value.ToString();
                Typedetail.PO_CUST_DESC = cmd.Parameters["PO_CUST_DESC"].Value.ToString();
                Typedetail.PO_INV_CD = cmd.Parameters["PO_INV_CD"].Value.ToString();
                Typedetail.PO_INV_DESC = cmd.Parameters["PO_INV_DESC"].Value.ToString();
                Typedetail.PO_INV_GSTIN = cmd.Parameters["PO_INV_GSTIN"].Value.ToString();
                Typedetail.PO_INS_COMPANY_CD = cmd.Parameters["PO_INS_COMPANY_CD"].Value.ToString();
                Typedetail.PO_INS_COMPANY_DESC = cmd.Parameters["PO_INS_COMPANY_DESC"].Value.ToString();
                Typedetail.PO_INS_PARTY_CD = cmd.Parameters["PO_INS_PARTY_CD"].Value.ToString();
                Typedetail.PO_INS_PARTY_DESC = cmd.Parameters["PO_INS_PARTY_DESC"].Value.ToString();
                Typedetail.PO_DEDUCTIBLES = cmd.Parameters["PO_DEDUCTIBLES"].Value.ToString();
                Typedetail.PO_SALVAGE = cmd.Parameters["PO_SALVAGE"].Value.ToString();
                Typedetail.PO_CATEGORY = cmd.Parameters["PO_CATEGORY"].Value.ToString();
                Typedetail.PO_CAR_USERNAME = cmd.Parameters["PO_CAR_USERNAME"].Value.ToString();
                Typedetail.PO_REMARKS = cmd.Parameters["PO_REMARKS"].Value.ToString();
                Typedetail.PO_JC_CLOSE_DATE = cmd.Parameters["PO_JC_CLOSE_DATE"].Value.ToString();
                Typedetail.PO_GST_TYPE = cmd.Parameters["PO_GST_TYPE"].Value.ToString();
                Typedetail.PO_PICKUP_TYPE = cmd.Parameters["PO_PICKUP_TYPE"].Value.ToString();
                Typedetail.PO_PICKUP_DATE = cmd.Parameters["PO_PICKUP_DATE"].Value.ToString();
                Typedetail.PO_OUT_AMT = cmd.Parameters["PO_OUT_AMT"].Value.ToString();
                Typedetail.PO_CUST_TYPE = cmd.Parameters["PO_CUST_TYPE"].Value.ToString();
                Typedetail.PO_PART_DISC_PER = cmd.Parameters["PO_PART_DISC_PER"].Value.ToString();
                Typedetail.PO_LABOUR_DISC_PER = cmd.Parameters["PO_LABOUR_DISC_PER"].Value.ToString();
                Typedetail.PO_PART_DISC_VAL = cmd.Parameters["PO_PART_DISC_VAL"].Value.ToString();
                Typedetail.PO_LABOUR_DISC_VAL = cmd.Parameters["PO_LABOUR_DISC_VAL"].Value.ToString();
                Typedetail.PO_DISC_AUTH_BY = cmd.Parameters["PO_DISC_AUTH_BY"].Value.ToString();
                Typedetail.PO_PART_AMT_EST = cmd.Parameters["PO_PART_AMT_EST"].Value.ToString();
                Typedetail.PO_TOTAL_BILL_AMT_EST = cmd.Parameters["PO_TOTAL_BILL_AMT_EST"].Value.ToString();
                Typedetail.PO_QR_CD_YN = cmd.Parameters["PO_QR_CD_YN"].Value.ToString();
                Typedetail.PO_ROUND_OFF = cmd.Parameters["PO_ROUND_OFF"].Value.ToString();
                Typedetail.PO_VAR_REASON_CD = cmd.Parameters["PO_VAR_REASON_CD"].Value.ToString();
                Typedetail.PO_DELAY_REASON_CD = cmd.Parameters["PO_DELAY_REASON_CD"].Value.ToString();
                Typedetail.PO_DELAY_REMARKS = cmd.Parameters["PO_DELAY_REMARKS"].Value.ToString();
                Typedetail.PO_CUST_TCS = cmd.Parameters["PO_CUST_TCS"].Value.ToString();
                Typedetail.PO_INS_TCS = cmd.Parameters["PO_INS_TCS"].Value.ToString();
                Typedetail.PO_EWR_TCS = cmd.Parameters["PO_EWR_TCS"].Value.ToString();
                Typedetail.PO_B2B_FLAG = cmd.Parameters["PO_B2B_FLAG"].Value.ToString();
                Typedetail.PO_B2C_FLAG = cmd.Parameters["PO_B2C_FLAG"].Value.ToString();

                Details.Add(Typedetail);

                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETJCBILLDTL", "pkg_jco_1.SP_JCO_GET_JC_BILL_DTL", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NO': '" + PN_JC_NO + "'PO_BILL_NUM': '" + PO_BILL_NUM, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETJCBILLDTL", "pkg_jco_1.SP_JCO_GET_JC_BILL_DTL", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NO': '" + PN_JC_NO + "'PO_BILL_NUM': '" + PO_BILL_NUM, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region CALCULATEJCBILL
        /// <summary>
        /// CALCULATEJCBILL For mtab jc billing
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        ///  <param name="PN_JC_NUM"></param>
        /// <returns></returns>
        public BaseListReturnType<CALCULATE_JC_BILL> CALCULATEJCBILL(string PN_USER_ID, string PN_JC_NUM)
        {

            BaseListReturnType<CALCULATE_JC_BILL> response = new BaseListReturnType<CALCULATE_JC_BILL>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            CALCULATE_JC_BILL Typedetail = null;
            List<CALCULATE_JC_BILL> Details = new List<CALCULATE_JC_BILL>();
            List<PART_REFCUR> PART_LIST = new List<PART_REFCUR>();
            List<LABOUR_REFCUR> LABOUR_LIST = new List<LABOUR_REFCUR>();

            PART_REFCUR PART_CURSOR;
            LABOUR_REFCUR LABOUR_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_calculate_jc_bill;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                cmd.Parameters.Add("PN_JC_NUM", OracleType.VarChar, 12).Value = PN_JC_NUM;
                //output varibale
                cmd.Parameters.Add("PN_PAYMENT_MODE", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_AMT", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_AMT", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_TOTAL_AMT", OracleType.Number, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PART_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_LABOUR_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<CALCULATE_JC_BILL>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_PART_REFCUR"].Value;
                    while (dr.Read())
                    {
                        PART_CURSOR = new PART_REFCUR();
                        PART_CURSOR.req_iss_type = Convert.ToString(dr["req_iss_type"]);
                        PART_CURSOR.Basic_Amt = Convert.ToString(dr["Basic_Amt"]);
                        PART_CURSOR.Total_Disc = Convert.ToString(dr["Total_Disc"]);
                        PART_CURSOR.Total_Charges = Convert.ToString(dr["Total_Charges"]);
                        PART_CURSOR.Total_Amt = Convert.ToString(dr["Total_Amt"]);
                        PART_CURSOR.Set_No = Convert.ToString(dr["Set_No"]);
                        PART_LIST.Add(PART_CURSOR);
                    }

                }


                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_LABOUR_REFCUR"].Value;
                    while (dr.Read())
                    {
                        LABOUR_CURSOR = new LABOUR_REFCUR();
                        LABOUR_CURSOR.req_iss_type = Convert.ToString(dr["req_iss_type"]);
                        LABOUR_CURSOR.Basic_Amt = Convert.ToString(dr["Basic_Amt"]);
                        LABOUR_CURSOR.Total_Disc = Convert.ToString(dr["Total_Disc"]);
                        LABOUR_CURSOR.Total_Charges = Convert.ToString(dr["Total_Charges"]);
                        LABOUR_CURSOR.Total_Amt = Convert.ToString(dr["Total_Amt"]);
                        LABOUR_CURSOR.Set_No = Convert.ToString(dr["Set_No"]);
                        LABOUR_LIST.Add(LABOUR_CURSOR);
                    }

                }

                Typedetail = new CALCULATE_JC_BILL();
                Typedetail.PART_DETAIL = PART_LIST;
                Typedetail.LABOUR_DETAIL = LABOUR_LIST;
                Typedetail.PN_PAYMENT_MODE = cmd.Parameters["PN_PAYMENT_MODE"].Value.ToString();
                Typedetail.PO_LABOUR_AMT = cmd.Parameters["PO_LABOUR_AMT"].Value.ToString();
                Typedetail.PO_PART_AMT = cmd.Parameters["PO_PART_AMT"].Value.ToString();
                Typedetail.PO_TOTAL_AMT = cmd.Parameters["PO_TOTAL_AMT"].Value.ToString();
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("CALCULATEJCBILL", "pkg_jco_1.SP_JCO_CALCULATE_JC_BILL", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '" + PN_JC_NUM, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                 + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("CALCULATEJCBILL", "pkg_jco_1.SP_JCO_CALCULATE_JC_BILL", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '" + PN_JC_NUM, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region CREATEBILLING
        /// <summary>
        /// To generate Billing
        /// </summary>
        /// <returns></returns>
        public BaseListReturnType<JCO_CREATE_BILLING> CREATEBILLING(string PN_USER_ID, string PN_JC_NUM, string PN_DOC_DATE,
            string PN_PAYMENT_MODE,
            string PN_INS_NAME, string PN_CUST_CREDIT_CRD_NAME, string PN_CREDIT_CRD_NUM,
            string PN_VEH_DELIVERED_BY, string PN_INV_PARTY_CD, string PN_INS_COMPANY, string PN_INS_PARTY_CD,
            string PN_DEDUCTIBLES, string PN_SALVAGE, string PN_REMARKS, string PN_VARIATION_REASON_CD, string PN_DELAY_REASON_CD, string PN_DELAY_REMARKS)
        {
            BaseListReturnType<JCO_CREATE_BILLING> response = new BaseListReturnType<JCO_CREATE_BILLING>();
            JCO_CREATE_BILLING Typedetail = null;
            List<JCO_CREATE_BILLING> Details = new List<JCO_CREATE_BILLING>();
            List<PO_BILL_DTL> PO_BILL_DTL_LIST = new List<PO_BILL_DTL>();
            PO_BILL_DTL PO_BILL_DTL_CURSOR;

            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.create_billing;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                cmd.Parameters.Add("PN_JC_NUM", OracleType.VarChar, 12).Value = PN_JC_NUM;
                //Updated By NM 24-07022
                cmd.Parameters.Add("PN_DOC_DATE", OracleType.VarChar, 50).Value = PN_DOC_DATE;
                cmd.Parameters.Add("PN_PAYMENT_MODE", OracleType.VarChar, 5).Value = PN_PAYMENT_MODE;
                cmd.Parameters.Add("PN_INS_NAME", OracleType.VarChar, 15).Value = PN_INS_NAME;
                cmd.Parameters.Add("PN_CUST_CREDIT_CRD_NAME", OracleType.VarChar, 50).Value = PN_CUST_CREDIT_CRD_NAME;
                cmd.Parameters.Add("PN_CREDIT_CRD_NUM", OracleType.VarChar, 50).Value = PN_CREDIT_CRD_NUM;
                cmd.Parameters.Add("PN_VEH_DELIVERED_BY", OracleType.VarChar, 20).Value = PN_VEH_DELIVERED_BY;
                cmd.Parameters.Add("PN_INV_PARTY_CD", OracleType.VarChar, 30).Value = PN_INV_PARTY_CD;
                cmd.Parameters.Add("PN_INS_COMPANY", OracleType.VarChar, 30).Value = PN_INS_COMPANY;
                cmd.Parameters.Add("PN_INS_PARTY_CD", OracleType.VarChar, 30).Value = PN_INS_PARTY_CD;
                cmd.Parameters.Add("PN_DEDUCTIBLES", OracleType.VarChar, 100).Value = PN_DEDUCTIBLES;
                cmd.Parameters.Add("PN_SALVAGE", OracleType.VarChar, 100).Value = PN_SALVAGE;
                cmd.Parameters.Add("PN_REMARKS", OracleType.VarChar, 500).Value = PN_REMARKS;
                //cmd.Parameters.Add("PN_PICKUP_TYPE", OracleType.VarChar, 30).Value = PN_PICKUP_TYPE;
                //cmd.Parameters.Add("PN_PICKUP_DATE", OracleType.VarChar, 20).Value = PN_PICKUP_DATE;
                //cmd.Parameters.Add("PN_DISC_AUTH_BY", OracleType.VarChar, 20).Value = PN_DISC_AUTH_BY;
                cmd.Parameters.Add("PN_VARIATION_REASON_CD", OracleType.VarChar, 20).Value = PN_VARIATION_REASON_CD;
                cmd.Parameters.Add("PN_DELAY_REASON_CD", OracleType.VarChar, 20).Value = PN_DELAY_REASON_CD;
                cmd.Parameters.Add("PN_DELAY_REMARKS", OracleType.VarChar, 500).Value = PN_DELAY_REMARKS;
                //output
                cmd.Parameters.Add("PO_BILL_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_BILL_DTL"].Value;
                    while (dr.Read())
                    {
                        PO_BILL_DTL_CURSOR = new PO_BILL_DTL();
                        PO_BILL_DTL_CURSOR.srl_no = Convert.ToString(dr["srl_no"]);
                        PO_BILL_DTL_CURSOR.Req_iss_type = Convert.ToString(dr["Req_iss_type"]);
                        PO_BILL_DTL_CURSOR.Bill_num = Convert.ToString(dr["Bill_num"]);
                        PO_BILL_DTL_CURSOR.set_no = Convert.ToString(dr["set_no"]);
                        PO_BILL_DTL_LIST.Add(PO_BILL_DTL_CURSOR);
                    }
                }
                Typedetail = new JCO_CREATE_BILLING();
                Typedetail.BILL_DETAIL = PO_BILL_DTL_LIST;

                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("CREATEBILLING", "pkg_jco_1.SP_JCO_CREATE_BILLING", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                   + PN_JC_NUM + "'PN_DOC_DATE': '" + PN_DOC_DATE + "'PN_PAYMENT_MODE': '" + PN_PAYMENT_MODE + "'PN_INS_NAME': '" + PN_INS_NAME +
                   "'PN_CUST_CREDIT_CRD_NAME': '" + PN_CUST_CREDIT_CRD_NAME + "'PN_CREDIT_CRD_NUM': '" + PN_CREDIT_CRD_NUM + "'PN_VEH_DELIVERED_BY': '" + PN_VEH_DELIVERED_BY + "'PN_INV_PARTY_CD': '" +
                   PN_INV_PARTY_CD + "'PN_INS_COMPANY': '" + PN_INS_COMPANY + "'PN_INS_PARTY_CD': '" + PN_INS_PARTY_CD + "'PN_DEDUCTIBLES': '"
                   + PN_DEDUCTIBLES + "'PN_SALVAGE': '" + PN_SALVAGE + "'PN_REMARKS': '" + PN_REMARKS + "'PN_VARIATION_REASON_CD': '" + PN_VARIATION_REASON_CD +
                   "'PN_DELAY_REASON_CD': '" + PN_DELAY_REASON_CD + "'PN_DELAY_REMARKS': '" + PN_DELAY_REMARKS, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                   + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("CREATEBILLING", "pkg_jco_1.SP_JCO_CREATE_BILLING", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                  + PN_JC_NUM + "'PN_DOC_DATE': '" + PN_DOC_DATE + "'PN_PAYMENT_MODE': '" + PN_PAYMENT_MODE + "'PN_INS_NAME': '" + PN_INS_NAME +
                  "'PN_CUST_CREDIT_CRD_NAME': '" + PN_CUST_CREDIT_CRD_NAME + "'PN_CREDIT_CRD_NUM': '" + PN_CREDIT_CRD_NUM + "'PN_VEH_DELIVERED_BY': '" + PN_VEH_DELIVERED_BY + "'PN_INV_PARTY_CD': '" +
                  PN_INV_PARTY_CD + "'PN_INS_COMPANY': '" + PN_INS_COMPANY + "'PN_INS_PARTY_CD': '" + PN_INS_PARTY_CD + "'PN_DEDUCTIBLES': '"
                  + PN_DEDUCTIBLES + "'PN_SALVAGE': '" + PN_SALVAGE + "'PN_REMARKS': '" + PN_REMARKS + "'PN_VARIATION_REASON_CD': '" + PN_VARIATION_REASON_CD +
                  "'PN_DELAY_REASON_CD': '" + PN_DELAY_REASON_CD + "'PN_DELAY_REMARKS': '" + PN_DELAY_REMARKS, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GETINSURANCECOMPANY
        /// <summary>
        /// GET INSURANCE COMPANY For mtab jc billing
        /// </summary>
        /// <returns></returns>
        public BaseListReturnType<INSURANCE_COMPANY> GETINSURANCECOMPANY()
        {

            BaseListReturnType<INSURANCE_COMPANY> response = new BaseListReturnType<INSURANCE_COMPANY>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            INSURANCE_COMPANY Typedetail = null;
            List<INSURANCE_COMPANY> Details = new List<INSURANCE_COMPANY>();
            List<INSURANCE_DTL> INSURANCE_LIST = new List<INSURANCE_DTL>();

            INSURANCE_DTL INSURANCE_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_insurance_company;
                cmd.CommandType = CommandType.StoredProcedure;
                //output varibale
                cmd.Parameters.Add("INSURANCE_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<INSURANCE_COMPANY>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["INSURANCE_DTL"].Value;
                    while (dr.Read())
                    {
                        INSURANCE_CURSOR = new INSURANCE_DTL();
                        INSURANCE_CURSOR.ins_comp_cd = Convert.ToString(dr["ins_comp_cd"]);
                        INSURANCE_CURSOR.ins_comp_desc = Convert.ToString(dr["ins_comp_desc"]);
                        INSURANCE_LIST.Add(INSURANCE_CURSOR);
                    }

                }

                Typedetail = new INSURANCE_COMPANY();
                Typedetail.INSURANCE_DTL = INSURANCE_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETINSURANCECOMPANY", "pkg_jco_1.SP_GET_INSURANCE_COMPANY", "", "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
             + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETINSURANCECOMPANY", "pkg_jco_1.SP_GET_INSURANCE_COMPANY", "", ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GETINSURANCEPARTY
        /// <summary>
        /// GET INSURANCE PARTY For mtab jc billing
        /// </summary>
        /// <returns></returns>
        public BaseListReturnType<INSURANCE_PARTY> GETINSURANCEPARTY(string INS_COMPANY_CD)
        {

            BaseListReturnType<INSURANCE_PARTY> response = new BaseListReturnType<INSURANCE_PARTY>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            INSURANCE_PARTY Typedetail = null;
            List<INSURANCE_PARTY> Details = new List<INSURANCE_PARTY>();
            List<INSURANCE_PARTY_DTL> INSURANCE_PARTY_LIST = new List<INSURANCE_PARTY_DTL>();

            INSURANCE_PARTY_DTL INSURANCE_PARTY_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_insurance_party;
                cmd.CommandType = CommandType.StoredProcedure;
                //Updated By NM 24/07/22
                cmd.Parameters.Add("INS_COMPANY_CD", OracleType.VarChar, 20).Value = INS_COMPANY_CD;
                //output varibale
                cmd.Parameters.Add("INSURANCE_PARTY_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<INSURANCE_PARTY>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["INSURANCE_PARTY_DTL"].Value;
                    while (dr.Read())
                    {
                        INSURANCE_PARTY_CURSOR = new INSURANCE_PARTY_DTL();
                        INSURANCE_PARTY_CURSOR.ins_party_Cd = Convert.ToString(dr["ins_party_Cd"]);
                        INSURANCE_PARTY_CURSOR.ins_city = Convert.ToString(dr["ins_city"]);
                        INSURANCE_PARTY_CURSOR.ins_state = Convert.ToString(dr["ins_state"]);
                        INSURANCE_PARTY_CURSOR.ins_gst_num = Convert.ToString(dr["ins_gst_num"]);
                        INSURANCE_PARTY_CURSOR.ins_name = Convert.ToString(dr["ins_name"]);
                        INSURANCE_PARTY_LIST.Add(INSURANCE_PARTY_CURSOR);
                    }

                }

                Typedetail = new INSURANCE_PARTY();
                Typedetail.INSURANCE_PARTY_DTL = INSURANCE_PARTY_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETINSURANCEPARTY", "pkg_jco_1.SP_GET_INSURANCE_PARTY", "'INS_COMPANY_CD': '" + INS_COMPANY_CD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
               + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETINSURANCEPARTY", "pkg_jco_1.SP_GET_INSURANCE_PARTY", "'INS_COMPANY_CD': '" + INS_COMPANY_CD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GETDISCAUTH
        /// <summary>
        /// GET DISC AUTH For mtab jc billing
        /// </summary>
        /// PN_USER_ID
        /// <returns></returns>
        public BaseListReturnType<GET_DISC_AUTH> GETDISCAUTH(string PN_USER_ID)
        {

            BaseListReturnType<GET_DISC_AUTH> response = new BaseListReturnType<GET_DISC_AUTH>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            GET_DISC_AUTH Typedetail = null;
            List<GET_DISC_AUTH> Details = new List<GET_DISC_AUTH>();
            List<DISC_AUTH_DTL> DISC_AUTH_LIST = new List<DISC_AUTH_DTL>();

            DISC_AUTH_DTL DISC_AUTH_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_disc_auth_by;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                //output varibale
                cmd.Parameters.Add("DISC_AUTH_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<GET_DISC_AUTH>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["DISC_AUTH_DTL"].Value;
                    while (dr.Read())
                    {
                        DISC_AUTH_CURSOR = new DISC_AUTH_DTL();
                        DISC_AUTH_CURSOR.Disc_auth_by_cd = Convert.ToString(dr["Disc_auth_by_cd"]);
                        DISC_AUTH_CURSOR.Disc_auth_by_desc = Convert.ToString(dr["Disc_auth_by_desc"]);
                        DISC_AUTH_LIST.Add(DISC_AUTH_CURSOR);
                    }

                }

                Typedetail = new GET_DISC_AUTH();
                Typedetail.DISC_AUTH_DTL = DISC_AUTH_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETDISCAUTH", "pkg_jco_1.SP_GET_disc_auth_by", "'PN_USER_ID': '" + PN_USER_ID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                 + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETDISCAUTH", "pkg_jco_1.SP_GET_disc_auth_by", "'PN_USER_ID': '" + PN_USER_ID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GETVEHDELBY
        /// <summary>
        /// For Vehicle Delivered by data dropdown
        /// </summary>
        /// PN_USER_ID
        /// <returns></returns>
        public BaseListReturnType<GET_veh_del_by> GETVEHDELBY(string PN_USER_ID)
        {
            BaseListReturnType<GET_veh_del_by> response = new BaseListReturnType<GET_veh_del_by>();
            GET_veh_del_by Typedetail = null;
            List<GET_veh_del_by> Details = new List<GET_veh_del_by>();
            List<VEH_DELIVERY_DTL> VEH_DELIVERY_DTL_LIST = new List<VEH_DELIVERY_DTL>();
            VEH_DELIVERY_DTL VEH_DELIVERY_DTL_CURSOR;

            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.get_veh_del_by;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                //output 
                cmd.Parameters.Add("VEH_DELIVERY_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["VEH_DELIVERY_DTL"].Value;
                    while (dr.Read())
                    {
                        VEH_DELIVERY_DTL_CURSOR = new VEH_DELIVERY_DTL();
                        VEH_DELIVERY_DTL_CURSOR.veh_delivered_by_cd = Convert.ToString(dr["veh_delivered_by_cd"]);
                        VEH_DELIVERY_DTL_CURSOR.veh_delivered_by_desc = Convert.ToString(dr["veh_delivered_by_desc"]);
                        VEH_DELIVERY_DTL_LIST.Add(VEH_DELIVERY_DTL_CURSOR);
                    }
                }
                Typedetail = new GET_veh_del_by();
                Typedetail.VEHDELIVERYDTL = VEH_DELIVERY_DTL_LIST;

                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETVEHDELBY", "pkg_jco_1.SP_GET_veh_del_by", "'PN_USER_ID': '" + PN_USER_ID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                  + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETVEHDELBY", "pkg_jco_1.SP_GET_veh_del_by", "'PN_USER_ID': '" + PN_USER_ID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GETVARIATIONREASON
        /// <summary>
        /// For Variation reason data dropdown
        /// </summary>
        /// <returns></returns>
        public BaseListReturnType<GET_VARIATION_REASON> GETVARIATIONREASON()
        {
            BaseListReturnType<GET_VARIATION_REASON> response = new BaseListReturnType<GET_VARIATION_REASON>();
            GET_VARIATION_REASON Typedetail = null;
            List<GET_VARIATION_REASON> Details = new List<GET_VARIATION_REASON>();
            List<VARIATION_DTL> VARIATION_DTL_LIST = new List<VARIATION_DTL>();
            VARIATION_DTL VARIATION_DTL_CURSOR;

            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.get_variation_reason;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("VARIATION_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["VARIATION_DTL"].Value;
                    while (dr.Read())
                    {
                        VARIATION_DTL_CURSOR = new VARIATION_DTL();
                        VARIATION_DTL_CURSOR.variation_cd = Convert.ToString(dr["variation_cd"]);
                        VARIATION_DTL_CURSOR.variation_desc = Convert.ToString(dr["variation_desc"]);
                        VARIATION_DTL_LIST.Add(VARIATION_DTL_CURSOR);
                    }
                }
                Typedetail = new GET_VARIATION_REASON();
                Typedetail.VARIATIONDTL = VARIATION_DTL_LIST;

                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETVARIATIONREASON", "pkg_jco_1.SP_GET_variation_reason", "", "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
               + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETVARIATIONREASON", "pkg_jco_1.SP_GET_variation_reason", "", ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GETBILLDELAYREASON
        /// <summary>
        /// For Bill Delay reason data dropdown
        /// </summary>
        /// <returns></returns>
        public BaseListReturnType<GET_BILL_DELAY_REASON> GETBILLDELAYREASON()
        {
            BaseListReturnType<GET_BILL_DELAY_REASON> response = new BaseListReturnType<GET_BILL_DELAY_REASON>();
            GET_BILL_DELAY_REASON Typedetail = null;
            List<GET_BILL_DELAY_REASON> Details = new List<GET_BILL_DELAY_REASON>();
            List<bill_reason_DTL> bill_reason_DTL_LIST = new List<bill_reason_DTL>();
            bill_reason_DTL bill_reason_DTL_CURSOR;

            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.get_bill_delay_reason;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("bill_reason_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["bill_reason_DTL"].Value;
                    while (dr.Read())
                    {
                        bill_reason_DTL_CURSOR = new bill_reason_DTL();
                        bill_reason_DTL_CURSOR.Bill_delay_reason_cd = Convert.ToString(dr["Bill_delay_reason_cd"]);
                        bill_reason_DTL_CURSOR.Bill_delay_reason_desc = Convert.ToString(dr["Bill_delay_reason_desc"]);
                        bill_reason_DTL_LIST.Add(bill_reason_DTL_CURSOR);
                    }
                }
                Typedetail = new GET_BILL_DELAY_REASON();
                Typedetail.billreasonDTL = bill_reason_DTL_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETBILLDELAYREASON", "pkg_jco_1.SP_GET_bill_delay_reason", "", "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
              + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETBILLDELAYREASON", "pkg_jco_1.SP_GET_bill_delay_reason", "", ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GETINVPARTY
        /// <summary>
        /// For get inv party dropdown
        /// </summary>
        /// <param name="INV_PARTY_CD"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_INV_PARTY> GETINVPARTY(string INV_PARTY_CD)
        {
            BaseListReturnType<GET_INV_PARTY> response = new BaseListReturnType<GET_INV_PARTY>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            GET_INV_PARTY Typedetail = null;
            List<GET_INV_PARTY> Details = new List<GET_INV_PARTY>();
            List<INV_PARTY_DTL> PARTY_LIST = new List<INV_PARTY_DTL>();
            INV_PARTY_DTL PARTY_CURSOR;
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.get_inv_party;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("INV_PARTY_CD", OracleType.VarChar, 20).Value = INV_PARTY_CD;
                //output varibale
                cmd.Parameters.Add("INV_PARTY_DTL", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<GET_INV_PARTY>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["INV_PARTY_DTL"].Value;
                    while (dr.Read())
                    {
                        PARTY_CURSOR = new INV_PARTY_DTL();
                        PARTY_CURSOR.Cust_cd = Convert.ToString(dr["Cust_cd"]);
                        PARTY_CURSOR.Cust_name = Convert.ToString(dr["Cust_name"]);
                        PARTY_CURSOR.State_cd = Convert.ToString(dr["State_cd"]);

                        PARTY_LIST.Add(PARTY_CURSOR);
                    }

                }
                Typedetail = new GET_INV_PARTY();
                Typedetail.Inv_Party_Details = PARTY_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GETINVPARTY", "pkg_jco_1.SP_GET_INV_PARTY", "'INV_PARTY_CD': '" + INV_PARTY_CD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GETINVPARTY", "pkg_jco_1.SP_GET_INV_PARTY", "'INV_PARTY_CD': '" + INV_PARTY_CD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GENQRB2B
        /// <summary>
        /// For genrate qr b2b
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        /// <param name="PN_JC_NUM"
        /// <param name="PN_BILL_NUM"
        /// <param name="PN_INV_PARTY_CD"
        /// <returns></returns>
        public BaseListReturnType<dynamic> GENQRB2B(string PN_USER_ID, string PN_JC_NUM, string PN_BILL_NUM, string PN_INV_PARTY_CD)
        {
            BaseListReturnType<dynamic> response = new BaseListReturnType<dynamic>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.qr_b2b;
                cmd.CommandType = CommandType.StoredProcedure;

                //Input varibale
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                cmd.Parameters.Add("PN_JC_NUM", OracleType.VarChar, 12).Value = PN_JC_NUM;
                cmd.Parameters.Add("PN_BILL_NUM", OracleType.VarChar, 15).Value = PN_BILL_NUM;
                cmd.Parameters.Add("PN_INV_PARTY_CD", OracleType.VarChar, 20).Value = PN_INV_PARTY_CD;

                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    Logger.SuccessLogPrint("GENQRB2B", "pkg_jco_1.SP_GEN_QR_B2B", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                 + PN_JC_NUM + "'PN_BILL_NUM': '" + PN_BILL_NUM + "'PN_INV_PARTY_CD': '" + PN_INV_PARTY_CD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                 + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
            }

            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GENQRB2B", "pkg_jco_1.SP_GEN_QR_B2B", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                + PN_JC_NUM + "'PN_BILL_NUM': '" + PN_BILL_NUM + "'PN_INV_PARTY_CD': '" + PN_INV_PARTY_CD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GENQRB2C
        /// <summary>
        /// For genrate qr b2c
        /// </summary>
        /// <param name="PN_USER_ID"></param>
        /// <param name="PN_JC_NUM"
        /// <param name="PN_BILL_NUM"
        /// <param name="PN_INV_PARTY_CD"
        /// <returns></returns>
        public BaseListReturnType<dynamic> GENQRB2C(string PN_USER_ID, string PN_JC_NUM, string PN_BILL_NUM, string PN_INV_PARTY_CD)
        {
            BaseListReturnType<dynamic> response = new BaseListReturnType<dynamic>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.qr_b2c;
                cmd.CommandType = CommandType.StoredProcedure;

                //Input varibale
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = PN_USER_ID;
                cmd.Parameters.Add("PN_JC_NUM", OracleType.VarChar, 12).Value = PN_JC_NUM;
                cmd.Parameters.Add("PN_BILL_NUM", OracleType.VarChar, 15).Value = PN_BILL_NUM;
                cmd.Parameters.Add("PN_INV_PARTY_CD", OracleType.VarChar, 20).Value = PN_INV_PARTY_CD;

                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    Logger.SuccessLogPrint("GENQRB2C", "pkg_jco_1.SP_GEN_QR_B2C", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                   + PN_JC_NUM + "'PN_BILL_NUM': '" + PN_BILL_NUM + "'PN_INV_PARTY_CD': '" + PN_INV_PARTY_CD, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                   + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GENQRB2C", "pkg_jco_1.SP_GEN_QR_B2C", "'PN_USER_ID': '" + PN_USER_ID + "'PN_JC_NUM': '"
                  + PN_JC_NUM + "'PN_BILL_NUM': '" + PN_BILL_NUM + "'PN_INV_PARTY_CD': '" + PN_INV_PARTY_CD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        //START API WORK OF MTAB CONSUMABLE MODULE 27 JULY 2022//

        #region GROUPPARTMCARD
        /// <summary>
        /// For get inv party dropdown
        /// </summary>
        /// <param name="pn_user_id"></param>
        /// /// <param name="pn_smodel_cd"></param>
        /// /// <param name="pn_fueltype"></param>
        /// /// <param name="pn_variant_cd"></param>
        /// /// <param name="pn_sub_rcateg_cd"></param>
        /// /// <param name="PN_GROUP_CD"></param>
        /// /// <param name="pn_menu_part_yn"></param>
        /// /// /// <param name="PN_MTAB_NPAD"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_GROUP_PART> GROUPPARTMCARD(string pn_user_id, string PN_PART_NUM, string pn_smodel_cd, string pn_fueltype,
            string pn_variant_cd, string pn_sub_rcateg_cd, string PN_GROUP_CD, string pn_menu_part_yn, string PN_MTAB_NPAD)
        {
            BaseListReturnType<GET_GROUP_PART> response = new BaseListReturnType<GET_GROUP_PART>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            GET_GROUP_PART Typedetail = null;
            List<GET_GROUP_PART> Details = new List<GET_GROUP_PART>();
            List<PART_DTL> PART_LIST = new List<PART_DTL>();
            PART_DTL PART_CURSOR;
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_group_part_mcard;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = pn_user_id;
                cmd.Parameters.Add("PN_PART_NUM", OracleType.VarChar, 15).Value = Convert.ToString(PN_PART_NUM.Substring(0, 5));
                cmd.Parameters.Add("pn_smodel_cd", OracleType.VarChar, 7).Value = pn_smodel_cd;
                cmd.Parameters.Add("pn_fueltype", OracleType.VarChar, 3).Value = pn_fueltype;
                cmd.Parameters.Add("pn_variant_cd", OracleType.VarChar, 8).Value = pn_variant_cd;
                cmd.Parameters.Add("pn_sub_rcateg_cd", OracleType.VarChar, 5).Value = pn_sub_rcateg_cd;
                cmd.Parameters.Add("PN_GROUP_CD", OracleType.VarChar, 15).Value = PN_GROUP_CD;
                cmd.Parameters.Add("pn_menu_part_yn", OracleType.VarChar, 1).Value = pn_menu_part_yn;
                cmd.Parameters.Add("PN_MTAB_NPAD", OracleType.VarChar, 10).Value = PN_MTAB_NPAD;
                //output varibale
                cmd.Parameters.Add("po_part_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<GET_GROUP_PART>();

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) != "1")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_part_refcur"].Value;
                    while (dr.Read())
                    {
                        PART_CURSOR = new PART_DTL();
                        PART_CURSOR.PART_NUM = Convert.ToString(dr["PART_NUM"]);
                        PART_CURSOR.PART_DESC = Convert.ToString(dr["PART_DESC"]);
                        PART_CURSOR.MRP_1 = Convert.ToString(dr["MRP_1"]);
                        PART_CURSOR.stock = Convert.ToString(dr["stock"]);
                        PART_CURSOR.GROUP_PART_NUM = PN_PART_NUM;
                        PART_LIST.Add(PART_CURSOR);
                    }

                }
                Typedetail = new GET_GROUP_PART();
                Typedetail.PART_DETAILS = PART_LIST;
                Details.Add(Typedetail);
                con.Close();
                response.code = (int)ServiceMassageCode.SUCCESS;
                response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                response.result = Details;
                Logger.SuccessLogPrint("GROUPPARTMCARD", "pkg_jco_1.sp_jco_get_group_part_mcard", "'pn_user_id': '" + pn_user_id + "'PN_PART_NUM': '"
                    + PN_PART_NUM + "'pn_smodel_cd': '" + pn_smodel_cd + "'pn_fueltype': '" + pn_fueltype + "'pn_variant_cd': '" + pn_variant_cd +
                    "'pn_sub_rcateg_cd': '" + pn_sub_rcateg_cd + "'PN_GROUP_CD': '" + PN_GROUP_CD + "'pn_menu_part_yn': '" + pn_menu_part_yn + "'PN_MTAB_NPAD': '" +
                    pn_user_id + "'pn_user_id': '" + pn_user_id + "'pn_user_id': '" + pn_user_id + "'pn_user_id': '"
                    + PN_MTAB_NPAD, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value)
                    + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GROUPPARTMCARD", "pkg_jco_1.sp_jco_get_group_part_mcard", "'pn_user_id': '" + pn_user_id + "'PN_PART_NUM': '"
                    + PN_PART_NUM + "'pn_smodel_cd': '" + pn_smodel_cd + "'pn_fueltype': '" + pn_fueltype + "'pn_variant_cd': '" + pn_variant_cd +
                    "'pn_sub_rcateg_cd': '" + pn_sub_rcateg_cd + "'PN_GROUP_CD': '" + PN_GROUP_CD + "'pn_menu_part_yn': '" + pn_menu_part_yn + "'PN_MTAB_NPAD': '" +
                    pn_user_id + "'pn_user_id': '" + pn_user_id + "'pn_user_id': '" + pn_user_id + "'pn_user_id': '"
                    + PN_MTAB_NPAD, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region Save Geo Fencing Details 
        public BaseListReturnType<dynamic> SaveGeoFencingDetails(string PN_RO_NUM, string PN_REG_NUM, string PN_RANGE_CD, string PN_SMART_PICK_FLAG)
        {
            BaseListReturnType<dynamic> response = new BaseListReturnType<dynamic>();
            //Validate Token
            ServiceHeaderInfo headerInfo = Common.Authenticate(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_insert_geo_fencing;
                cmd.CommandType = CommandType.StoredProcedure;

                //Input varibale
                cmd.Parameters.Add("PN_RO_NUM", OracleType.VarChar, 12).Value = PN_RO_NUM;
                cmd.Parameters.Add("PN_REG_NUM", OracleType.VarChar, 20).Value = PN_REG_NUM;
                cmd.Parameters.Add("PN_RANGE_CD", OracleType.VarChar, 5).Value = PN_RANGE_CD;
                cmd.Parameters.Add("PN_SMART_PICK_FLAG", OracleType.VarChar, 2).Value = PN_SMART_PICK_FLAG;

                //output varibale
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Float, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) != "1")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    Logger.SuccessLogPrint("SaveGeoFencingDetails", "pkg_jco_1.SP_INSERT_GEO_FENCING_DTL", "'PN_RO_NUM': '" + PN_RO_NUM + "'PN_REG_NUM': '"
                   + PN_REG_NUM + "'PN_RANGE_CD': '" + PN_RANGE_CD + "'PN_SMART_PICK_FLAG': '" + PN_SMART_PICK_FLAG, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value)
                   + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = Convert.ToString(ServiceMassageCode.ERROR);
                    response.result = null;
                }
            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("SaveGeoFencingDetails", "pkg_jco_1.SP_INSERT_GEO_FENCING_DTL", "'PN_RO_NUM': '" + PN_RO_NUM + "'PN_REG_NUM': '"
                   + PN_REG_NUM + "'PN_RANGE_CD': '" + PN_RANGE_CD + "'PN_SMART_PICK_FLAG': '" + PN_SMART_PICK_FLAG, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion


        #region NewUserAuth
        /// <summary>
        /// CALCULATEJCBILL For mtab jc billing
        /// </summary>
        /// <param name="UserName"></param>
        ///  <param name="Password"></param>
        ///  <param name="Imei"></param>
        ///  <param name="Version"></param>
        ///   <param name="vUpdate"></param>
        /// <returns></returns>
        public BaseListReturnType<LoginResponse> NewUserAuth(string UserName, string Password, string Imei, string Version, string vUpdate)
        {
            //JWT token
            UserName = Common.GetDecryptedString(UserName);
            Password = Common.GetDecryptedString(Password);
            Imei = Common.GetDecryptedString(Imei);
            Version = Common.GetDecryptedString(Version);
            vUpdate = Common.GetDecryptedString(vUpdate);

            //check count for lockout policy
            var chkCount = Common.CheckLockOutCount(UserName);
            BaseListReturnType<LoginResponse> response = new BaseListReturnType<LoginResponse>();
            if (chkCount <= 4)
            {
                LoginResponse Typedetail = new LoginResponse();
                List<LoginResponse> Details = new List<LoginResponse>();
                try
                {
                    con = new OracleConnection(constr);
                    cmd = new OracleCommand();
                    cmd.Connection = con;
                    cmd.CommandText = ProcedureDetails.sp_user_validate;
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = UserName;
                    cmd.Parameters.Add("pn_pwd", OracleType.VarChar, 12).Value = Password;
                    //added two parameters imei and version to these fn on 7 may  2015 by gst
                    cmd.Parameters.Add("pn_imei", OracleType.VarChar, 12).Value = Imei;
                    cmd.Parameters.Add("pn_version", OracleType.VarChar, 12).Value = Version;
                    //output varibale
                    cmd.Parameters.Add("po_parent_group", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_dealer_map_cd", OracleType.Int32, 5).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_loc_cd", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_comp_fa", OracleType.VarChar, 4).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_dealer_name", OracleType.VarChar, 70).Direction = ParameterDirection.Output;
                    //start added five new parameters as per warranty protal requirement created by mukesh sinha
                    cmd.Parameters.Add("PO_DEALER_CODE", OracleType.VarChar, 13).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_REGION_CD", OracleType.VarChar, 3).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_REGION", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_ZONE_CD", OracleType.VarChar, 2).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_ZONE", OracleType.VarChar, 30).Direction = ParameterDirection.Output;
                    //end added five new parameters as per warranty protal requirement created by mukesh sinha
                    cmd.Parameters.Add("po_loc_desc", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                    //added this key by kritika kulariya
                    cmd.Parameters.Add("PO_OUTLET_CD", OracleType.VarChar, 5).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_emp_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_DESG_CD", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("PO_ACCESS_FLAG", OracleType.VarChar, 3).Direction = ParameterDirection.Output;
                    //Added Out param by GAGAN Sharma 24 FEB 2023 PO_GEO_RADIUS_RANGE OUT NUMBER
                    cmd.Parameters.Add("PO_GEO_RADIUS_RANGE", OracleType.Int32).Direction = ParameterDirection.Output;
                    //Added Out param by Nagmani Chauhan 17 MAY 2023 po_cont_no OUT NUMBER
                    cmd.Parameters.Add("po_cont_no", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                    string token = Common.GenearteXMLDealerFile(UserName, Password);

                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    cmd.ExecuteNonQuery();
                    if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                    {
                        response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                        response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                        response.result = null;
                        con.Close();
                        return response;
                    }
                    Details = new List<LoginResponse>();

                    //check error 
                    if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                    {
                        string empCd = Convert.ToString(cmd.Parameters["po_emp_cd"].Value);
                        Typedetail = new LoginResponse();
                        Typedetail.PG = Convert.ToString(cmd.Parameters["po_parent_group"].Value);
                        Typedetail.DMC = Convert.ToString(cmd.Parameters["po_dealer_map_cd"].Value);
                        Typedetail.LC = Convert.ToString(cmd.Parameters["po_loc_cd"].Value);
                        Typedetail.CFA = Convert.ToString(cmd.Parameters["po_comp_fa"].Value);
                        Typedetail.LDSC = Convert.ToString(cmd.Parameters["po_loc_desc"].Value);
                        Typedetail.EMPCD = ((!string.IsNullOrEmpty(vUpdate) && "1".Equals(vUpdate)) ? empCd : empCd.Replace("$", "-"));
                        Typedetail.EMPCD1 = empCd;
                        Typedetail.DESGCD = Convert.ToString(cmd.Parameters["PO_DESG_CD"].Value);
                        Typedetail.ACCESS_FLAG = Convert.ToString(cmd.Parameters["PO_ACCESS_FLAG"].Value);
                        Typedetail.OUTLET_CD = Convert.ToString(cmd.Parameters["PO_OUTLET_CD"].Value);
                        Typedetail.GEO_RADIUS_RANGE = Convert.ToString(cmd.Parameters["PO_GEO_RADIUS_RANGE"].Value);
                        Typedetail.DN = Convert.ToString(cmd.Parameters["po_dealer_name"].Value);
                        Typedetail.DEALER_CODE = Convert.ToString(cmd.Parameters["PO_DEALER_CODE"].Value);
                        Typedetail.REGION_CD = Convert.ToString(cmd.Parameters["PO_REGION_CD"].Value);
                        Typedetail.REGION = Convert.ToString(cmd.Parameters["PO_REGION"].Value);
                        Typedetail.ZONE_CD = Convert.ToString(cmd.Parameters["PO_ZONE_CD"].Value);
                        Typedetail.ZONE = Convert.ToString(cmd.Parameters["PO_ZONE"].Value);
                        Typedetail.CONT_NO = Convert.ToString(cmd.Parameters["po_cont_no"].Value);
                        //Typedetail.Token = ((!string.IsNullOrEmpty(token.Access_Token)) ? token.Access_Token : null);
                        Typedetail.Token = Convert.ToString(token);
                        //LOGIN_LIST.Add(Login_Res);
                    }
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    if (response.code == 1)
                    {
                        Common.SaveLockOutCount(UserName, 1);

                    }

                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    //Typedetail = new LoginReturn();
                    //Typedetail.Login_Response = LOGIN_LIST;
                    Details.Add(Typedetail);
                    response.result = Details;
                    Logger.SuccessLogPrint("NewUserAuth", "pkg_jco_1.sp_jco_user_validate", "'pn_user_id': '" + UserName + "','pn_pwd':'" + Password + "','pn_imei':'" + Imei + "','pn_version':'" + Version, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

                }
                catch (Exception ex)
                {
                    //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                    const string lineSearch = ":line";
                    var index = ex.StackTrace.LastIndexOf(lineSearch);
                    var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = lineNumberText + ex.Message; //ex.Message;
                                                                    //response.code = (int)ServiceMassageCode.ERROR;
                                                                    //response.message = ex.Message;
                    response.result = null;
                    con.Close();
                    cmd.Dispose();
                    Logger.ErrorLogException("NewUserAuth", "pkg_jco_1.sp_jco_user_validate", "'pn_user_id': '" + UserName + "','pn_pwd':'" + Password + "','pn_imei':'" + Imei + "','pn_version':'" + Version, ex);
                }
                finally
                {
                    con.Close();
                    cmd.Dispose();
                    OracleConnection.ClearPool(con);
                }
            }
            else
            {
                response.message = "Your Account has been locked, please try again after 60 min";
            }
            return response;
        }

        #endregion


        /// <summary>
        /// Created by GAGAN SHARMA 28 FEB 2023
        /// </summary>
        /// <param name=""></param>
        /// <param name=""></param>
        /// <returns></returns>
        public BaseListReturnType<Token> PullToken()
        {
            BaseListReturnType<Token> response = new BaseListReturnType<Token>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            Token Typedetail = null;
            List<Token> Details = new List<Token>();
            //List<TokenValue> PART_LIST = new List<TokenValue>();
            TokenValue PART_CURSOR;
            try
            {
                PART_CURSOR = new TokenValue();
                string Tokenvalue = Logger.CreateToken();

                if (!string.IsNullOrEmpty(Tokenvalue))
                {
                    PART_CURSOR.DMS_Token = Tokenvalue;
                    //PART_LIST.Add(PART_CURSOR);
                    Typedetail = new Token();
                    Typedetail.DMS_Token = Tokenvalue;
                    Details.Add(Typedetail);
                    response.code = (int)ServiceMassageCode.SUCCESS;
                    response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                    response.result = Details;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = "Error in token generation please try again";
                    response.result = null;
                }

            }
            catch (Exception ex)
            {
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
            }
            return response;
        }


        #region UpdateJCDetails
        /// <summary>
        /// For genrate qr b2c
        /// </summary>
        /// <param name=""></param>
        /// <param name=""
        /// <param name=""
        /// <param name=""
        /// <returns></returns>
        public BaseListReturnType<dynamic> UpdateJCDetails(string JC_NUM, string USER_ID, string SRV_CAT_CD, string SUB_SRV_TYPE_CD,
                                       string PROMISED_DATE, string SA_ADV, string TECH_ADV, string BAY_CD, string GROUP_CD, string TECH_CD,
                                       string DEMAND_INS_STR, string PART_INS_STR, string LABOR_INS_STR, string UNAPPRV_FIT_STR,
                                       string PICKUP_TYPE, string PICKUP_DATE, string FREE_PIKCUP_FLAG, string PICKUP_LOC_CD, string PICKUP_DRIVER, string PIKCUP_REMARKS,
                                       string MMS_NUM, string PROB_STR, string CUST_REMARKS, string DLR_REMARKS, string APPRV_STATUS,
                                       double PART_EST_AMT, double OPR_EST_AMT, string REJ_PRT_LAB_INS_STR, string WASH_TYPE, int OCAS_CNT, int SAVE_CNT,
                                       int SENT_CNT, string FINAL_INSPECTION, string ADD_CHK, string ccp_yn, string ccp_num, string holdup_reasn_cd)
        {
            BaseListReturnType<dynamic> response = new BaseListReturnType<dynamic>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr_PushApi);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_UPDATE_dtl;
                cmd.CommandType = CommandType.StoredProcedure;

                //Input varibale
                cmd.Parameters.Add("PN_JC_NUM", OracleType.VarChar, 20).Value = Convert.ToString(JC_NUM);
                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = Convert.ToString(USER_ID);
                cmd.Parameters.Add("PN_SRV_CAT_CD", OracleType.VarChar, 20).Value = Convert.ToString(SRV_CAT_CD);
                cmd.Parameters.Add("PN_SUB_SRV_TYPE_CD", OracleType.VarChar, 20).Value = Convert.ToString(SUB_SRV_TYPE_CD);


                if (PROMISED_DATE == "")
                    cmd.Parameters.Add("PN_PROMISED_DATE", OracleType.VarChar).Value = DBNull.Value;//Convert.ToDateTime(promised_date_up);
                else
                    cmd.Parameters.Add("PN_PROMISED_DATE", OracleType.VarChar).Value = Convert.ToString(PROMISED_DATE);
                //Response.Write("pdate from device="+Convert.ToString(promised_date_up));

                cmd.Parameters.Add("PN_SA_ADV", OracleType.VarChar, 20).Value = Convert.ToString(SA_ADV);
                cmd.Parameters.Add("PN_TECH_ADV", OracleType.VarChar, 20).Value = Convert.ToString(TECH_ADV);
                cmd.Parameters.Add("PN_BAY_CD", OracleType.VarChar, 20).Value = Convert.ToString(BAY_CD);
                cmd.Parameters.Add("PN_GROUP_CD", OracleType.VarChar, 20).Value = Convert.ToString(GROUP_CD);
                cmd.Parameters.Add("PN_TECH_CD", OracleType.VarChar, 20).Value = Convert.ToString(TECH_CD);

                cmd.Parameters.Add("PN_DEMAND_INS_STR", OracleType.VarChar, 3600).Value = Convert.ToString(DEMAND_INS_STR);
                cmd.Parameters.Add("PN_PART_INS_STR", OracleType.VarChar, 3600).Value = Convert.ToString(PART_INS_STR);
                cmd.Parameters.Add("PN_LABOR_INS_STR", OracleType.VarChar, 3600).Value = Convert.ToString(LABOR_INS_STR);
                cmd.Parameters.Add("PN_UNAPPRV_FIT_STR", OracleType.VarChar, 3600).Value = Convert.ToString(UNAPPRV_FIT_STR);

                cmd.Parameters.Add("PN_PICKUP_TYPE", OracleType.VarChar, 25).Value = Convert.ToString(PICKUP_TYPE);

                if (PICKUP_DATE == "")
                    cmd.Parameters.Add("PN_PICKUP_DATE", OracleType.VarChar, 25).Value = DBNull.Value;//Convert.ToDateTime(Pick_Dat_up);
                else
                    cmd.Parameters.Add("PN_PICKUP_DATE", OracleType.VarChar, 25).Value = Convert.ToDateTime(PICKUP_DATE);

                cmd.Parameters.Add("PN_FREE_PIKCUP_FLAG", OracleType.VarChar, 1).Value = Convert.ToString(FREE_PIKCUP_FLAG);
                cmd.Parameters.Add("PN_PICKUP_LOC_CD", OracleType.VarChar, 5).Value = Convert.ToString(PICKUP_LOC_CD);
                cmd.Parameters.Add("PN_PICKUP_DRIVER", OracleType.VarChar, 30).Value = Convert.ToString(PICKUP_DRIVER);
                cmd.Parameters.Add("PN_PIKCUP_REMARKS", OracleType.VarChar, 500).Value = Convert.ToString(PIKCUP_REMARKS);
                cmd.Parameters.Add("PN_MMS_NUM", OracleType.VarChar, 20).Value = Convert.ToString(MMS_NUM);
                //new param added on 27 nov 2015
                cmd.Parameters.Add("PN_PROB_STR", OracleType.VarChar, 500).Value = Convert.ToString(PROB_STR);

                cmd.Parameters.Add("PN_CUST_REMARKS", OracleType.VarChar, 500).Value = Convert.ToString(CUST_REMARKS);
                cmd.Parameters.Add("PN_DLR_REMARKS", OracleType.VarChar, 500).Value = Convert.ToString(DLR_REMARKS);
                cmd.Parameters.Add("PN_APPRV_STATUS", OracleType.VarChar, 500).Value = Convert.ToString(APPRV_STATUS);

                cmd.Parameters.Add("PN_PART_EST_AMT", OracleType.Double, 500).Value = Convert.ToDouble(PART_EST_AMT); //string.IsNullOrEmpty(PART_EST_AMT) ? (double?)null : Convert.ToDouble(PART_EST_AMT);
                cmd.Parameters.Add("PN_OPR_EST_AMT", OracleType.Double, 500).Value = Convert.ToDouble(OPR_EST_AMT);//string.IsNullOrEmpty(OPR_EST_AMT) ? (double?)null : Convert.ToDouble(OPR_EST_AMT);
                cmd.Parameters.Add("PN_WASH_TYPE", OracleType.VarChar, 500).Value = WASH_TYPE;

                //Start Added new three input parameters by mukesh sinha 17APRIL2020
                cmd.Parameters.Add("PN_OCAS_CNT", OracleType.Int32, 8).Value = OCAS_CNT;
                cmd.Parameters.Add("PN_SAVE_CNT", OracleType.Int32, 8).Value = SAVE_CNT;
                cmd.Parameters.Add("PN_SENT_CNT", OracleType.Int32, 8).Value = SENT_CNT;
                //End Added new three input parameters by mukesh sinha 17APRIL2020         

                // added new input parameter PN_ADD_CHK by mukesh sinha 10SEPT2020
                cmd.Parameters.Add("PN_ADD_CHK", OracleType.VarChar, 4000).Value = ADD_CHK;

                cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PN_REJ_PRT_LAB_INS_STR", OracleType.VarChar, 2000).Value = REJ_PRT_LAB_INS_STR;

                // added Final Inspection input parameter by mukesh sinha 22SEPT2020          
                cmd.Parameters.Add("PN_FINAL_INSPECTION", OracleType.VarChar, 1).Value = FINAL_INSPECTION;

                // added pn_ccp_yn pn_ccp_num input parameter by gagan sharma 6MAY2022 
                cmd.Parameters.Add("pn_ccp_yn", OracleType.VarChar, 1).Value = ccp_yn;
                cmd.Parameters.Add("pn_ccp_num", OracleType.VarChar, 12).Value = ccp_num;
                //Added pn_holdup_reasn_cd by Nagmani 25NOV2022
                cmd.Parameters.Add("pn_holdup_reasn_cd", OracleType.VarChar, 200).Value = holdup_reasn_cd;

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();

                //if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) != "0")
                //{
                //    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                //    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                //    response.result = null;
                //    con.Close();
                //    return response;
                //}
                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    con.Close();
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = Convert.ToString(cmd.Parameters["po_err_msg"].Value);


                    Logger.SuccessLogPrint("UpdateJCDetails", "sp_jco_UPDATE_dtl", "'pn_jc_num': '" + JC_NUM + "','pn_user_id':'" + USER_ID + "','pn_srv_cat_cd':'" + SRV_CAT_CD + "','pn_sub_srv_type_cd':'" + SUB_SRV_TYPE_CD + "','pn_promised_date':'"
                    + PROMISED_DATE + "','pn_sa_adv':'" + SA_ADV + "','pn_tech_adv':'" + TECH_ADV + "','pn_bay_cd':'" + BAY_CD + "','pn_group_cd':'" + GROUP_CD + "','pn_tech_cd':'" + TECH_CD
                    + "','pn_demand_ins_str':'" + DEMAND_INS_STR + "','pn_part_ins_str':'" + PART_INS_STR + "','pn_labor_ins_str':'" + LABOR_INS_STR + ",'pn_unapprv_fit_str':'" + UNAPPRV_FIT_STR + "','pn_pickup_type':'" + PICKUP_TYPE + ",'po_pickup_date':'" + PICKUP_DATE
                    + "','pn_free_pikcup_flag':'" + FREE_PIKCUP_FLAG + "','pn_pickup_loc_cd':'" + PICKUP_LOC_CD + "','pn_pickup_driver':'" + PICKUP_DRIVER + "','pn_pikcup_remarks':'" + PIKCUP_REMARKS + "','pn_mms_num':'" + MMS_NUM + "','pn_prob_str':'"
                    + PROB_STR + "','PN_CUST_REMARKS':'" + CUST_REMARKS + "','PN_DLR_REMARKS':'" + DLR_REMARKS + "','PN_APPRV_STATUS':'" + APPRV_STATUS + "','PN_PART_EST_AMT':'" + PART_EST_AMT + "','PN_OPR_EST_AMT':'" + OPR_EST_AMT + "','REJ_PRT_LAB_INS_STR':'" + REJ_PRT_LAB_INS_STR + "','PN_WASH_TYPE':'" + WASH_TYPE
                    + "','PN_OCAS_CNT':'" + OCAS_CNT + "','PN_SAVE_CNT':'" + SAVE_CNT + "','PN_SENT_CNT':'" + SENT_CNT + "','final_Inspection':'" + FINAL_INSPECTION + "','PN_ADD_CHK':'" + ADD_CHK + "','pn_ccp_yn':'" + ccp_yn + "','pn_ccp_num':'" + ccp_num + "', 'pn_holdup_reasn_cd':'" + holdup_reasn_cd, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
                    response.result = null;
                }

            }
            catch (Exception ex)
            {
                var lineNumber = 0;
                const string lineSearch = ":line";
                var index = ex.StackTrace.LastIndexOf(lineSearch);
                var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = lineNumberText + ex.Message; //ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();

                Logger.ErrorLogException("UpdateJCDetails", "sp_jco_UPDATE_dtl", "'pn_jc_num': '" + JC_NUM + "','pn_user_id':'" + USER_ID + "','pn_srv_cat_cd':'" + SRV_CAT_CD + "','pn_sub_srv_type_cd':'" + SUB_SRV_TYPE_CD + "','pn_promised_date':'"
                 + PROMISED_DATE + "','pn_sa_adv':'" + SA_ADV + "','pn_tech_adv':'" + TECH_ADV + "','pn_bay_cd':'" + BAY_CD + "','pn_group_cd':'" + GROUP_CD + "','pn_tech_cd':'" + TECH_CD
                 + "','pn_demand_ins_str':'" + DEMAND_INS_STR + "','pn_part_ins_str':'" + PART_INS_STR + "','pn_labor_ins_str':'" + LABOR_INS_STR + ",'pn_unapprv_fit_str':'" + UNAPPRV_FIT_STR + "','pn_pickup_type':'" + PICKUP_TYPE + ",'po_pickup_date':'" + PICKUP_DATE
                 + "','pn_free_pikcup_flag':'" + FREE_PIKCUP_FLAG + "','pn_pickup_loc_cd':'" + PICKUP_LOC_CD + "','pn_pickup_driver':'" + PICKUP_DRIVER + "','pn_pikcup_remarks':'" + PIKCUP_REMARKS + "','pn_mms_num':'" + MMS_NUM + "','pn_prob_str':'"
                 + PROB_STR + "','PN_CUST_REMARKS':'" + CUST_REMARKS + "','PN_DLR_REMARKS':'" + DLR_REMARKS + "','PN_APPRV_STATUS':'" + APPRV_STATUS + "','PN_PART_EST_AMT':'" + PART_EST_AMT + "','PN_OPR_EST_AMT':'" + OPR_EST_AMT + "','REJ_PRT_LAB_INS_STR':'" + REJ_PRT_LAB_INS_STR + "','PN_WASH_TYPE':'" + WASH_TYPE
                 + "','PN_OCAS_CNT':'" + OCAS_CNT + "','PN_SAVE_CNT':'" + SAVE_CNT + "','PN_SENT_CNT':'" + SENT_CNT + "','final_Inspection':'" + FINAL_INSPECTION + "','PN_ADD_CHK':'" + ADD_CHK + "','pn_ccp_yn':'" + ccp_yn + "','pn_ccp_num':'" + ccp_num + "', 'pn_holdup_reasn_cd':'" + holdup_reasn_cd, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GetGroupDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public BaseListReturnType<GroupDetails> GetGroupDetails(string userID)
        {

            BaseListReturnType<GroupDetails> response = new BaseListReturnType<GroupDetails>();

            GroupDetails Typedetail = null;
            List<GroupDetails> Details = new List<GroupDetails>();
            List<Group_Details> FAILURE_HIST_LIST = new List<Group_Details>();
            Group_Details FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_group_dtl;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userID;
                //output varibale
                cmd.Parameters.Add("po_group_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_group_refcur"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new Group_Details();
                        FAILURE_HIST_CURSOR.GROUP_CD = Convert.ToString(dr["GROUP_CD"]);
                        FAILURE_HIST_CURSOR.GROUP_NAME = Convert.ToString(dr["GROUP_NAME"]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new GroupDetails();
                    Typedetail.Group_Details = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetGroupDetails", "pkg_jco_1.sp_jco_get_group_dtl", "'pn_user_id': '" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value)
    + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetGroupDetails", "sp_jco_get_group_dtl", "'pn_user_id': '" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetTechAdv
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public BaseListReturnType<GetTechAdv> GetTechAdv(string userID)
        {

            BaseListReturnType<GetTechAdv> response = new BaseListReturnType<GetTechAdv>();

            GetTechAdv Typedetail = null;
            List<GetTechAdv> Details = new List<GetTechAdv>();
            List<GetTech_Adv> FAILURE_HIST_LIST = new List<GetTech_Adv>();
            GetTech_Adv FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_tech_adv;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userID;
                //output varibale
                cmd.Parameters.Add("po_tech_adv_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_tech_adv_refcur"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new GetTech_Adv();
                        FAILURE_HIST_CURSOR.EMP_CD = Convert.ToString(dr[0]);//Convert.ToString(dr["EMP_CD"]);
                        FAILURE_HIST_CURSOR.EMP_NAME = Convert.ToString(dr[1]);//Convert.ToString(dr["EMP_NAME"]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new GetTechAdv();
                    Typedetail.GetTech_Adv = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetTechAdv", "sp_jco_get_tech_adv", "'pn_user_id': '" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetTechAdv", "sp_jco_get_tech_adv", "'pn_user_id': '" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetSaAdv
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public BaseListReturnType<GetSaAdv> GetSaAdv(string userID)
        {

            BaseListReturnType<GetSaAdv> response = new BaseListReturnType<GetSaAdv>();

            GetSaAdv Typedetail = null;
            List<GetSaAdv> Details = new List<GetSaAdv>();
            List<GetSa_Adv> FAILURE_HIST_LIST = new List<GetSa_Adv>();
            GetSa_Adv FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_sa_adv;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userID;
                //output varibale
                cmd.Parameters.Add("po_srv_adv_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_srv_adv_refcur"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new GetSa_Adv();
                        FAILURE_HIST_CURSOR.EMP_CD = Convert.ToString(dr[0]);
                        FAILURE_HIST_CURSOR.EMP_NAME = Convert.ToString(dr[1]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new GetSaAdv();
                    Typedetail.GetSa_Adv = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetTechAdv", "sp_jco_get_tech_adv", "'pn_user_id': '" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetTechAdv", "sp_jco_get_tech_adv", "'pn_user_id': '" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetServiceCategory
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public BaseListReturnType<GetServiceCategory> GetServiceCategory(string userID)
        {

            BaseListReturnType<GetServiceCategory> response = new BaseListReturnType<GetServiceCategory>();

            GetServiceCategory Typedetail = null;
            List<GetServiceCategory> Details = new List<GetServiceCategory>();
            List<SRVCAT> FAILURE_HIST_LIST = new List<SRVCAT>();
            SRVCAT FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_srv_cat;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userID;
                //output varibale
                cmd.Parameters.Add("PO_SRV_CAT_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_SRV_CAT_REFCUR"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new SRVCAT();
                        FAILURE_HIST_CURSOR.LIST_CODE = Convert.ToString(dr["LIST_CODE"]);
                        FAILURE_HIST_CURSOR.LIST_DESC = Convert.ToString(dr["LIST_DESC"]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new GetServiceCategory();
                    Typedetail.SRVCAT = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetServiceCategory", "sp_jco_get_srv_cat", "'pn_user_id': '" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetServiceCategory", "sp_jco_get_srv_cat", "'pn_user_id': '" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetCityDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public BaseListReturnType<GetCityDetails> GetCityDetails(string userID)
        {

            BaseListReturnType<GetCityDetails> response = new BaseListReturnType<GetCityDetails>();

            GetCityDetails Typedetail = null;
            List<GetCityDetails> Details = new List<GetCityDetails>();
            List<CITYDTL> FAILURE_HIST_LIST = new List<CITYDTL>();
            CITYDTL FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jco_get_city_dtl;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userID;
                //output varibale
                cmd.Parameters.Add("po_city_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Number, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_city_refcur"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new CITYDTL();
                        FAILURE_HIST_CURSOR.CITY_CD = Convert.ToString(dr["CITY_CD"]);
                        FAILURE_HIST_CURSOR.CITY_DESC = Convert.ToString(dr["CITY_DESC"]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new GetCityDetails();
                    Typedetail.CITYDTL = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetServiceCategory", "sp_jco_get_srv_cat", "'pn_user_id': '" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetServiceCategory", "sp_jco_get_srv_cat", "'pn_user_id': '" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetRFTagDetails
        public BaseListReturnType<RfTagDetails> GetRFTagDetails(string parentGroup, string dealerCode, string locationCode, string userId, string vin, string srvCategory)
        {
            BaseListReturnType<RfTagDetails> response = new BaseListReturnType<RfTagDetails>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            RfTagDetails Typedetail = null;
            List<RfTagDetails> Details = new List<RfTagDetails>();
            //List<LoginResponse> LOGIN_LIST = new List<LoginResponse>();
            //LoginResponse Login_Res;
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.SP_GET_RFTAGDTL;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("pn_parent_group", OracleType.VarChar, 20).Value = parentGroup;
                cmd.Parameters.Add("pn_dealer_cd", OracleType.Int32, 8).Value = Convert.ToInt32(dealerCode);
                cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 20).Value = locationCode;
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = userId;
                cmd.Parameters.Add("pn_vin", OracleType.VarChar, 22).Value = vin;
                cmd.Parameters.Add("PO_AVTS_YN", OracleType.VarChar, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_RFTAG_NO", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CHECKIN_DATETIME", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PN_SRV_CAT_CD", OracleType.VarChar, 200).Value = srvCategory;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<RfTagDetails>();

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    Typedetail = new RfTagDetails();
                    Typedetail.AVTS = Convert.ToString(cmd.Parameters["PO_AVTS_YN"].Value);
                    Typedetail.RFTNO = Convert.ToString(cmd.Parameters["PO_RFTAG_NO"].Value);
                    Typedetail.CDATETIME = Convert.ToString(cmd.Parameters["PO_CHECKIN_DATETIME"].Value);
                    //LOGIN_LIST.Add(Login_Res);
                }

                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                //Typedetail = new LoginReturn();
                //Typedetail.Login_Response = LOGIN_LIST;
                Details.Add(Typedetail);
                response.result = Details;
                Logger.SuccessLogPrint("GetRFTagDetails", "SP_GET_RFTAGDTL", "'pn_parent_group':'" + parentGroup + "','pn_dealer_cd':'" + dealerCode + "','pn_loc_Cd':'" + locationCode + "''pn_user_id':'" + userId + "','pn_vin':'" + vin + "','PN_SRV_CAT_CD':'" + srvCategory, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetRFTagDetails", "SP_GET_RFTAGDTL", "'pn_parent_group':'" + parentGroup + "','pn_dealer_cd':'" + dealerCode + "','pn_loc_Cd':'" + locationCode + "''pn_user_id':'" + userId + "','pn_vin':'" + vin + "','PN_SRV_CAT_CD':'" + srvCategory, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region HistoryMaster
        /// <summary>
        /// 
        /// </summary>
        /// <param name="RegNum"></param>
        /// <returns></returns>
        public BaseListReturnType<HistoryMaster> HistoryMaster(string RegNum)
        {

            BaseListReturnType<HistoryMaster> response = new BaseListReturnType<HistoryMaster>();

            HistoryMaster Typedetail = null;
            List<HistoryMaster> Details = new List<HistoryMaster>();
            List<History_Master> FAILURE_HIST_LIST = new List<History_Master>();
            History_Master FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_history_master;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pn_reg_num", OracleType.VarChar, 20).Value = Convert.ToString(RegNum);
                //output varibale
                cmd.Parameters.Add("po_jc_hist_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }

                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["po_jc_hist_refcur"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new History_Master();
                        FAILURE_HIST_CURSOR.K1 = Convert.ToString(dr[0]);
                        FAILURE_HIST_CURSOR.K2 = Convert.ToString(dr[2]);
                        FAILURE_HIST_CURSOR.K3 = Convert.ToString(dr[3]);
                        FAILURE_HIST_CURSOR.K4 = Convert.ToString(dr[4]);
                        FAILURE_HIST_CURSOR.K5 = Convert.ToString(dr[5]);
                        FAILURE_HIST_CURSOR.K6 = Convert.ToString(dr[6]);
                        FAILURE_HIST_CURSOR.K7 = Convert.ToString(dr[7]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new HistoryMaster();
                    Typedetail.History_Master = FAILURE_HIST_LIST;
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("HistoryMaster", "PKG_JCO.sp_get_history_master", "'RegNum': '" + RegNum, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("HistoryMaster", "PKG_JCO.sp_get_history_master", "'RegNum': '" + RegNum, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetRFTagScanTime
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dealerCode"></param>
        /// <param name="locationCode"></param>
        /// <param name="userId"></param>
        /// <param name="rftagNo"></param>
        /// <param name="srvCategory"></param>
        /// <returns></returns>
        public BaseListReturnType<GetRFTagScanTime> GetRFTagScanTime(Int32 dealerCode, string locationCode, string userId, string rftagNo, string srvCategory)
        {
            BaseListReturnType<GetRFTagScanTime> response = new BaseListReturnType<GetRFTagScanTime>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            GetRFTagScanTime Typedetail = null;
            List<GetRFTagScanTime> Details = new List<GetRFTagScanTime>();
            //List<LoginResponse> LOGIN_LIST = new List<LoginResponse>();
            //LoginResponse Login_Res;
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.SP_GET_RFTAG_SCANTIME;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("pn_dealer_cd", OracleType.Int32, 8).Value = Convert.ToInt32(dealerCode);
                cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 20).Value = Convert.ToString(locationCode);
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = Convert.ToString(userId);
                cmd.Parameters.Add("pn_rftag_no", OracleType.VarChar, 50).Value = Convert.ToString(rftagNo);

                cmd.Parameters.Add("po_checkin_datetime", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_err_cd", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_err_msg", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PN_SRV_CAT_CD", OracleType.VarChar, 200).Value = srvCategory;

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["po_err_msg"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                    response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                Details = new List<GetRFTagScanTime>();
                int cntRowsEffected = cmd.ExecuteNonQuery();
                //check error 
                if (Convert.ToString(cmd.Parameters["po_err_cd"].Value) == "0")
                {
                    string empCd = Convert.ToString(cmd.Parameters["po_emp_cd"].Value);
                    Typedetail = new GetRFTagScanTime();
                    Typedetail.ROWCNT = cntRowsEffected.ToString();
                    Typedetail.CDATETIME = Convert.ToString(cmd.Parameters["po_checkin_datetime"].Value);
                }

                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                //Typedetail = new LoginReturn();
                //Typedetail.Login_Response = LOGIN_LIST;
                Details.Add(Typedetail);
                response.result = Details;
                Logger.SuccessLogPrint("GetRFTagScanTime", "SP_GET_RFTAG_SCANTIME", "'pn_dealer_cd':'" + dealerCode + "','pn_loc_Cd':'" + locationCode + "','pn_user_id':'" + userId + "''pn_rftag_no':'" + rftagNo + "','PN_SRV_CAT_CD':'" + srvCategory, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));

            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetRFTagScanTime", "SP_GET_RFTAG_SCANTIME", "'pn_dealer_cd':'" + dealerCode + "','pn_loc_Cd':'" + locationCode + "','pn_user_id':'" + userId + "''pn_rftag_no':'" + rftagNo + "','PN_SRV_CAT_CD':'" + srvCategory, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region NewBillPrint
        /// <summary>
        /// GetDrivableAdvice For Suzuki Connect Gen-2
        /// </summary>
        /// <param name="P_REG_NUM"></param>
        /// <param name="P_FAILURE_ID"></param>
        /// <returns></returns>
        public BaseListReturnType<NewBillPrint> NewBillPrint(string userID, string JobCardnum)
        {

            BaseListReturnType<NewBillPrint> response = new BaseListReturnType<NewBillPrint>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            NewBillPrint Typedetail = null;
            List<NewBillPrint> Details = new List<NewBillPrint>();
            List<PO_DEMAND_REF_CUR> DEMAND_REF_CUR = new List<PO_DEMAND_REF_CUR>();
            List<PO_PART_REF_CUR> PART_REF_CUR = new List<PO_PART_REF_CUR>();
            List<PO_INV_REF_CUR> INV_REF_CUR = new List<PO_INV_REF_CUR>();
            List<PO_HIST1_DTL_REF_CUR> HIST1_DTL_REF_CUR = new List<PO_HIST1_DTL_REF_CUR>();
            List<PO_HIST2_DTL_REF_CUR> HIST2_DTL_REF_CUR = new List<PO_HIST2_DTL_REF_CUR>();
            List<PO_SUBSCRIBER_DET> SUBSCRIBER_DET = new List<PO_SUBSCRIBER_DET>();
            List<NewBillResponse> newBillResponseList = new List<NewBillResponse>();
            NewBillResponse newBillResponse;
            PO_DEMAND_REF_CUR DEMAND_REF_CURSOR;
            PO_PART_REF_CUR PART_REF_CURSOR;
            PO_INV_REF_CUR INV_REF_CURSOR;
            PO_HIST1_DTL_REF_CUR HIST1_DTL_CURSOR;
            PO_HIST2_DTL_REF_CUR HIST2_DTL_CURSOR;
            PO_SUBSCRIBER_DET SUBSCRIBER_DET_CURSOR;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_jcbill_print;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = Convert.ToString(userID);
                cmd.Parameters.Add("PN_JC_NO", OracleType.VarChar, 12).Value = Convert.ToString(JobCardnum);

                cmd.Parameters.Add("PO_JC_DATE", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_ID", OracleType.VarChar, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_NAME", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_ADD", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CUST_PHONE", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CAR_USER_NAME", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_EMAIL", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_REG_NUM", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CHASSIS_NUM", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ENGINE_NUM", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_MODEL", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_MILEAGE", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SOLD_BY", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SOLD_DATE", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_KEY_NO", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_TV_SALE_DATE", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SERVICE_TYPE", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                //new param added as on 21 may 2015

                cmd.Parameters.Add("PO_SUB_SERVICE_TYPE", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                //----

                cmd.Parameters.Add("PO_DEMAND_REF_CUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_INSTRUCTIONS", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SRV_ADV", OracleType.VarChar, 120).Direction = ParameterDirection.Output;

                //new param added as on 21 may 2015
                cmd.Parameters.Add("PO_PROM_INTIAL_DATE", OracleType.VarChar, 120).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PROM_INTIAL_TIME", OracleType.VarChar, 120).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PROM_REVD_DATE", OracleType.VarChar, 120).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_PROM_REVD_TIME", OracleType.VarChar, 120).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_TECH_CIRCULAR_DESC", OracleType.VarChar, 120).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_EST_SCH_LABOR_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_EST_SCH_PART_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_RE_SCH_EST_LABOR_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_RE_SCH_EST_PART_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;

                //these are fields not marked as new  in excel
                cmd.Parameters.Add("PO_EST_LABOR_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_EST_PART_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_RE_EST_LABOR_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_RE_EST_PART_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                //----

                cmd.Parameters.Add("PO_PART_REF_CUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_GROUP_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_MECH_CD", OracleType.VarChar, 20).Direction = ParameterDirection.Output;

                //-**************			
                cmd.Parameters.Add("PO_CREATED_BY", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_INV_REF_CUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                //cmd.Parameters.Add("po_group", OracleDbType.Varchar2, 5).Direction = ParameterDirection.Output;

                // new param added again for history
                cmd.Parameters.Add("PO_HIST1_JC_NO", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_JC_DT", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_MILEAGE", OracleType.Number, 10).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_GROUP", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_SRV_ADV", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_MECHANIC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_LBR_AMT", OracleType.Int32, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_PART_AMT", OracleType.Int32, 10).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_SRV_TYPE", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_PSF_STAT", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_CSI_PERT", OracleType.Int32, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST1_REMARKS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST1_DTL_REF_CUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                // for hist2

                cmd.Parameters.Add("PO_HIST2_JC_NO", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_JC_DT", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_MILEAGE", OracleType.Number, 10).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_GROUP", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_SRV_ADV", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_MECHANIC", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_LBR_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_PART_AMT", OracleType.Number, 10).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_SRV_TYPE", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_PSF_STAT", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_CSI_PERT", OracleType.Number, 10).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_HIST2_REMARKS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_HIST2_DTL_REF_CUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                // Added new parameter and ref cursor PO_SUBS_YN, PO_PVO_SUBSCRIBER_DET added by mukesh sinha 15NOV2019
                cmd.Parameters.Add("PO_SUBS_YN", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_SUBSCRIBER_DET", OracleType.Cursor).Direction = ParameterDirection.Output;

                //start added by gagan sharma 6may2022
                cmd.Parameters.Add("po_ccp_yn", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_ccp_NUM", OracleType.VarChar, 12).Direction = ParameterDirection.Output;
                //end by gagan sharma 6may2022

                //PO_FC_OK PO_CATALYTIC_CONV_NUM Added by GAGAN SHARMA 20 FEB 2023
                cmd.Parameters.Add("PO_FC_OK_DATE", OracleType.DateTime).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CATALYTIC_CONV_NUM", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                //end by gagan sharma 20 FEB 2023

                //PO_CORP_CUST_FLAG  PO_CORP_NAME Added by GAGAN SHARMA 5 JULY 2023
                cmd.Parameters.Add("PO_CORP_CUST_FLAG", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CORP_NAME", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                //end by gagan sharma 5 JULY 2023

                //***************

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                //Details = new List<NewBillPrint>();

                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    newBillResponse = new NewBillResponse();
                    newBillResponse.JD = cmd.Parameters["PO_JC_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ID = cmd.Parameters["PO_CUST_ID"].Value.ToString().Replace(@"\", "");
                    newBillResponse.NM = cmd.Parameters["PO_CUST_NAME"].Value.ToString().Replace(@"\", "");
                    newBillResponse.AD = cmd.Parameters["PO_CUST_ADD"].Value.ToString().Replace(@"\", "");
                    newBillResponse.CP = cmd.Parameters["PO_CUST_PHONE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.UN = cmd.Parameters["PO_CAR_USER_NAME"].Value.ToString().Replace(@"\", "");
                    newBillResponse.EM = cmd.Parameters["PO_EMAIL"].Value.ToString().Replace(@"\", "");
                    newBillResponse.RN = cmd.Parameters["PO_REG_NUM"].Value.ToString().Replace(@"\", "");
                    newBillResponse.CN = cmd.Parameters["PO_CHASSIS_NUM"].Value.ToString().Replace(@"\", "");
                    newBillResponse.EN = cmd.Parameters["PO_ENGINE_NUM"].Value.ToString().Replace(@"\", "");
                    newBillResponse.MD = cmd.Parameters["PO_MODEL"].Value.ToString().Replace(@"\", "");
                    newBillResponse.MI = cmd.Parameters["PO_MILEAGE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.XX = cmd.Parameters["PO_SOLD_BY"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PO_SOLD_DATE = cmd.Parameters["PO_SOLD_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.KN = cmd.Parameters["PO_KEY_NO"].Value.ToString().Replace(@"\", "");
                    newBillResponse.RR = cmd.Parameters["PO_TV_SALE_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ST = cmd.Parameters["PO_SERVICE_TYPE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.SST = cmd.Parameters["PO_SUB_SERVICE_TYPE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.IN = cmd.Parameters["PO_INSTRUCTIONS"].Value.ToString().Replace(@"\", "");
                    newBillResponse.AC = cmd.Parameters["PO_SRV_ADV"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PID = cmd.Parameters["PO_PROM_INTIAL_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PIT = cmd.Parameters["PO_PROM_INTIAL_TIME"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PRD = cmd.Parameters["PO_PROM_REVD_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PRT = cmd.Parameters["PO_PROM_REVD_TIME"].Value.ToString().Replace(@"\", "");
                    newBillResponse.TCD = cmd.Parameters["PO_TECH_CIRCULAR_DESC"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ESLT = cmd.Parameters["PO_EST_SCH_LABOR_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ESPT = cmd.Parameters["PO_EST_SCH_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.RSELT = cmd.Parameters["PO_RE_SCH_EST_LABOR_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.RSEPT = cmd.Parameters["PO_RE_SCH_EST_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ELA = cmd.Parameters["PO_EST_LABOR_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.EPA = cmd.Parameters["PO_EST_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.RELA = cmd.Parameters["PO_RE_EST_LABOR_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.REPA = cmd.Parameters["PO_RE_EST_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.GCD = cmd.Parameters["PO_GROUP_CD"].Value.ToString().Replace(@"\", "");
                    newBillResponse.MCD = cmd.Parameters["PO_MECH_CD"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PO_CREATED_BY = cmd.Parameters["PO_CREATED_BY"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1JN = cmd.Parameters["PO_HIST1_JC_NO"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1JD = cmd.Parameters["PO_HIST1_JC_DT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1MLG = cmd.Parameters["PO_HIST1_MILEAGE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1GRP = cmd.Parameters["PO_HIST1_GROUP"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PO_HIST1_SRV_ADV = cmd.Parameters["PO_HIST1_SRV_ADV"].Value.ToString().Replace(@"\", "");

                    newBillResponse.H1MCH = cmd.Parameters["PO_HIST1_MECHANIC"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PO_HIST1_LBR_AMT = cmd.Parameters["PO_HIST1_LBR_AMT"].Value.ToString().Replace(@"\", "");

                    newBillResponse.H1PA = cmd.Parameters["PO_HIST1_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.PO_HIST1_SRV_TYPE = cmd.Parameters["PO_HIST1_SRV_TYPE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1PS = cmd.Parameters["PO_HIST1_PSF_STAT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1CP = cmd.Parameters["PO_HIST1_CSI_PERT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H1RM = cmd.Parameters["PO_HIST1_REMARKS"].Value.ToString().Replace(@"\", "");

                    newBillResponse.H2JN = cmd.Parameters["PO_HIST2_JC_NO"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2JD = cmd.Parameters["PO_HIST2_JC_DT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2MLG = cmd.Parameters["PO_HIST2_MILEAGE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2GRP = cmd.Parameters["PO_HIST2_GROUP"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2SA = cmd.Parameters["PO_HIST2_SRV_ADV"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2MCH = cmd.Parameters["PO_HIST2_MECHANIC"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2LA = cmd.Parameters["PO_HIST2_LBR_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2PA = cmd.Parameters["PO_HIST2_PART_AMT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2ST = cmd.Parameters["PO_HIST2_SRV_TYPE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2PS = cmd.Parameters["PO_HIST2_PSF_STAT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2CP = cmd.Parameters["PO_HIST2_CSI_PERT"].Value.ToString().Replace(@"\", "");
                    newBillResponse.H2RM = cmd.Parameters["PO_HIST2_REMARKS"].Value.ToString().Replace(@"\", "");
                    newBillResponse.SUBS_YN = cmd.Parameters["PO_SUBS_YN"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ccp_yn = cmd.Parameters["po_ccp_yn"].Value.ToString().Replace(@"\", "");
                    newBillResponse.ccp_num = cmd.Parameters["po_ccp_NUM"].Value.ToString().Replace(@"\", "");
                    newBillResponse.FC_OK = cmd.Parameters["PO_FC_OK_DATE"].Value.ToString().Replace(@"\", "");
                    newBillResponse.CATALYTIC_NUM = cmd.Parameters["PO_CATALYTIC_CONV_NUM"].Value.ToString().Replace(@"\", "");
                    newBillResponse.CORP_CUST_FLAG = cmd.Parameters["PO_CORP_CUST_FLAG"].Value.ToString().Replace(@"\", "");
                    newBillResponse.CORP_NAME = cmd.Parameters["PO_CORP_NAME"].Value.ToString().Replace(@"\", "");
                    newBillResponseList.Add(newBillResponse);

                    //Get value from output ref cursor
                    OracleDataReader dr1 = (OracleDataReader)cmd.Parameters["PO_DEMAND_REF_CUR"].Value;
                    while (dr1.Read())
                    {
                        DEMAND_REF_CURSOR = new PO_DEMAND_REF_CUR();
                        DEMAND_REF_CURSOR.DEMAND_DESC = Convert.ToString(dr1[0]);
                        DEMAND_REF_CUR.Add(DEMAND_REF_CURSOR);
                    }

                    //Get value from output ref cursor
                    OracleDataReader dr2 = (OracleDataReader)cmd.Parameters["PO_INV_REF_CUR"].Value;
                    while (dr2.Read())
                    {
                        INV_REF_CURSOR = new PO_INV_REF_CUR();
                        INV_REF_CURSOR.INVENTORY_DESC = Convert.ToString(dr2["INVENTORY_DESC"]);
                        INV_REF_CURSOR.INV_REMARKS = Convert.ToString(dr2["INV_REMARKS"]);
                        INV_REF_CUR.Add(INV_REF_CURSOR);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr3 = (OracleDataReader)cmd.Parameters["PO_PART_REF_CUR"].Value;
                    while (dr3.Read())
                    {

                        PART_REF_CURSOR = new PO_PART_REF_CUR();
                        PART_REF_CURSOR.PART_DESC = Convert.ToString(dr3["PART_DESC"]);
                        PART_REF_CURSOR.ACCEPT_YN = Convert.ToString(dr3["ACCEPT_YN"]);
                        PART_REF_CURSOR.REJECT_REASON = Convert.ToString(dr3["REJECT_REASON"]);
                        PART_REF_CUR.Add(PART_REF_CURSOR);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr4 = (OracleDataReader)cmd.Parameters["PO_HIST1_DTL_REF_CUR"].Value;
                    while (dr4.Read())
                    {

                        HIST1_DTL_CURSOR = new PO_HIST1_DTL_REF_CUR();
                        HIST1_DTL_CURSOR.OPR_CD = Convert.ToString(dr4["OPR_CD"]);
                        HIST1_DTL_CURSOR.OPR_DESC = Convert.ToString(dr4["OPR_DESC"]);
                        HIST1_DTL_CURSOR.QTY = Convert.ToString(dr4["QTY"]);
                        HIST1_DTL_REF_CUR.Add(HIST1_DTL_CURSOR);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr5 = (OracleDataReader)cmd.Parameters["PO_HIST2_DTL_REF_CUR"].Value;
                    while (dr5.Read())
                    {

                        HIST2_DTL_CURSOR = new PO_HIST2_DTL_REF_CUR();
                        HIST2_DTL_CURSOR.OPR_CD = Convert.ToString(dr5["OPR_CD"]);
                        HIST2_DTL_CURSOR.OPR_DESC = Convert.ToString(dr5["OPR_DESC"]);
                        HIST2_DTL_CURSOR.QTY = Convert.ToString(dr5["QTY"]);
                        HIST2_DTL_REF_CUR.Add(HIST2_DTL_CURSOR);
                    }

                    //Get value from output ref cursor
                    OracleDataReader dr6 = (OracleDataReader)cmd.Parameters["PO_SUBSCRIBER_DET"].Value;
                    while (dr6.Read())
                    {

                        SUBSCRIBER_DET_CURSOR = new PO_SUBSCRIBER_DET();
                        SUBSCRIBER_DET_CURSOR.DMS_SUBSCRIBER_ID = Convert.ToString(dr6["DMS_SUBSCRIBER_ID"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_NAME = Convert.ToString(dr6["SUBS_NAME"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_EMAIL = Convert.ToString(dr6["SUBS_EMAIL"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_DOB = Convert.ToString(dr6["SUBS_DOB"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_ADD1 = Convert.ToString(dr6["SUBS_ADD1"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_ADD2 = Convert.ToString(dr6["SUBS_ADD2"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_ADD3 = Convert.ToString(dr6["SUBS_ADD3"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_PIN = Convert.ToString(dr6["SUBS_PIN"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_CITY_CD = Convert.ToString(dr6["SUBS_CITY_CD"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_CITY_DESC = Convert.ToString(dr6["SUBS_CITY_DESC"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_STATE_CD = Convert.ToString(dr6["SUBS_STATE_CD"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_STATE_DESC = Convert.ToString(dr6["SUBS_STATE_DESC"]);
                        SUBSCRIBER_DET_CURSOR.SUBS_MOBILE = Convert.ToString(dr6["SUBS_MOBILE"]);
                        SUBSCRIBER_DET.Add(SUBSCRIBER_DET_CURSOR);
                    }



                }
                Typedetail = new NewBillPrint();
                Typedetail.NewBill_Response = newBillResponseList;
                Typedetail.DEMAND_REF_CUR = DEMAND_REF_CUR;
                Typedetail.INV_REF_CUR = INV_REF_CUR;
                Typedetail.PART_REF_CUR = PART_REF_CUR;
                Typedetail.HIST1_DTL_REF_CUR = HIST1_DTL_REF_CUR;
                Typedetail.HIST2_DTL_REF_CUR = HIST2_DTL_REF_CUR;
                Typedetail.SUBSCRIBER_DET = SUBSCRIBER_DET;
                Details.Add(Typedetail);
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("NewBillPrint", "sp_jcbill_print", "'pn_user_id': '" + userID + "','pn_jc_no':'" + JobCardnum, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                //GetLineNumber(ex);
                Logger.ErrorLogException("NewBillPrint", "sp_jcbill_print", "'pn_user_id': '" + userID + "','pn_jc_no':'" + JobCardnum, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }

        #endregion

        #region GetAppointmentDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="dealer_cd"></param>
        /// <param name="loc_cd"></param>
        /// <param name="isTesting"></param>
        /// <returns></returns>
        public BaseListReturnType<AppointmentDetails> GetAppointmentDetails(string userID, Int32 dealer_cd, string loc_cd, string isTesting = "1")
        {

            BaseListReturnType<AppointmentDetails> response = new BaseListReturnType<AppointmentDetails>();
            //string isTesting = "1"
            AppointmentDetails Typedetail = null;
            List<AppointmentDetails> Details = new List<AppointmentDetails>();
            List<po_appointdtl_refcur> FAILURE_HIST_LIST = new List<po_appointdtl_refcur>();
            po_appointdtl_refcur FAILURE_HIST_CURSOR;
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.sp_get_appointdtl;
                cmd.CommandType = CommandType.StoredProcedure;
                if (isTesting == "1")
                {
                    cmd.Parameters.Add("pn_dealer_cd", OracleType.Int32, 8).Value = 10136;
                    cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 20).Value = "DPB";
                    cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = "bansrv.tab1";

                }
                else if (isTesting == "2")
                {
                    cmd.Parameters.Add("pn_dealer_cd", OracleType.Int32, 8).Value = null;
                    cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 20).Value = "DPB";
                    cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = "bansrv.tab1";

                }
                else if (isTesting == "3")
                {
                    cmd.Parameters.Add("pn_dealer_cd", OracleType.Int32, 8).Value = 10136;
                    cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 20).Value = null;
                    cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 20).Value = "bansrv.tab1";

                }
                else
                {
                    cmd.Parameters.Add("PN_DEALER_CD", OracleType.Int32, 8).Value = Convert.ToInt32(dealer_cd);
                    cmd.Parameters.Add("PN_LOC_CD", OracleType.VarChar, 20).Value = Convert.ToString(loc_cd);
                    cmd.Parameters.Add("PN_USER_ID", OracleType.VarChar, 20).Value = Convert.ToString(userID);
                }


                cmd.Parameters.Add("PO_APPNTDTL_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                int cntRowsEffected = cmd.ExecuteNonQuery();
                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    //Get value from output ref cursor
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_APPNTDTL_REFCUR"].Value;
                    while (dr.Read())
                    {
                        FAILURE_HIST_CURSOR = new po_appointdtl_refcur();
                        FAILURE_HIST_CURSOR.CUSTOMER_NAME = Convert.ToString(dr["CUSTOMER_NAME"]);
                        FAILURE_HIST_CURSOR.REG_NUM = Convert.ToString(dr["REG_NUM"]);
                        FAILURE_HIST_CURSOR.CONTACT_NO = Convert.ToString(dr["CONTACT_NO"]);
                        FAILURE_HIST_CURSOR.TIME_SLOT = Convert.ToString(dr["TIME_SLOT"]);
                        FAILURE_HIST_CURSOR.SRV_TYPE_DESC = Convert.ToString(dr["SRV_TYPE_DESC"]);
                        FAILURE_HIST_CURSOR.PICKUP_TYPE = Convert.ToString(dr["PICKUP_TYPE"]);
                        FAILURE_HIST_CURSOR.BOOKING_REMARKS = Convert.ToString(dr["BOOKING_REMARKS"]);
                        FAILURE_HIST_CURSOR.VECHILEMODEL = Convert.ToString(dr["VECHILEMODEL"]);
                        FAILURE_HIST_CURSOR.APPNT_FOR_DT = Convert.ToString(dr["APPNT_FOR_DT"]);
                        FAILURE_HIST_CURSOR.Appointment_Type = Convert.ToString(dr["Appointment_Type"]);
                        //FAILURE_HIST_CURSOR.REMARKS = Convert.ToString(dr[6]);
                        FAILURE_HIST_LIST.Add(FAILURE_HIST_CURSOR);
                    }
                    Typedetail = new AppointmentDetails();
                    Typedetail.GADTL = FAILURE_HIST_LIST;
                    Typedetail.ROWCNT = cntRowsEffected.ToString(); ; //consume input-output parameter
                    Details.Add(Typedetail);

                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }
                }

                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["po_err_cd"].Value.ToString());
                response.message = cmd.Parameters["po_err_msg"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetAppointmentDetails", "sp_get_appointdtl", "'pn_dealer_cd':'" + dealer_cd + "','pn_loc_Cd':'" + loc_cd + "','pn_user_id':'" + userID, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_FAILURE_HIST");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetAppointmentDetails", "sp_get_appointdtl", "'pn_dealer_cd':'" + dealer_cd + "','pn_loc_Cd':'" + loc_cd + "','pn_user_id':'" + userID, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion GetAppointmentDetails

        #region GetJCOpenDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Jcmodule"></param>
        /// <param name="UserID"></param>
        /// <param name="Parent_group"></param>
        /// <param name="Dealer_map_cd"></param>
        /// <param name="Loc_Cd"></param>
        /// <param name="Comp_fa"></param>
        /// <param name="Jcno"></param>
        /// <returns></returns>
        public BaseListReturnType<JCOpenDetails> GetJCOpenDetails(string Jcmodule, string UserID, string Parent_group, string Dealer_map_cd, string Loc_Cd, string Comp_fa, string Jcno)
        {

            BaseListReturnType<JCOpenDetails> response = new BaseListReturnType<JCOpenDetails>();
            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            JCOpenDetails Typedetail = null;
            List<JCOpenDetails> Details = new List<JCOpenDetails>();
            List<demand_refcur> DEMAND_REF_CUR = new List<demand_refcur>();
            List<PO_DLR_REFCUR> PO_DLR = new List<PO_DLR_REFCUR>();
            List<part_refcur_opne> part_refcur = new List<part_refcur_opne>();
            List<po_labor_Refcur> po_labor = new List<po_labor_Refcur>();
            List<po_inv_refcur> po_inv = new List<po_inv_refcur>();
            List<po_smcard_refcur> po_smcard = new List<po_smcard_refcur>();
            List<po_unapprfit_refcur> po_unapprfit = new List<po_unapprfit_refcur>();
            List<tech_camp_refcur> tech_camp = new List<tech_camp_refcur>();
            List<repair_act_refcur> repair_act = new List<repair_act_refcur>();
            List<comply_dtl_refcur> comply_dtl = new List<comply_dtl_refcur>();
            List<OpenDetails_Response> details_ResponseList = new List<OpenDetails_Response>();
            OpenDetails_Response details_Response;
            demand_refcur demand_refcur;
            part_refcur_opne part_refcur_opne;
            PO_DLR_REFCUR PO_DLR_REFCUR;
            po_labor_Refcur po_labor_Refcur;
            po_inv_refcur po_inv_refcur;
            po_smcard_refcur po_smcard_refcur;
            po_unapprfit_refcur po_unapprfit_refcur;
            tech_camp_refcur tech_camp_refcur;
            repair_act_refcur repair_act_refcur;
            comply_dtl_refcur comply_dtl_refcur;

            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.SP_JCO_GET_JC_OPEN_DTL;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("pn_jc_module", OracleType.VarChar, 200).Value = Convert.ToString(Jcmodule);
                cmd.Parameters.Add("pn_user_id", OracleType.VarChar, 200).Value = Convert.ToString(UserID);
                cmd.Parameters.Add("pn_parent_group", OracleType.VarChar, 200).Value = Convert.ToString(Parent_group);
                cmd.Parameters.Add("pn_dealer_map_cd", OracleType.VarChar, 20).Value = Convert.ToString(Dealer_map_cd);
                cmd.Parameters.Add("pn_loc_Cd", OracleType.VarChar, 200).Value = Convert.ToString(Loc_Cd);
                cmd.Parameters.Add("pn_comp_fa", OracleType.VarChar, 200).Value = Convert.ToString(Comp_fa);
                cmd.Parameters.Add("pn_jc_no", OracleType.VarChar, 200).Value = Convert.ToString(Jcno);
                cmd.Parameters.Add("po_jc_status", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_jc_status_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_omr", OracleType.Int32, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_srv_type_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_srv_type_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_sub_srv_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_sub_srv_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_bay_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_bay_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_srv_adv_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_srv_adv_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_group_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_group_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_tech_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_tech_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_tech_adv_Cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_tech_adv_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_ceo_approval", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_lastflwup_date", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_lastflwup_csi", OracleType.Int32, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_lastflwup_by", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pickup_type", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_pickup_type_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pickup_date", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pickup_loc", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pickup_loc_desc", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_driver", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_driver_desc", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pickup_remarks", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_free_pickup_yn", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_mms_num", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_intial_prom_date", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_revised_prom_date", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_jc_close_date", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_jc_open_date", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_cust_corp_status", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_rdtest_st_time", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_rdtest_st_km", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_rdtest_end_time", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_rdtest_end_km", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_est_sch_labor_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_est_sch_part_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_est_labor_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_est_part_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_re_est_labor_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_re_est_part_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_amc_yn", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_amc_num", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_amc_date", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_recall_yn", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_delay_reas_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_delay_reas_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_delay_reas_remarks", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_csi_reas_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_csi_reas_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_csi_reas_remarks", OracleType.VarChar, 4000).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_part_disc_perc", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_labour_disc_perc", OracleType.Double, 30).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_disc_auth_by_cd", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_disc_auth_by_desc", OracleType.VarChar, 1000).Direction = ParameterDirection.Output;

                //following are the cursors in o/p
                cmd.Parameters.Add("po_demand_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_part_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_labor_Refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_inv_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_smcard_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_unapprfit_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_tech_camp_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_repair_act_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                //added these two parameters on 18 jun 2015 from excel got on 18/06
                cmd.Parameters.Add("po_vts_card_num", OracleType.Int32, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_checkin_date", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                //added these three parameters on 25 aug 2015 from maruti  got on 24/08
                cmd.Parameters.Add("po_cus_out_amt", OracleType.Double, 30).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_pref_followup_time", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_comply_dtl_refcur", OracleType.Cursor).Direction = ParameterDirection.Output;
                //new param added on 27 nov 2015
                cmd.Parameters.Add("po_prob_str", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                //new param added on 20 mar 2017
                cmd.Parameters.Add("po_channel", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                cmd.Parameters.Add("po_wash_type", OracleType.VarChar, 500).Direction = ParameterDirection.Output;

                //start new param added on 13 JUNE 2019
                cmd.Parameters.Add("po_mms_address", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_mms_city", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_mms_district", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_mms_state", OracleType.VarChar, 50).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_mms_pin", OracleType.VarChar, 6).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_AUDIO_COUNT", OracleType.Int32, 25).Direction = ParameterDirection.Output;
                //end new param added on 13 JUNE 2019

                //start new param added on 23 SEPT 2019
                cmd.Parameters.Add("PO_VIN", OracleType.VarChar, 20).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_DLR_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                //End new param added on 23 SEPT 2019

                //start new param added on 07 Aug 2020
                cmd.Parameters.Add("po_ocas_cnt", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_save_cnt", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_sent_cnt", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                //End new param added on 07 Aug 2020

                cmd.Parameters.Add("PO_ERR_CD", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 200).Direction = ParameterDirection.Output;

                //Start new param added on 21SEPT2020
                cmd.Parameters.Add("PO_FINAL_INSPECTION", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                //End new param added on 21SEPT2020

                //Start new param added on 10SEPT2021
                cmd.Parameters.Add("PO_ADD_CHK", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                //Start new param added on 10SEPT2021

                //Added by gagan sharma 6MAY2022
                cmd.Parameters.Add("po_ccp_claim_yn", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_ccp_num", OracleType.VarChar, 12).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("po_ccp_type", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                //PO_CORP_CUST_FLAG  PO_CORP_NAME Added by GAGAN SHARMA 5 JULY 2023
                cmd.Parameters.Add("PO_CORP_CUST_FLAG", OracleType.VarChar, 1).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_CORP_NAME", OracleType.VarChar, 500).Direction = ParameterDirection.Output;
                //end by gagan sharma 5 JULY 2023

                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }



                //check error 
                if (Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) == "0")
                {
                    details_Response = new OpenDetails_Response();
                    details_Response.JS = NullValidator(Convert.ToString(cmd.Parameters["po_jc_status"].Value));
                    details_Response.JSD = Convert.ToString(cmd.Parameters["po_jc_status_desc"].Value);
                    details_Response.OMR = Convert.ToString(cmd.Parameters["po_omr"].Value);//((cmd.Parameters["po_omr"].Value != null && !(cmd.Parameters["po_omr"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_omr"].Value) == "null" ? "" : cmd.Parameters["po_omr"].Value : "") + "\"" + ",";
                    details_Response.STC = Convert.ToString(cmd.Parameters["po_srv_type_cd"].Value);
                    details_Response.STD = Convert.ToString(cmd.Parameters["po_srv_type_desc"].Value);
                    details_Response.SSC = Convert.ToString(cmd.Parameters["po_sub_srv_cd"].Value);
                    details_Response.SSD = Convert.ToString(cmd.Parameters["po_sub_srv_desc"].Value);
                    details_Response.BC = Convert.ToString(cmd.Parameters["po_bay_cd"].Value);
                    details_Response.BD = Convert.ToString(cmd.Parameters["po_bay_desc"].Value);
                    details_Response.SAC = Convert.ToString(cmd.Parameters["po_srv_adv_cd"].Value);
                    details_Response.SAD = Convert.ToString(cmd.Parameters["po_srv_adv_desc"].Value);
                    details_Response.GC = Convert.ToString(cmd.Parameters["po_group_cd"].Value);
                    details_Response.GD = Convert.ToString(cmd.Parameters["po_group_desc"].Value);
                    details_Response.TC = Convert.ToString(cmd.Parameters["po_tech_cd"].Value);
                    details_Response.TD = Convert.ToString(cmd.Parameters["po_tech_desc"].Value);
                    details_Response.TAC = Convert.ToString(cmd.Parameters["po_tech_adv_Cd"].Value);
                    details_Response.TAD = Convert.ToString(cmd.Parameters["po_tech_adv_desc"].Value);
                    details_Response.CEOA = Convert.ToString(cmd.Parameters["po_ceo_approval"].Value);
                    details_Response.LFDT = Convert.ToString(cmd.Parameters["po_lastflwup_date"].Value);
                    details_Response.LFC = Convert.ToString(cmd.Parameters["po_lastflwup_csi"].Value);//((cmd.Parameters["po_lastflwup_csi"].Value != null && !(cmd.Parameters["po_lastflwup_csi"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_lastflwup_csi"].Value) == "null" ? "" : cmd.Parameters["po_lastflwup_csi"].Value : "") + "\"" + ",";
                    details_Response.LFB = Convert.ToString(cmd.Parameters["po_lastflwup_by"].Value);
                    details_Response.PT = Convert.ToString(cmd.Parameters["po_pickup_type"].Value);
                    details_Response.PTD = Convert.ToString(cmd.Parameters["po_pickup_type_desc"].Value);
                    details_Response.PDT = Convert.ToString(cmd.Parameters["po_pickup_date"].Value);
                    details_Response.PL = Convert.ToString(cmd.Parameters["po_pickup_loc"].Value);
                    details_Response.PLD = Convert.ToString(cmd.Parameters["po_pickup_loc_desc"].Value);
                    details_Response.PDR = Convert.ToString(cmd.Parameters["po_driver"].Value);
                    details_Response.PDD = Convert.ToString(cmd.Parameters["po_driver_desc"].Value);
                    details_Response.ELA = Convert.ToString(cmd.Parameters["po_est_labor_amt"].Value != null && !(cmd.Parameters["po_est_labor_amt"].Value is DBNull)) ?? Convert.ToString(cmd.Parameters["po_est_labor_amt"].Value == null ? cmd.Parameters["po_est_labor_amt"].Value : "");

                    details_Response.EPA = Convert.ToString(cmd.Parameters["po_est_part_amt"].Value);
                    details_Response.RELA = Convert.ToString(cmd.Parameters["po_re_est_labor_amt"].Value);
                    details_Response.REPA = Convert.ToString(cmd.Parameters["po_re_est_part_amt"].Value);
                    details_Response.PRM = Convert.ToString(cmd.Parameters["po_pickup_remarks"].Value);
                    details_Response.FPYN = Convert.ToString(cmd.Parameters["po_free_pickup_yn"].Value);
                    details_Response.MMSNUM = Convert.ToString(cmd.Parameters["po_mms_num"].Value);
                    details_Response.IPDT = Convert.ToString(cmd.Parameters["po_intial_prom_date"].Value);
                    details_Response.RPDT = Convert.ToString(cmd.Parameters["po_revised_prom_date"].Value);
                    details_Response.JCCDT = Convert.ToString(cmd.Parameters["po_jc_close_date"].Value);
                    details_Response.JCODT = Convert.ToString(cmd.Parameters["po_jc_open_date"].Value);
                    details_Response.CCS = Convert.ToString(cmd.Parameters["po_cust_corp_status"].Value);
                    details_Response.RST = Convert.ToString(cmd.Parameters["po_rdtest_st_time"].Value);//((cmd.Parameters["po_rdtest_st_time"].Value != null && !(cmd.Parameters["po_rdtest_st_time"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_rdtest_st_time"].Value) == "null" ? "" : cmd.Parameters["po_rdtest_st_time"].Value : "") + "\"";
                    details_Response.RSKM = Convert.ToString(cmd.Parameters["po_rdtest_st_km"].Value);//((cmd.Parameters["po_rdtest_st_km"].Value != null && !(cmd.Parameters["po_rdtest_st_km"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_rdtest_st_km"].Value) == "null" ? "" : cmd.Parameters["po_rdtest_st_km"].Value : "") + "\"";
                    details_Response.RSET = Convert.ToString(cmd.Parameters["po_rdtest_end_time"].Value);//((cmd.Parameters["po_rdtest_end_time"].Value != null && !(cmd.Parameters["po_rdtest_end_time"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_rdtest_end_time"].Value) == "null" ? "" : cmd.Parameters["po_rdtest_end_time"].Value : "") + "\"";
                    details_Response.RSEK = Convert.ToString(cmd.Parameters["po_rdtest_end_km"].Value);//((cmd.Parameters["po_rdtest_end_km"].Value != null && !(cmd.Parameters["po_rdtest_end_km"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_rdtest_end_km"].Value) == "null" ? "" : cmd.Parameters["po_rdtest_end_km"].Value : "") + "\"";
                    details_Response.ESLA = Convert.ToString(cmd.Parameters["po_est_sch_labor_amt"].Value);//((cmd.Parameters["po_est_sch_labor_amt"].Value != null && !(cmd.Parameters["po_est_sch_labor_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_est_sch_labor_amt"].Value) == "null" ? "" : cmd.Parameters["po_est_sch_labor_amt"].Value : "") + "\"";
                    details_Response.ESPA = Convert.ToString(cmd.Parameters["po_est_sch_part_amt"].Value);//((cmd.Parameters["po_est_sch_part_amt"].Value != null && !(cmd.Parameters["po_est_sch_part_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_est_sch_part_amt"].Value) == "null" ? "" : cmd.Parameters["po_est_sch_part_amt"].Value : "") + "\"";
                    details_Response.ELA = Convert.ToString(cmd.Parameters["po_est_labor_amt"].Value);//((cmd.Parameters["po_est_labor_amt"].Value != null && !(cmd.Parameters["po_est_labor_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_est_labor_amt"].Value) == "null" ? "" : cmd.Parameters["po_est_labor_amt"].Value : "") + "\"";
                    details_Response.EPA = Convert.ToString(cmd.Parameters["po_est_part_amt"].Value);//((cmd.Parameters["po_est_part_amt"].Value != null && !(cmd.Parameters["po_est_part_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_est_part_amt"].Value) == "null" ? "" : cmd.Parameters["po_est_part_amt"].Value : "") + "\"";
                    details_Response.RELA = Convert.ToString(cmd.Parameters["po_re_est_labor_amt"].Value);//((cmd.Parameters["po_re_est_labor_amt"].Value != null && !(cmd.Parameters["po_re_est_labor_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_re_est_labor_amt"].Value) == "null" ? "" : cmd.Parameters["po_re_est_labor_amt"].Value : "") + "\"";
                    details_Response.REPA = Convert.ToString(cmd.Parameters["po_re_est_part_amt"].Value);//((cmd.Parameters["po_re_est_part_amt"].Value != null && !(cmd.Parameters["po_re_est_part_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_re_est_part_amt"].Value) == "null" ? "" : cmd.Parameters["po_re_est_part_amt"].Value : "") + "\"";
                    details_Response.AMCYN = Convert.ToString(cmd.Parameters["po_amc_yn"].Value);
                    details_Response.AMCN = Convert.ToString(cmd.Parameters["po_amc_num"].Value);
                    details_Response.AMCDT = Convert.ToString(cmd.Parameters["po_amc_date"].Value);
                    details_Response.RCYN = Convert.ToString(cmd.Parameters["po_recall_yn"].Value);
                    details_Response.DRC = Convert.ToString(cmd.Parameters["po_delay_reas_cd"].Value);
                    details_Response.DRD = Convert.ToString(cmd.Parameters["po_delay_reas_desc"].Value);
                    details_Response.DRR = Convert.ToString(cmd.Parameters["po_delay_reas_remarks"].Value);
                    details_Response.CRC = Convert.ToString(cmd.Parameters["po_csi_reas_cd"].Value);
                    details_Response.CRD = Convert.ToString(cmd.Parameters["po_csi_reas_desc"].Value);
                    details_Response.CRR = Convert.ToString(cmd.Parameters["po_csi_reas_remarks"].Value);
                    details_Response.PDP = Convert.ToString(cmd.Parameters["po_part_disc_perc"].Value);//((cmd.Parameters["po_part_disc_perc"].Value != null && !(cmd.Parameters["po_part_disc_perc"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_part_disc_perc"].Value) == "null" ? "" : cmd.Parameters["po_part_disc_perc"].Value : "") + "\"";
                    details_Response.LDP = Convert.ToString(cmd.Parameters["po_labour_disc_perc"].Value);//((cmd.Parameters["po_labour_disc_perc"].Value != null && !(cmd.Parameters["po_labour_disc_perc"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_part_disc_perc"].Value) == "null" ? "" : cmd.Parameters["po_part_disc_perc"].Value : "") + "\"";
                    details_Response.DABC = Convert.ToString(cmd.Parameters["po_disc_auth_by_cd"].Value);
                    details_Response.DABD = Convert.ToString(cmd.Parameters["po_disc_auth_by_desc"].Value);
                    details_Response.VTSN = Convert.ToString(cmd.Parameters["po_vts_card_num"].Value);//((cmd.Parameters["po_vts_card_num"].Value != null && !(cmd.Parameters["po_vts_card_num"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_vts_card_num"].Value) == "null" ? "" : cmd.Parameters["po_vts_card_num"].Value : "") + "\"";
                    details_Response.CHKDT = Convert.ToString(cmd.Parameters["po_checkin_date"].Value);
                    details_Response.COAMT = Convert.ToString(cmd.Parameters["po_cus_out_amt"].Value);//((cmd.Parameters["po_cus_out_amt"].Value != null && !(cmd.Parameters["po_cus_out_amt"].Value is DBNull)) ? Convert.ToString(cmd.Parameters["po_cus_out_amt"].Value) == "null" ? "" : cmd.Parameters["po_cus_out_amt"].Value : "") + "\"";
                    details_Response.PROB = Convert.ToString(cmd.Parameters["po_prob_str"].Value);
                    details_Response.CHANNEL = Convert.ToString(cmd.Parameters["po_channel"].Value);
                    details_Response.PFLOT = Convert.ToString(cmd.Parameters["po_pref_followup_time"].Value);
                    details_Response.WASH_TYPE = Convert.ToString(cmd.Parameters["po_wash_type"].Value);
                    details_Response.MMS_ADDRESS = Convert.ToString(cmd.Parameters["po_mms_address"].Value);
                    details_Response.MMS_CITY = Convert.ToString(cmd.Parameters["po_mms_city"].Value);
                    details_Response.MMS_DISTRICT = Convert.ToString(cmd.Parameters["po_mms_district"].Value);
                    details_Response.MMS_STATE = Convert.ToString(cmd.Parameters["po_mms_state"].Value);
                    details_Response.MMS_PIN = Convert.ToString(cmd.Parameters["po_mms_pin"].Value);
                    details_Response.AUDIO_COUNT = Convert.ToString(cmd.Parameters["PO_AUDIO_COUNT"].Value);
                    details_Response.OCAS_CNT = Convert.ToString(cmd.Parameters["po_ocas_cnt"].Value);
                    details_Response.SAVE_CNT = Convert.ToString(cmd.Parameters["po_save_cnt"].Value);
                    details_Response.SENT_CNT = Convert.ToString(cmd.Parameters["po_sent_cnt"].Value);
                    details_Response.FINAL_INSPECTION = Convert.ToString(cmd.Parameters["PO_FINAL_INSPECTION"].Value);
                    details_Response.ADD_CHK = Convert.ToString(cmd.Parameters["PO_ADD_CHK"].Value);
                    details_Response.CCP_CLAIM = Convert.ToString(cmd.Parameters["po_ccp_claim_yn"].Value);
                    details_Response.CCP_NUM = Convert.ToString(cmd.Parameters["po_ccp_num"].Value);
                    details_Response.CCP_TYPE = Convert.ToString(cmd.Parameters["po_ccp_type"].Value);
                    details_Response.CORP_CUST_FLAG = Convert.ToString(cmd.Parameters["PO_CORP_CUST_FLAG"].Value);
                    details_Response.CORP_NAME = Convert.ToString(cmd.Parameters["PO_CORP_NAME"].Value);
                    details_Response.VIN = Convert.ToString(cmd.Parameters["PO_VIN"].Value);
                    details_ResponseList.Add(details_Response);
                    OracleDataReader dr2 = (OracleDataReader)cmd.Parameters["PO_DEMAND_REFCUR"].Value;
                    while (dr2.Read())
                    {
                        demand_refcur = new demand_refcur();
                        demand_refcur.SN = Convert.ToString(dr2["SRL_NUM"]);
                        demand_refcur.DC = Convert.ToString(dr2["DEMAND_CD"]);
                        demand_refcur.DD = Convert.ToString(dr2["DEMAND_DESC"]);
                        demand_refcur.RBY = Convert.ToString(dr2["REPORTED_BY"]);
                        demand_refcur.RBYD = Convert.ToString(dr2["REPORTED_BY_DESC"]);
                        demand_refcur.ATTYN = Convert.ToString(dr2["ATTENDED_YN"]);
                        demand_refcur.CRYYN = Convert.ToString(dr2["CARRY_FWD_YN"]);
                        demand_refcur.CRYYND = Convert.ToString(dr2["CARRY_FWD_YN_DESC"]);
                        demand_refcur.WYN = Convert.ToString(dr2["WAR_YN"]);
                        demand_refcur.PRBN = Convert.ToString(dr2["PROBLEM_NARR"]);
                        DEMAND_REF_CUR.Add(demand_refcur);
                    }

                    //Get value from output ref cursor
                    OracleDataReader dr3 = (OracleDataReader)cmd.Parameters["PO_PART_REFCUR"].Value;
                    while (dr3.Read())
                    {

                        part_refcur_opne = new part_refcur_opne();
                        part_refcur_opne.SN = Convert.ToString(dr3[0]);
                        part_refcur_opne.DN = Convert.ToString(dr3[1]);
                        part_refcur_opne.PN = Convert.ToString(dr3[2]);
                        part_refcur_opne.PD = Convert.ToString(dr3[3]);
                        part_refcur_opne.RQ = Convert.ToString(dr3[4]);
                        part_refcur_opne.IQ = Convert.ToString(dr3[5]);
                        part_refcur_opne.RTNQ = Convert.ToString(dr3[6]);
                        part_refcur_opne.BQ = Convert.ToString(dr3[7]);
                        part_refcur_opne.R = Convert.ToString(dr3[8]);
                        part_refcur_opne.TA = Convert.ToString(dr3[9]);
                        part_refcur_opne.BT = Convert.ToString(dr3[10]);
                        part_refcur_opne.BTD = Convert.ToString(dr3[11]);
                        part_refcur_opne.AD = Convert.ToString(dr3[12]);
                        part_refcur_opne.DI = Convert.ToString(dr3[13]);
                        part_refcur_opne.DID = Convert.ToString(dr3[14]);
                        part_refcur_opne.DV = Convert.ToString(dr3[15]);
                        part_refcur_opne.SR = Convert.ToString(dr3[16]);
                        part_refcur_opne.SDPRF = Convert.ToString(dr3[17]);
                        part_refcur_opne.CP = Convert.ToString(dr3[18]);
                        part_refcur_opne.IP = Convert.ToString(dr3[19]);
                        part_refcur_opne.DP = Convert.ToString(dr3[20]);
                        part_refcur_opne.OP = Convert.ToString(dr3[21]);
                        part_refcur_opne.CS = Convert.ToString(dr3[22]);
                        part_refcur.Add(part_refcur_opne);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr4 = (OracleDataReader)cmd.Parameters["PO_LABOR_REFCUR"].Value;
                    while (dr4.Read())
                    {

                        po_labor_Refcur = new po_labor_Refcur();
                        po_labor_Refcur.LSN = Convert.ToString(dr4["SRL_NUM"]);
                        po_labor_Refcur.LC = Convert.ToString(dr4["LABOUR_CD"]);
                        po_labor_Refcur.LD = Convert.ToString(dr4["LABOUR_DESC"]);
                        po_labor_Refcur.MYN = Convert.ToString(dr4["MOD_YN"]);
                        po_labor_Refcur.FAMT = Convert.ToString(dr4["FLAT_AMT"]);
                        po_labor_Refcur.LAMT = Convert.ToString(dr4["LABOUR_AMOUT"]);
                        po_labor_Refcur.FHRS = Convert.ToString(dr4["FRM_HRS"]);
                        po_labor_Refcur.LBT = Convert.ToString(dr4["BILL_TYPE"]);
                        po_labor_Refcur.LBTD = Convert.ToString(dr4["BILL_TYPE_DESC"]);
                        po_labor_Refcur.LDI = Convert.ToString(dr4["DISC_IND"]);
                        po_labor_Refcur.LDID = Convert.ToString(dr4["DISC_IND_DESC"]);
                        po_labor_Refcur.LDV = Convert.ToString(dr4["DISC_VALUE"]);
                        po_labor_Refcur.LSR = Convert.ToString(dr4["SPLIT_RATIO"]);
                        po_labor_Refcur.LSD = Convert.ToString(dr4["SPLIT_DESC"]);
                        po_labor_Refcur.LCP = Convert.ToString(dr4["CUST_PER"]);
                        po_labor_Refcur.LIP = Convert.ToString(dr4["INS_PER"]);
                        po_labor_Refcur.LDP = Convert.ToString(dr4["DLR_PER"]);
                        po_labor_Refcur.LOP = Convert.ToString(dr4["OEM_PER"]);
                        po_labor_Refcur.TCH = Convert.ToString(dr4["TECHNICIAN"]);
                        po_labor_Refcur.TCHD = Convert.ToString(dr4["TECHNICIAN_DESC"]);
                        po_labor_Refcur.TCH2 = Convert.ToString(dr4["TECHNICIAN_2"]);
                        po_labor_Refcur.TCH2D = Convert.ToString(dr4["TECHNICIAN_2_DESC"]);
                        po_labor_Refcur.SYN = Convert.ToString(dr4["SUBLET_YN"]);
                        po_labor_Refcur.SAMT = Convert.ToString(dr4["SUBLET_AMT"]);
                        po_labor_Refcur.SCC = Convert.ToString(dr4["SUB_CONT_CD"]);
                        po_labor_Refcur.SCD = Convert.ToString(dr4["SUB_CONT_DESC"]);
                        po_labor.Add(po_labor_Refcur);
                    }

                    //Get value from output ref cursor
                    OracleDataReader dr5 = (OracleDataReader)cmd.Parameters["PO_INV_REFCUR"].Value;
                    while (dr5.Read())
                    {

                        po_inv_refcur = new po_inv_refcur();
                        po_inv_refcur.ICD = Convert.ToString(dr5["INV_CD"]);
                        po_inv_refcur.IDSC = Convert.ToString(dr5["INV_DESC"]);
                        po_inv_refcur.ICNT = Convert.ToString(dr5["INV_COUNT"]);
                        po_inv_refcur.IYN = Convert.ToString(dr5["INV_YN"]);
                        po_inv.Add(po_inv_refcur);
                    }

                    //Get value from output ref cursor
                    OracleDataReader dr6 = (OracleDataReader)cmd.Parameters["PO_SMCARD_REFCUR"].Value;
                    while (dr6.Read())
                    {

                        po_smcard_refcur = new po_smcard_refcur();
                        po_smcard_refcur.SRLN = Convert.ToString(dr6["SRL_NUM"]);
                        po_smcard_refcur.ST = Convert.ToString(dr6["SRV_TYPE"]);
                        po_smcard_refcur.STD1 = Convert.ToString(dr6["SRV_TYPE_DESC"]);
                        po_smcard_refcur.SC = Convert.ToString(dr6["SRV_CD"]);
                        po_smcard_refcur.SD = Convert.ToString(dr6["SRV_DESC"]);
                        po_smcard_refcur.PN = Convert.ToString(dr6["PART_NUM"]);
                        po_smcard_refcur.PD = Convert.ToString(dr6["PART_DESC"]);
                        po_smcard_refcur.SQ = Convert.ToString(dr6["SRV_QTY"]);
                        po_smcard_refcur.AYN = Convert.ToString(dr6["ACCEPT_YN"]);
                        po_smcard_refcur.AYND = Convert.ToString(dr6["ACCEPT_YN_DESC"]);
                        po_smcard_refcur.RR = Convert.ToString(dr6["REJECT_REASON"]);
                        po_smcard_refcur.RRD = Convert.ToString(dr6["REJECT_REASON_DESC"]);
                        po_smcard_refcur.AQTY = Convert.ToString(dr6["ACCEPT_QTY"]);
                        po_smcard.Add(po_smcard_refcur);
                    }



                    //Get value from output ref cursor
                    OracleDataReader dr7 = (OracleDataReader)cmd.Parameters["PO_UNAPPRFIT_REFCUR"].Value;
                    while (dr7.Read())
                    {
                        po_unapprfit_refcur = new po_unapprfit_refcur();
                        po_unapprfit_refcur.USN = Convert.ToString(dr7["SRL_NUM"]);
                        po_unapprfit_refcur.FC = Convert.ToString(dr7["FITMENT_CD"]);
                        po_unapprfit_refcur.FD = Convert.ToString(dr7["FITMENT_DESC"]);
                        po_unapprfit.Add(po_unapprfit_refcur);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr8 = (OracleDataReader)cmd.Parameters["PO_TECH_CAMP_REFCUR"].Value;
                    while (dr8.Read())
                    {

                        tech_camp_refcur = new tech_camp_refcur();
                        tech_camp_refcur.TCSN = Convert.ToString(dr8["SRL_NUM"]);
                        tech_camp_refcur.SCN = Convert.ToString(dr8["SRV_CIRCULAR_NUM"]);
                        tech_camp_refcur.SUB = Convert.ToString(dr8["SUBJECT"]);
                        tech_camp_refcur.MSRE = Convert.ToString(dr8["MEASURE"]);
                        tech_camp_refcur.FDT = Convert.ToString(dr8["FROM_DATE"]);
                        tech_camp_refcur.TDT = Convert.ToString(dr8["TO_DATE"]);
                        tech_camp_refcur.RCN = Convert.ToString(dr8["RECALL_NUM"]);
                        tech_camp_refcur.JCSC = Convert.ToString(dr8["JC_STATUS"]);
                        tech_camp_refcur.JCSD = Convert.ToString(dr8["JC_STATUS_DESC"]);
                        tech_camp.Add(tech_camp_refcur);
                    }


                    //Get value from output ref cursor
                    OracleDataReader dr9 = (OracleDataReader)cmd.Parameters["PO_REPAIR_ACT_REFCUR"].Value;
                    while (dr9.Read())
                    {

                        repair_act_refcur = new repair_act_refcur();
                        repair_act_refcur.RSN = Convert.ToString(dr9["SRL_NUM"]);
                        repair_act_refcur.RDC = Convert.ToString(dr9["DEMAND_CD"]);
                        repair_act_refcur.RDD = Convert.ToString(dr9["DEMAND_DESC"]);
                        repair_act_refcur.PC = Convert.ToString(dr9["PROBLEM_CD"]);
                        repair_act_refcur.PRD = Convert.ToString(dr9["PROBLEM_DESC"]);
                        repair_act_refcur.FTC = Convert.ToString(dr9["FAULT_CD"]);
                        repair_act_refcur.FTD = Convert.ToString(dr9["FAULT_DESC"]);
                        repair_act_refcur.AC = Convert.ToString(dr9["ACTION_CD"]);
                        repair_act_refcur.AD = Convert.ToString(dr9["ACTION_DESC"]);
                        repair_act.Add(repair_act_refcur);
                    }
                    //Get value from output ref cursor
                    OracleDataReader dr10 = (OracleDataReader)cmd.Parameters["PO_COMPLY_DTL_REFCUR"].Value;
                    while (dr10.Read())
                    {

                        comply_dtl_refcur = new comply_dtl_refcur();
                        comply_dtl_refcur.SLN = Convert.ToString(dr10[0]);
                        comply_dtl_refcur.PSFMUM = Convert.ToString(dr10[1]);
                        comply_dtl_refcur.COMPDTL = Convert.ToString(dr10[2]);
                        comply_dtl_refcur.ATTYN = Convert.ToString(dr10[3]);
                        comply_dtl.Add(comply_dtl_refcur);
                    }
                    //Get value from output ref cursor
                    OracleDataReader dr1 = (OracleDataReader)cmd.Parameters["PO_DLR_REFCUR"].Value;
                    while (dr1.Read())
                    {
                        PO_DLR_REFCUR = new PO_DLR_REFCUR();
                        PO_DLR_REFCUR.DEALER_CODE = Convert.ToString(dr1[0]);
                        PO_DLR_REFCUR.DEALER_NAME = Convert.ToString(dr1[1]);
                        PO_DLR_REFCUR.REGION_CD = Convert.ToString(dr1[2]);
                        PO_DLR_REFCUR.REGION_NAME = Convert.ToString(dr1[3]);
                        PO_DLR_REFCUR.ZONE_CD = Convert.ToString(dr1[4]);
                        PO_DLR_REFCUR.ZONE = Convert.ToString(dr1[5]);
                        PO_DLR.Add(PO_DLR_REFCUR);
                    }

                }
                Typedetail = new JCOpenDetails();
                Typedetail.K = details_ResponseList;
                Typedetail.DRF = DEMAND_REF_CUR;
                Typedetail.PRF = part_refcur;
                Typedetail.LRF = po_labor;
                Typedetail.IRF = po_inv;
                Typedetail.SCRF = po_smcard;
                Typedetail.UFTRF = po_unapprfit;
                Typedetail.TCRF = tech_camp;
                Typedetail.RARF = repair_act;
                Typedetail.CMPLY = comply_dtl;
                Typedetail.DLR_DETAILS = PO_DLR;
                Details.Add(Typedetail);
                con.Close();
                response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                response.result = Details;
                Logger.SuccessLogPrint("GetJCOpenDetails", "SP_JCO_GET_JC_OPEN_DTL", "'pn_jc_module': '" + Jcmodule + "','pn_user_id':'" + UserID + "','pn_parent_group':'" + Parent_group + "','pn_dealer_map_cd':'" + Dealer_map_cd + "','pn_loc_Cd':'" + Loc_Cd + "','pn_comp_fa':'" + Comp_fa + "','pn_jc_no':'" + Jcno, "Success Code': '" + Convert.ToString(cmd.Parameters["po_err_cd"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["po_err_msg"].Value));
            }
            catch (Exception ex)
            {
                //Logger.Log(ex.InnerException.ToString(), "GET_DRIVABLE_ADVICE");
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();
                Logger.ErrorLogException("GetJCOpenDetails", "SP_JCO_GET_JC_OPEN_DTL", "'pn_jc_module': '" + Jcmodule + "','pn_user_id':'" + UserID + "','pn_parent_group':'" + Parent_group + "','pn_dealer_map_cd':'" + Dealer_map_cd + "','pn_loc_Cd':'" + Loc_Cd + "','pn_comp_fa':'" + Comp_fa + "','pn_jc_no':'" + Jcno, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        #region GetSrvDemandLabourDetails
        /// <summary>
        /// GetSrvDemandLabourDetails
        /// </summary>
        /// <param name="PN_SRV_TYPE"></param>
        /// <returns></returns>
        public BaseListReturnType<GET_SRV_DEMAND_LABOUR> GetSrvDemandLabourDetails(string PN_SRV_TYPE)
        {
            BaseListReturnType<GET_SRV_DEMAND_LABOUR> response = new BaseListReturnType<GET_SRV_DEMAND_LABOUR>();

            GET_SRV_DEMAND_LABOUR Typedetail = null;
            List<GET_SRV_DEMAND_LABOUR> Details = new List<GET_SRV_DEMAND_LABOUR>();

            //PO_DEMAND_LAB_REFCUR 
            List<DEMAND_LAB_REFCUR> lAB_REFCUR_List = new List<DEMAND_LAB_REFCUR>();
            DEMAND_LAB_REFCUR lAB_REFCUR;

            //Validate Token
            ServiceHeaderInfo1 headerInfo = Common.Authenticate2(WebOperationContext.Current.IncomingRequest);
            if (!headerInfo.IsAuthenticated)
            {
                response.code = (int)ServiceMassageCode.UNAUTHORIZED_REQUEST;
                response.message = Convert.ToString(ServiceMassageCode.ERROR) + " - Token is invailid.";
                response.result = null;
                return response;
            }
            try
            {
                con = new OracleConnection(constr);
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandText = ProcedureDetails.SP_GET_SRV_DEMAND_LABOUR;
                cmd.CommandType = CommandType.StoredProcedure;

                // Input Parameters
                cmd.Parameters.Add("PN_SRV_TYPE", OracleType.VarChar, 50).Value = PN_SRV_TYPE;

                cmd.Parameters.Add("PO_DEMAND_LAB_REFCUR", OracleType.Cursor).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_CD", OracleType.Int32, 8).Direction = ParameterDirection.Output;
                cmd.Parameters.Add("PO_ERR_MSG", OracleType.VarChar, 200).Direction = ParameterDirection.Output;
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                cmd.ExecuteNonQuery();
                if (!string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = null;
                    con.Close();
                    return response;
                }
                //check error 
                if (string.IsNullOrEmpty(cmd.Parameters["PO_ERR_MSG"].Value.ToString()))
                {
                    OracleDataReader dr = (OracleDataReader)cmd.Parameters["PO_DEMAND_LAB_REFCUR"].Value;
                    while (dr.Read())
                    {
                        lAB_REFCUR = new DEMAND_LAB_REFCUR();

                        lAB_REFCUR.DEMAND_REPAIR = Convert.ToString(dr["DEMAND_REPAIR"]);
                        lAB_REFCUR.LABOUR_CD = Convert.ToString(dr["LABOUR_CD"]);
                        lAB_REFCUR_List.Add(lAB_REFCUR);
                    }
                    Typedetail = new GET_SRV_DEMAND_LABOUR();
                    Typedetail.DLR = lAB_REFCUR_List;
                    Details.Add(Typedetail);
                    response.code = 0;
                    response.message = cmd.Parameters["PO_ERR_MSG"].Value.ToString();
                    response.result = Details;
                    if (dr != null)
                    {
                        dr.Dispose();
                        dr = null;
                    }

                }
                con.Close();
                //response.code = Convert.ToInt32(cmd.Parameters["PO_ERR_CD"].Value.ToString());

                Logger.SuccessLogPrint("GetSrvDemandLabourDetails", "SP_GET_SRV_DEMAND_LABOUR ", "'PN_SRV_TYPE': '" + PN_SRV_TYPE, "Success Code': '" + Convert.ToString(cmd.Parameters["PO_ERR_CD"].Value) + "', 'Success Message': '" + Convert.ToString(cmd.Parameters["PO_ERR_MSG"].Value));
            }
            catch (Exception ex)
            {
                var lineNumber = 0;
                const string lineSearch = ":line";
                var index = ex.StackTrace.LastIndexOf(lineSearch);
                var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = lineNumberText + ex.Message; //ex.Message;
                response.result = null;
                con.Close();
                cmd.Dispose();

                Logger.ErrorLogException("GetSrvDemandLabourDetails", "SP_GET_SRV_DEMAND_LABOUR ", "'PN_SRV_TYPE': '" + PN_SRV_TYPE, ex);
            }
            finally
            {
                con.Close();
                cmd.Dispose();
                OracleConnection.ClearPool(con);
            }
            return response;
        }
        #endregion

        //JWT Token

        public Tokens GenerateToken(string UserId, string Password)
        {
            Common tokenGenerate = new Common();
            return tokenGenerate.GenerateJWTTokens(UserId, Password);
        }
        //public Tokens GenerateXmlToken(string UserId, string Password)
        //{
        //    Common tokenXMLGenerate = new Common();
        //    return tokenXMLGenerate.GenearteXMLDealerFile(UserId, Password);
        //}

        public Tokens GenerateRefreshToken(string UserId, string Password)
        {
            Common tokenGenerate = new Common();
            return tokenGenerate.GenerateJWTTokens(UserId, Password);
        }

        //public ServiceHeaderInfos1 AuthenticateJWTToken()
        //{

        //    Common tokenGenerate = new Common();
        //    var obj = tokenGenerate.AuthenticateJWTToken(WebOperationContext.Current.IncomingRequest);
        //    return obj;
        //}

        public BaseListReturnType<Tokens> RefreshToken(string UserName, string Password)
        {
            BaseListReturnType<Tokens> response = new BaseListReturnType<Tokens>();
            Tokens Typedetail = new Tokens();
            List<Tokens> Details = new List<Tokens>();
            RefreshToken PART_CURSOR;
            try
            {
                PART_CURSOR = new RefreshToken();
                Tokens Tokenvalue = GenerateRefreshToken(UserName, Password);

                if (!string.IsNullOrEmpty(Tokenvalue.Refresh_Token))
                {
                    PART_CURSOR.Refresh_Token = Tokenvalue.Refresh_Token;
                    PART_CURSOR.Access_Token = Tokenvalue.Access_Token;
                    Typedetail = new Tokens();
                    Typedetail.Access_Token = Tokenvalue.Access_Token;
                    Typedetail.Refresh_Token = Tokenvalue.Refresh_Token;
                    Details.Add(Typedetail);
                    response.code = (int)ServiceMassageCode.SUCCESS;
                    response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
                    response.result = Details;
                }
                else
                {
                    response.code = (int)ServiceMassageCode.ERROR;
                    response.message = "Error in token generation please try again";
                    response.result = null;
                }

            }
            catch (Exception ex)
            {
                var lineNumber = 0;
                const string lineSearch = ":line";
                var index = ex.StackTrace.LastIndexOf(lineSearch);
                var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                response.code = (int)ServiceMassageCode.ERROR;
                response.message = lineNumberText + ex.Message; //ex.Message;
                response.result = null;

            }
            return response;
        }

        public BaseListReturnType<dynamic> logout(string token)
        {
            BaseListReturnType<dynamic> response = new BaseListReturnType<dynamic>();
            Common tokenLog = new Common();
            dynamic obj = tokenLog.LogOut(token);

            response.code = (int)ServiceMassageCode.SUCCESS;
            response.message = Convert.ToString(ServiceMassageCode.SUCCESS);
            response.result = null;
            return response;

        }
    }
}